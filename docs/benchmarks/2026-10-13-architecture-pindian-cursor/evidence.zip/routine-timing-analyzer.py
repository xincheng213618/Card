"""Parse an already completed verbose Test-Changed run; never launches a runner."""
import collections
import json
import pathlib
import re
import sys

logs_root = pathlib.Path(sys.argv[1])
summary_path = pathlib.Path(sys.argv[2])
summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
time_pattern = re.compile(r"^\[TIME\] (?P<name>.+): (?P<ms>\d+\.\d+) ms\s*$")
core_totals = re.compile(r"^(\d+) passed, (\d+) failed, (\d+) skipped \((\d+) total\)\.$")
wpf_totals = re.compile(r"^(\d+) WPF checks passed, (\d+) failed\. Renders:")
routine_ms = summary["durationMs"]
scopes = {}

for scope in ("Core", "WPF"):
    path = logs_root / (scope.lower() + "-selected.log")
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    rows = []
    counts = None
    passed_names = set()
    for line_number, line in enumerate(lines, 1):
        if line.startswith("[PASS] "):
            passed_names.add(line[7:])
        match = time_pattern.fullmatch(line)
        if match:
            rows.append({"name": match["name"], "duration_ms": float(match["ms"]),
                         "log_line": line_number})
        totals = (core_totals if scope == "Core" else wpf_totals).match(line)
        if totals:
            counts = {"passed": int(totals[1]), "failed": int(totals[2])}
    if counts is None or len(rows) != counts["passed"] + counts["failed"]:
        raise ValueError(f"Incomplete {scope} timing log: rows={len(rows)}, totals={counts}")
    summed_ms = sum(row["duration_ms"] for row in rows)
    step = next(item for item in summary["results"] if item["name"].startswith(scope + " selected checks"))
    sorted_rows = sorted(rows, key=lambda row: row["duration_ms"], reverse=True)
    for rank, row in enumerate(sorted_rows, 1):
        row["rank"] = rank
        row["status"] = "passed" if row["name"] in passed_names else "failed"
        row["scope_timed_percent"] = round(100 * row["duration_ms"] / summed_ms, 4)
        row["routine_wall_percent"] = round(100 * row["duration_ms"] / routine_ms, 4)
    name_counts = collections.Counter(row["name"] for row in rows)
    scopes[scope] = {
        "log": str(path), "counts": counts, "time_row_count": len(rows),
        "timed_body_sum_ms": round(summed_ms, 3), "process_step_wall_ms": step["durationMs"],
        "wall_minus_timed_ms": round(step["durationMs"] - summed_ms, 3),
        "step_routine_wall_percent": round(100 * step["durationMs"] / routine_ms, 4),
        "top_1_timed_percent": round(100 * sorted_rows[0]["duration_ms"] / summed_ms, 4),
        "top_5_timed_percent": round(100 * sum(row["duration_ms"] for row in sorted_rows[:5]) / summed_ms, 4),
        "top_10_timed_percent": round(100 * sum(row["duration_ms"] for row in sorted_rows[:10]) / summed_ms, 4),
        "top_10": sorted_rows[:10],
        "repeated_time_names": {name: count for name, count in name_counts.items() if count > 1},
        "all_timed_rows": sorted_rows,
    }

build = next(item for item in summary["results"] if item["name"] == "Build selected scope")
report = {
    "review_kind": "single completed routine profile; source-informed attribution, no additional run",
    "summary": str(summary_path), "routine_status": summary["status"], "routine_mode": summary["mode"],
    "routine_duration_ms": routine_ms, "target_ms": 60000,
    "target_overage_ms": max(0, routine_ms - 60000),
    "build_wall_ms": build["durationMs"],
    "build_routine_wall_percent": round(100 * build["durationMs"] / routine_ms, 4),
    "wrapper_wall_minus_steps_ms": routine_ms - sum(item["durationMs"] for item in summary["results"]),
    "method": "Parse exact invariant-culture [TIME] Name: N.NNN ms lines. Count matches the final passed+failed totals. Sort each scope separately and divide by its summed timed bodies; whole-routine ratios use summary wall time. Build/process/wrapper time is kept separate. Filters execute their union once, not once per matching filter.",
    "scopes": scopes,
}
print(json.dumps(report, ensure_ascii=False, indent=2))
