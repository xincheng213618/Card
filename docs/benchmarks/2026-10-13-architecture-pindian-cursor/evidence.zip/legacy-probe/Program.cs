using System.Text.Json;
using System.Reflection;
using CardGame.Core;
Console.WriteLine("CORE_MVID=" + typeof(GameEngine).Assembly.ManifestModule.ModuleVersionId);
try { BoundaryWangYiChecks.PaidOtherUseNullificationOpaqueObtainAndActualSlash(); Console.WriteLine("ORIGINAL_ASSERTIONS=PASS"); return 0; }
catch (Exception error) { Console.WriteLine("ORIGINAL_ASSERTIONS=FAIL"); Console.WriteLine(error); return 1; }
