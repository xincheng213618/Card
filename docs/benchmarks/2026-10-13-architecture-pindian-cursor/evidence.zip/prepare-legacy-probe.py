from pathlib import Path
import hashlib
import json

root = Path(__file__).parent
repo = Path(r'C:\Users\17917\Desktop\Card')
task_id = '01a13336-b0c2-7472-a49f-7e3458841d28'
if task_id not in (root / '.owner').read_text(encoding='utf-8-sig'):
    raise RuntimeError('Unexpected iteration owner')
probe = root / 'legacy-probe'
if probe.exists():
    raise RuntimeError('Inspect the existing probe instead of replacing it')
probe.mkdir()
(probe / '.owner').write_text(task_id + ' legacy diagnostic source copy', encoding='utf-8')
original = (repo / 'tests/CardGame.Core.Tests/BoundaryWangYiChecks.cs').read_bytes()
source = original.decode('utf-8-sig')
anchor = '        var legacyPaid = E<PaidOwnTargetHpEvent>(legacy).Single();'
if source.count(anchor) != 1:
    raise RuntimeError('The diagnostic insertion point changed')
addition = '''
        Console.WriteLine("LEGACY_FACTS=" + JsonSerializer.Serialize(new {
            Identity = legacyPaid.Receipt.Use,
            IdentityMatches = legacyPaid.Receipt.Use is { ActionId: null, LegacyProducerProgramId: not null, ActorSeat: 1, ProviderSeat: 1, TargetSeat: 0, EffectiveKind: CardKind.Slash },
            HpBefore = legacyHp, HpAfter = legacy.State.Players[0].Hp,
            HpMatches = legacy.State.Players[0].Hp == legacyHp - 1,
            Applied = E<PaidOwnTargetAppliedEvent>(legacy).Single(),
            AppliedActionIsNull = E<PaidOwnTargetAppliedEvent>(legacy).Single().ActionId is null
        }));'''
instrumented = source.replace(anchor, anchor + addition)
(probe / 'BoundaryWangYiChecks.cs').write_text(instrumented, encoding='utf-8', newline='')
(probe / 'LegacyProbe.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><LangVersion>12</LangVersion>
    <AssemblyName>CardGame.LegacyProbe</AssemblyName></PropertyGroup>
  <ItemGroup><Reference Include="CardGame.Core"><HintPath>..\\baseline\\CardGame.Core.dll</HintPath><Private>true</Private></Reference>
    <Reference Include="CardGame.Content.Standard"><HintPath>..\\baseline\\CardGame.Content.Standard.dll</HintPath><Private>true</Private></Reference></ItemGroup>
</Project>''', encoding='utf-8')
(probe / 'Program.cs').write_text('''using System.Text.Json;
using System.Reflection;
using CardGame.Core;
Console.WriteLine("CORE_MVID=" + typeof(GameEngine).Assembly.ManifestModule.ModuleVersionId);
try { BoundaryWangYiChecks.PaidOtherUseNullificationOpaqueObtainAndActualSlash(); Console.WriteLine("ORIGINAL_ASSERTIONS=PASS"); return 0; }
catch (Exception error) { Console.WriteLine("ORIGINAL_ASSERTIONS=FAIL"); Console.WriteLine(error); return 1; }
''', encoding='utf-8')
manifest = {'originalSha256': hashlib.sha256(original).hexdigest(),
            'instrumentedSha256': hashlib.sha256(instrumented.encode()).hexdigest(),
            'singleCaptureInsertionOnly': instrumented.replace(addition, '').encode('utf-8') == source.encode('utf-8'),
            'note': 'No original assertion or command changed; only actual facts are printed immediately before the failing assertion.'}
(root / 'legacy-probe-source.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps(manifest))
