using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using CardGame.Content.Standard;
using CardGame.Core;

string? output = null;
string? variant = null;
for (var index = 0; index < args.Length; index += 2)
{
    if (index + 1 >= args.Length) throw new ArgumentException("Every argument requires a value.");
    switch (args[index])
    {
        case "--output": output = Path.GetFullPath(args[index + 1]); break;
        case "--variant": variant = args[index + 1]; break;
        default: throw new ArgumentException($"Unknown argument: {args[index]}");
    }
}
if (output is null || variant is not ("baseline" or "candidate"))
    throw new ArgumentException("Use --output <absolute-json-path> --variant baseline|candidate.");

var methods = new (string Name, Action Execute)[]
{
    (nameof(BoundaryTaiShiCiChecks.BothRandomStrategiesFreezeReceiptsAndClaimTiedSlashes),
        BoundaryTaiShiCiChecks.BothRandomStrategiesFreezeReceiptsAndClaimTiedSlashes),
    (nameof(BoundaryTaiShiCiChecks.DeclinedRandomPolicyDoesNotConsumeRngAndOpponentCanForceSource),
        BoundaryTaiShiCiChecks.DeclinedRandomPolicyDoesNotConsumeRngAndOpponentCanForceSource),
    (nameof(BoundaryTaiShiCiChecks.MaximumSlashClaimUsesEffectiveRanksAndPreservesDeferredTop),
        BoundaryTaiShiCiChecks.MaximumSlashClaimUsesEffectiveRanksAndPreservesDeferredTop)
};
var results = new List<object>();
var failures = 0;
foreach (var (name, execute) in methods)
{
    PindianObservation.Begin(name);
    var timer = Stopwatch.StartNew();
    string? error = null;
    try { execute(); }
    catch (Exception failure) { failures++; error = failure.ToString(); }
    timer.Stop();
    results.Add(new { Name = name, Passed = error is null, ElapsedMs = timer.Elapsed.TotalMilliseconds, Error = error });
    Console.WriteLine($"{variant}: {name}: {(error is null ? "PASS" : "FAIL")}");
}
var report = new
{
    SchemaVersion = 1,
    Metadata = new
    {
        Variant = variant,
        CapturedUtc = DateTime.UtcNow,
        Core = AssemblyIdentity(typeof(GameEngine).Assembly),
        Standard = AssemblyIdentity(typeof(StandardContentPackage).Assembly),
        CrossImplementationExclusions = new[] { "ResolutionStack", "Raw Pindian frame fields", "Raw claim/random drafts" }
    },
    Results = results,
    Samples = PindianObservation.Captured
};
File.WriteAllText(output, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"{variant}: {PindianObservation.Captured.Count} observation samples; failures={failures}; output={output}");
return failures == 0 ? 0 : 1;

static object AssemblyIdentity(Assembly assembly) => new
{
    Name = assembly.GetName().Name,
    Sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location))).ToLowerInvariant()
};
