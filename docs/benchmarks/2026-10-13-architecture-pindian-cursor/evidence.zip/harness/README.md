# Pindian differential diagnostic

This is a disposable task-owned diagnostic, not a repository test framework or runner registration. It reuses the three existing public `BoundaryTaiShiCiChecks` methods and their finite seed-7001 fixture exactly. The copied private `Replay` method adds only `PindianObservation.Capture(game)` after all original assertions and same-implementation cold comparison, before returning.

The cross-implementation digest includes five safe viewer snapshots (-1 and seats 0..3), typed event envelopes and payloads, accepted command JSON, revision, checkpoint JSON, existing RNG state, card movements and physical zones. It excludes the raw resolution stack and Pindian drafts whose representation is being changed. Existing test assertions still inspect frame data and compare exact frame JSON within each implementation.

The baseline and candidate DLL directories are fixed snapshots with immutable SHA manifests. The project compiles against the baseline snapshots; the runner copies the same diagnostic executable to two isolated runtime directories and replaces only its two referenced DLLs with each variant. The runner never references or writes the shared verification outputs or repository source.

Run only when the main verification run has finished:

```powershell
pwsh -NoProfile -File 'C:\Users\17917\AppData\Local\Temp\Card-architecture-01a13336\iteration6\harness\run-probe.ps1'
```

No build or diagnostic run was performed during preparation. The script builds one small executable under `iteration6/probe-build`, runs all three methods for baseline and candidate, writes `baseline-observations.json`, `candidate-observations.json`, `probe-comparison.json`, and build/run logs in iteration6. Its exclusive `.probe.lock` prevents concurrent probe consumers. `try/finally` removes only its owned `probe-build` and `probe-runtime` directories after both runs, rejecting linked or unowned paths. Cleanup failures are registered individually with the existing cleanup tool without running the historical queue.

Retain `before.zip`, SHA manifests, baseline/candidate DLL snapshots, harness source and the observation/comparison evidence until the root agent has inspected the comparison and finished its recovery/closeout work. Root owns their later task-scoped cleanup. The only generated binary/obj/runtime outputs are automatically disposable. This harness does not add a new ordinary-claim fixture; root's existing relevant Core filters cover ordinary Pindian claims.
