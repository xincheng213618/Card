using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using CardGame.Core;

internal static class PindianObservation
{
    private static readonly List<ObservationSample> Samples = [];
    private static string _scenario = "unassigned";
    private static int _ordinal;
    public static IReadOnlyList<ObservationSample> Captured => Samples;

    public static void Begin(string scenario)
    {
        _scenario = scenario;
        _ordinal = 0;
    }

    public static void Capture(GameEngine game)
    {
        // Cross-implementation comparison intentionally excludes ResolutionStack
        // and raw Pindian frame/draft fields. The copied test still compares its
        // exact frame JSON when restoring within the same implementation.
        var observation = JsonSerializer.SerializeToElement(new
        {
            game.Revision,
            ContentHash = game.ContentRegistry.ContentHash,
            Views = Enumerable.Range(-1, 5)
                .Select(viewer => new { Viewer = viewer, Json = SnapshotJson.Serialize(game.CreateSnapshot(viewer)) })
                .ToArray(),
            Events = game.Events.Select(envelope => new
            {
                envelope.Id, envelope.ParentId, envelope.Sequence, envelope.Revision, envelope.CorrelationId,
                PayloadType = envelope.Payload.GetType().FullName,
                Payload = JsonSerializer.SerializeToElement(envelope.Payload, envelope.Payload.GetType())
            }).ToArray(),
            Commands = CommandJson.Serialize(game.AcceptedCommands),
            Checkpoint = GameCheckpointJson.Serialize(game.CreateCheckpoint()),
            RandomState = ReadRandomState(game),
            game.CardMovements,
            Zones = game.CreateCardZoneDiagnostics()
        });
        var digest = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(observation.GetRawText()))).ToLowerInvariant();
        Samples.Add(new(_scenario, ++_ordinal, digest, observation));
    }

    private static uint ReadRandomState(GameEngine game)
    {
        var random = typeof(GameEngine).GetField("_random", BindingFlags.Instance | BindingFlags.NonPublic)
            ?.GetValue(game) ?? throw new InvalidOperationException("Existing RNG field was not found.");
        return (uint)(random.GetType().GetProperty("State", BindingFlags.Instance | BindingFlags.Public)
            ?.GetValue(random) ?? throw new InvalidOperationException("Existing RNG state was not found."));
    }

    public sealed record ObservationSample(string Scenario, int Ordinal, string Digest, JsonElement Observation);
}
