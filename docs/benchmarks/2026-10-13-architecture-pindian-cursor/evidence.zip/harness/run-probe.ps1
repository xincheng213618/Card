[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$taskId = '01a13336-b0c2-7472-a49f-7e3458841d28'
$repository = 'C:\Users\17917\Desktop\Card'
$iterationRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot)).TrimEnd([IO.Path]::DirectorySeparatorChar)
$expectedOwner = "$taskId iteration6 Pindian differential diagnostic; $repository"
if ((Get-Content -LiteralPath (Join-Path $iterationRoot '.owner') -Raw).Trim() -ne $expectedOwner) { throw 'Iteration6 owner mismatch.' }
if ((Get-Item -LiteralPath $iterationRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Iteration6 root is linked.' }
$buildRoot = Join-Path $iterationRoot 'probe-build'
$runtimeRoot = Join-Path $iterationRoot 'probe-runtime'
$generatedOwner = "$taskId Pindian probe disposable outputs"
$lockPath = Join-Path $iterationRoot '.probe.lock'
$lock = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)

function Assert-TaskPath([string] $Path) {
    $absolute = [IO.Path]::GetFullPath($Path).TrimEnd([IO.Path]::DirectorySeparatorChar)
    $prefix = $iterationRoot + [IO.Path]::DirectorySeparatorChar
    if (-not $absolute.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Not strictly inside iteration6: $absolute" }
    for ($cursor = [IO.DirectoryInfo]::new($absolute); $null -ne $cursor -and $cursor.FullName.Length -ge $iterationRoot.Length; $cursor = $cursor.Parent) {
        if ($cursor.Exists -and ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Linked path: $($cursor.FullName)" }
    }
    return $absolute
}

function Ensure-DisposableDirectory([string] $Path) {
    $absolute = Assert-TaskPath $Path
    if (Test-Path -LiteralPath $absolute) {
        $marker = Join-Path $absolute '.owner'
        if (-not (Test-Path -LiteralPath $marker) -or (Get-Content -LiteralPath $marker -Raw).Trim() -ne $generatedOwner) { throw "Output ownership mismatch: $absolute" }
    } else {
        [IO.Directory]::CreateDirectory($absolute) | Out-Null
        $generatedOwner | Set-Content -LiteralPath (Join-Path $absolute '.owner') -Encoding utf8
    }
}

function Remove-DisposableDirectory([string] $Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $absolute = Assert-TaskPath $Path
    $marker = Join-Path $absolute '.owner'
    if (-not (Test-Path -LiteralPath $marker) -or (Get-Content -LiteralPath $marker -Raw).Trim() -ne $generatedOwner) { throw "Refusing cleanup without exact ownership: $absolute" }
    $links = @(Get-ChildItem -LiteralPath $absolute -Force -Recurse | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })
    if ($links.Count -gt 0) { throw "Refusing cleanup of linked descendants: $absolute" }
    try {
        Remove-Item -LiteralPath $absolute -Recurse -Force
    } catch {
        $reason = "Pindian probe cleanup failed; no retry was attempted: $($_.Exception.Message)"
        & python -B (Join-Path $repository 'tools\cleanup_temp.py') --add $absolute --root $iterationRoot --lock-root $iterationRoot --reason $reason
        Write-Warning "$reason Retained: $absolute"
    }
}

function Snapshot-Dlls([string] $Variant) {
    $snapshot = Assert-TaskPath (Join-Path $iterationRoot $Variant)
    $manifest = Get-Content -LiteralPath (Join-Path $iterationRoot "$Variant-dll-sha256.json") -Raw | ConvertFrom-Json
    $entries = @()
    foreach ($filename in @('CardGame.Core.dll', 'CardGame.Content.Standard.dll')) {
        $path = Join-Path $snapshot $filename
        $entry = @($manifest.files | Where-Object { [IO.Path]::GetFileName($_.copy) -eq $filename })
        if ($entry.Count -ne 1 -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry[0].sha256) { throw "Snapshot hash mismatch: $path" }
        $entries += [pscustomobject]@{ Path = $path; File = $filename; Sha256 = $entry[0].sha256 }
    }
    return $entries
}

$runtimeCreated = $false
$buildCreated = $false
try {
    $baseline = @(Snapshot-Dlls 'baseline')
    $candidate = @(Snapshot-Dlls 'candidate')
    Ensure-DisposableDirectory $buildRoot
    $buildCreated = $true
    Ensure-DisposableDirectory $runtimeRoot
    $runtimeCreated = $true
    $buildLog = Join-Path $iterationRoot 'probe-build.log'
    & dotnet build (Join-Path $PSScriptRoot 'PindianProbe.csproj') -c Release --artifacts-path $buildRoot 2>&1 | Tee-Object -FilePath $buildLog
    if ($LASTEXITCODE -ne 0) { throw "Probe build failed; see $buildLog" }
    $binaries = @(Get-ChildItem -LiteralPath (Join-Path $buildRoot 'bin\PindianProbe') -Filter 'CardGame.PindianProbe.dll' -File -Recurse)
    if ($binaries.Count -ne 1) { throw 'Expected exactly one built diagnostic executable.' }
    $binaryRoot = $binaries[0].DirectoryName
    $runFailures = @()
    foreach ($variant in @('baseline', 'candidate')) {
        $entries = if ($variant -eq 'baseline') { $baseline } else { $candidate }
        $runRoot = Assert-TaskPath (Join-Path $runtimeRoot $variant)
        [IO.Directory]::CreateDirectory($runRoot) | Out-Null
        foreach ($file in Get-ChildItem -LiteralPath $binaryRoot -File) { Copy-Item -LiteralPath $file.FullName -Destination $runRoot -Force }
        foreach ($entry in $entries) {
            $destination = Join-Path $runRoot $entry.File
            Copy-Item -LiteralPath $entry.Path -Destination $destination -Force
            if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Sha256 -or
                (Get-FileHash -LiteralPath $entry.Path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Sha256) { throw 'Snapshot changed during isolated copy.' }
        }
        $output = Join-Path $iterationRoot "$variant-observations.json"
        $runLog = Join-Path $iterationRoot "probe-$variant.log"
        & dotnet (Join-Path $runRoot 'CardGame.PindianProbe.dll') --variant $variant --output $output 2>&1 | Tee-Object -FilePath $runLog
        if ($LASTEXITCODE -ne 0) { $runFailures += $variant }
    }
    & (Join-Path $PSScriptRoot 'compare-probe.ps1')
    if ($runFailures.Count -gt 0) { throw "Original test assertions failed in: $($runFailures -join ', ')" }
} finally {
    if ($runtimeCreated) { Remove-DisposableDirectory $runtimeRoot }
    if ($buildCreated) { Remove-DisposableDirectory $buildRoot }
    $lock.Dispose()
    if (Test-Path -LiteralPath $lockPath) { Remove-Item -LiteralPath $lockPath -Force }
}
