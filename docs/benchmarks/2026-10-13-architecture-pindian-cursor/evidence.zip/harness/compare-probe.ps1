[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$iterationRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$baselinePath = Join-Path $iterationRoot 'baseline-observations.json'
$candidatePath = Join-Path $iterationRoot 'candidate-observations.json'
$baseline = Get-Content -LiteralPath $baselinePath -Raw | ConvertFrom-Json
$candidate = Get-Content -LiteralPath $candidatePath -Raw | ConvertFrom-Json
if ($baseline.SchemaVersion -ne 1 -or $candidate.SchemaVersion -ne 1) { throw 'Unknown probe report format.' }
$baselineKeys = @($baseline.Samples | ForEach-Object { "$($_.Scenario)/$($_.Ordinal)/$($_.Digest)" })
$candidateKeys = @($candidate.Samples | ForEach-Object { "$($_.Scenario)/$($_.Ordinal)/$($_.Digest)" })
$sameCount = $baselineKeys.Count -eq $candidateKeys.Count
$difference = @()
for ($index = 0; $index -lt [Math]::Max($baselineKeys.Count, $candidateKeys.Count); $index++) {
    $before = if ($index -lt $baselineKeys.Count) { $baselineKeys[$index] } else { $null }
    $after = if ($index -lt $candidateKeys.Count) { $candidateKeys[$index] } else { $null }
    if ($before -ne $after) { $difference += [ordered]@{ index = $index; baseline = $before; candidate = $after } }
}
$baselineFailures = @($baseline.Results | Where-Object { -not $_.Passed })
$candidateFailures = @($candidate.Results | Where-Object { -not $_.Passed })
$report = [ordered]@{
    baseline = $baselinePath; candidate = $candidatePath
    baselineSamples = $baselineKeys.Count; candidateSamples = $candidateKeys.Count
    originalAssertionsPassed = $baselineFailures.Count -eq 0 -and $candidateFailures.Count -eq 0
    exactExistingObservationDigestsMatch = $sameCount -and $difference.Count -eq 0
    excludedFromCrossImplementationComparison = @('ResolutionStack', 'Raw Pindian frame/claim/random drafts', 'Build metadata and elapsed time')
    differences = $difference
}
$output = Join-Path $iterationRoot 'probe-comparison.json'
$report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $output -Encoding utf8
$report | ConvertTo-Json -Depth 5
if (-not $report.originalAssertionsPassed -or -not $report.exactExistingObservationDigestsMatch) { throw "Pindian differential diagnostic differs; inspect $output and the paired observation JSON files." }
