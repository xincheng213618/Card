param([ValidateSet('focused','routine')][string]$Mode='focused')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/17917/Desktop/Card'
$taskDir='C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336/iteration16'
$verification='C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336/verification'
$paths=@(& rg --files src tests tools -g '*.cs' -g '*.csproj' -g '*.json' -g '*.xaml' -g '*.resx' -g '*.ps1' -g '*.psd1' -g '*.props' -g '*.targets')
$paths+=@(& rg --files -g '*.sln' -g 'Directory.Build.*' -g 'global.json' -g 'NuGet.Config')
$paths=@($paths | Sort-Object -Unique)
function Get-Hashes { @($paths | ForEach-Object {[ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_).Hash}}) }
$before=Get-Hashes
$before | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$taskDir/$Mode-input-hashes.json" -Encoding utf8
Copy-Item -LiteralPath 'tools/Test-Changed.ps1' -Destination "$taskDir/Test-Changed.invoked.ps1"
Copy-Item -LiteralPath 'tools/VerificationScopes.psd1' -Destination "$taskDir/VerificationScopes.invoked.psd1"
if($Mode -eq 'focused') {
    & ./tools/Test-Changed.ps1 -CoreFilter @('Actual hand gains and category gifts:','Rice pile:','Incoming distance courtesy:','committed event collections reject observer mutation','prepared snapshot rejects observer collection mutation','program state projection preserves empty and live policy JSON','public pile projection preserves empty and live queries','Extra card effect and rank guess: rank equality public reveal and paid child cold') -WpfFilter @('Program deferred cards preserve private views and public pile ownership','Program public pile exchange restores optional count and public faces','Program public rule states restore quota limit and self prohibition') -ArtifactsPath $verification -Verbose
} else {
    & ./tools/Test-Changed.ps1 -ArtifactsPath $verification -Verbose
}
$code=$LASTEXITCODE
$summary=Get-Content -LiteralPath "$verification/summary.json" -Raw | ConvertFrom-Json
Copy-Item -LiteralPath "$verification/summary.json" -Destination "$taskDir/$Mode-summary.json"
foreach($step in $summary.results) {
    $kind=if($step.name -eq 'Build selected scope'){'build'}elseif($step.name -like 'Core*'){'core'}elseif($step.name -like 'WPF*'){'wpf'}else{$null}
    if($kind){Copy-Item -LiteralPath $step.log -Destination "$taskDir/$Mode-$kind.log"}
}
$after=Get-Hashes
$after | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$taskDir/$Mode-final-input-hashes.json" -Encoding utf8
$lookup=@{}
foreach($item in $before){$lookup[$item.path]=$item.sha256}
[ordered]@{inputCount=$before.Count;changedDuringRun=@($after | Where-Object {$_.sha256 -ne $lookup[$_.path]})} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$taskDir/$Mode-source-drift.json" -Encoding utf8
exit $code

