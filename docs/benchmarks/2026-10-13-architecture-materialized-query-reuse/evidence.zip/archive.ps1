$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/17917/Desktop/Card'
$taskRoot=[IO.Path]::GetFullPath('C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336')
$taskDir=Join-Path $taskRoot 'iteration16'
$deliverable=[IO.Path]::GetFullPath('docs/benchmarks/2026-10-13-architecture-materialized-query-reuse')
$routine=Get-Content -LiteralPath "$taskDir/routine-summary.json" -Raw | ConvertFrom-Json
if($routine.status -notin @('passed','test-failed') -or $routine.mode -ne 'routine'){throw 'Unexpected verification state'}
$owned=Get-Content -LiteralPath "$taskDir/owned-source-changes.json" -Raw | ConvertFrom-Json
$inputs=Get-Content -LiteralPath "$taskDir/routine-input-hashes.json" -Raw | ConvertFrom-Json
$final=Get-Content -LiteralPath "$taskDir/routine-final-input-hashes.json" -Raw | ConvertFrom-Json
$lookup=@{}; foreach($item in $inputs){$lookup[$item.path]=$item.sha256}
$endLookup=@{}; foreach($item in $final){$endLookup[$item.path]=$item.sha256}
$proof=@(foreach($item in $owned){
    $key=$item.path.Replace('/','\')
    $current=(Get-FileHash -LiteralPath $item.path).Hash
    if($current -ne $item.afterSHA256 -or $lookup[$key] -ne $current -or $endLookup[$key] -ne $current){throw "Owned source drift: $key"}
    [ordered]@{path=$item.path;sha256=$current;matchesVerifiedInput=$true;matchesVerifiedFinal=$true}
})
$proof | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$taskDir/owned-verification-proof.json" -Encoding utf8
$paths=@(& rg --files src tests tools -g '*.cs' -g '*.csproj' -g '*.json' -g '*.xaml' -g '*.resx' -g '*.ps1' -g '*.psd1' -g '*.props' -g '*.targets')
$paths+=@(& rg --files -g '*.sln' -g 'Directory.Build.*' -g 'global.json' -g 'NuGet.Config')
$paths=@($paths | Sort-Object -Unique)
$newPaths=@($paths | Where-Object {!$lookup.ContainsKey($_)})
$missingPaths=@($inputs.path | Where-Object {!(Test-Path -LiteralPath $_)})
$currentDrift=@(foreach($path in $paths){if($lookup.ContainsKey($path)){$hash=(Get-FileHash -LiteralPath $path).Hash; if($hash -ne $lookup[$path]){[ordered]@{path=$path;sha256=$hash}}}})
[ordered]@{capturedInputs=$inputs.Count;currentInputs=$paths.Count;newInputs=$newPaths;missingInputs=$missingPaths;changedSinceVerifiedInput=$currentDrift} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$taskDir/final-input-discovery.json" -Encoding utf8
$files=@(Get-ChildItem -LiteralPath $taskDir -File -Recurse -Force | Sort-Object FullName)
$manifest=@(foreach($file in $files){if($file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked evidence'}; [ordered]@{path=[IO.Path]::GetRelativePath($taskDir,$file.FullName).Replace('\','/');length=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}})
$manifest | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$deliverable/evidence-manifest.json" -Encoding utf8
$zipPath=Join-Path $deliverable 'evidence.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Preserve existing archive before update'}
[IO.Compression.ZipFile]::CreateFromDirectory($taskDir,$zipPath,[IO.Compression.CompressionLevel]::Optimal,$false)
$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{
    if($zip.Entries.Count -ne $manifest.Count){throw 'Archive count mismatch'}
    foreach($item in $manifest){
        $entry=$zip.GetEntry($item.path)
        if($null -eq $entry -or $entry.Length -ne $item.length){throw 'Archive entry mismatch'}
        $stream=$entry.Open()
        try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
        if($hash -ne $item.sha256){throw "Archive hash mismatch: $($item.path)"}
    }
}finally{$zip.Dispose()}
$counts=[regex]::Match((Get-Content -LiteralPath "$taskDir/routine-core.log" -Raw),'(\d+) passed, (\d+) failed, (\d+) skipped \((\d+) total\)')
$wpfCounts=[regex]::Match((Get-Content -LiteralPath "$taskDir/routine-wpf.log" -Raw),'(\d+) WPF checks passed, (\d+) failed')
if(!$counts.Success -or !$wpfCounts.Success){throw 'Missing actual check counts'}
$summary=[ordered]@{
    generatedAt=[DateTimeOffset]::Now.ToString('O')
    structural=Get-Content -LiteralPath "$taskDir/structural-results.json" -Raw | ConvertFrom-Json
    ownedInputs=$proof
    focused=Get-Content -LiteralPath "$taskDir/initial-focused-summary.json" -Raw | ConvertFrom-Json
    uiRepairRecheck=Get-Content -LiteralPath "$taskDir/recheck-summary.json" -Raw | ConvertFrom-Json
    initialRoutine=Get-Content -LiteralPath "$taskDir/initial-routine-failures.json" -Raw | ConvertFrom-Json
    concurrentCoreRecheck=Get-Content -LiteralPath "$taskDir/core-recheck-summary.json" -Raw | ConvertFrom-Json
    routine=[ordered]@{corePassed=[int]$counts.Groups[1].Value;coreFailed=[int]$counts.Groups[2].Value;wpfPassed=[int]$wpfCounts.Groups[1].Value;wpfFailed=[int]$wpfCounts.Groups[2].Value;run=$routine;parallelScopes=$true}
    drift=Get-Content -LiteralPath "$taskDir/routine-source-drift.json" -Raw | ConvertFrom-Json
    discovery=Get-Content -LiteralPath "$taskDir/final-input-discovery.json" -Raw | ConvertFrom-Json
    evidence=[ordered]@{path=$zipPath;files=$manifest.Count;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Get-FileHash -LiteralPath $zipPath).Hash;allEntryHashesVerified=$true}
    cleanup=[ordered]@{taskRoot=$taskRoot;taskTemporaryPath=$taskDir;newBuildOutputDirectories=0;blockedDeletionRetried=$false;verificationReasonsRestored=$true;disposableTaskEvidence='archive verified; cleanup pending'}
    limits=@('No manual Full','No foreground desktop acceptance','No isolated time or allocation-byte performance claim','Three-Slash display folding has static equivalence evidence rather than a direct registered scenario','Concurrent changes excluded from own diff attribution')
}
$summary | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath "$deliverable/summary.json" -Encoding utf8
[ordered]@{archive=$summary.evidence;routine=$summary.routine | Select-Object corePassed,coreFailed,wpfPassed,wpfFailed;durationMs=$routine.durationMs;inputs=$inputs.Count} | ConvertTo-Json -Depth 4
