$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'C:/Users/17917/Desktop/Card'
$taskRoot = [IO.Path]::GetFullPath('C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336')
$taskDir = Join-Path $taskRoot 'iteration10'
$deliverable = [IO.Path]::GetFullPath('docs/benchmarks/2026-10-13-architecture-empty-bindings')
$routine = Get-Content -LiteralPath (Join-Path $taskDir 'routine-summary.json') -Raw | ConvertFrom-Json
$failures = @(foreach ($kind in @('core','wpf')) {
    $lines = Get-Content -LiteralPath (Join-Path $taskDir "routine-$kind.log")
    for ($i=0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '\[FAIL\]') {
            [ordered]@{scope=$kind;failure=$lines[$i];detail=$lines[$i+1]}
        }
    }
})
$failures | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $taskDir 'final-routine-failures.json') -Encoding utf8
$queue = Get-Content -LiteralPath 'tools/cleanup_queue.json' -Raw | ConvertFrom-Json
$entries = @($queue.entries | Where-Object { [IO.Path]::GetFullPath($_.path).StartsWith($taskRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) })
$entries | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskDir 'cleanup-registrations.json') -Encoding utf8
$files = @(Get-ChildItem -LiteralPath $taskDir -Recurse -File -Force | Where-Object {
    -not $_.FullName.StartsWith((Join-Path $taskDir 'allocation-probe-output')+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)
} | Sort-Object FullName)
$manifest = @(foreach ($file in $files) {
    if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked evidence file' }
    [ordered]@{path=[IO.Path]::GetRelativePath($taskDir,$file.FullName).Replace('\','/');length=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}
})
$manifest | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $deliverable 'evidence-manifest.json') -Encoding utf8
$zipPath = Join-Path $deliverable 'evidence.zip'
if (Test-Path -LiteralPath $zipPath) { throw 'Evidence archive already exists; preserve it before choosing an update.' }
$stream = [IO.File]::Open($zipPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try {
    $zip = [IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try { foreach ($file in $files) {
        $relative = [IO.Path]::GetRelativePath($taskDir,$file.FullName).Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$relative,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }} finally { $zip.Dispose() }
} finally { $stream.Dispose() }
$verify = [IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    if ($verify.Entries.Count -ne $manifest.Count) { throw 'Archive count mismatch' }
    foreach ($item in $manifest) {
        $entry = $verify.GetEntry($item.path)
        if ($null -eq $entry -or $entry.Length -ne $item.length) { throw 'Archive entry mismatch' }
        $read = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($read)) } finally { $read.Dispose() }
        if ($hash -ne $item.sha256) { throw "Archive hash mismatch: $($item.path)" }
    }
} finally { $verify.Dispose() }
$rootSize = Get-ChildItem -LiteralPath $taskRoot -Recurse -File -Force | Measure-Object -Property Length -Sum
$summary = [ordered]@{
    generatedAt=[DateTimeOffset]::Now.ToString('O')
    production=Get-Content -LiteralPath (Join-Path $taskDir 'structural-results.json') -Raw | ConvertFrom-Json
    ownedSources=Get-Content -LiteralPath (Join-Path $taskDir 'owned-final-source-hashes.json') -Raw | ConvertFrom-Json
    allocation=Get-Content -LiteralPath (Join-Path $taskDir 'allocation-comparison.json') -Raw | ConvertFrom-Json
    focused=Get-Content -LiteralPath (Join-Path $taskDir 'focused-summary.json') -Raw | ConvertFrom-Json
    phaseAndArchitectureRecheck=Get-Content -LiteralPath (Join-Path $taskDir 'integration-recheck-summary.json') -Raw | ConvertFrom-Json
    openingRecheck=Get-Content -LiteralPath (Join-Path $taskDir 'opening-recheck-summary.json') -Raw | ConvertFrom-Json
    captureRecheck=Get-Content -LiteralPath (Join-Path $taskDir 'capture-recheck-summary.json') -Raw | ConvertFrom-Json
    finalRoutine=[ordered]@{status=$routine.status;mode=$routine.mode;corePassed=554;coreFailed=2;coreTotal=556;wpfPassed=75;wpfFailed=0;durationMs=$routine.durationMs;parallelScopes=$true;steps=$routine.results;failures=$failures}
    sourceDrift=Get-Content -LiteralPath (Join-Path $taskDir 'routine-source-drift.json') -Raw | ConvertFrom-Json
    discoveredInputs=Get-Content -LiteralPath (Join-Path $taskDir 'final-input-discovery.json') -Raw | ConvertFrom-Json
    cleanup=[ordered]@{retainedRoot=$taskRoot;rootBytes=$rootSize.Sum;probe=Get-Content -LiteralPath (Join-Path $taskDir 'probe-cleanup-result.json') -Raw | ConvertFrom-Json;blockedDeletionRetried=$false;verificationReasonsRestored=$true;taskConsumersComplete=$true}
    evidence=[ordered]@{path=$zipPath;files=$manifest.Count;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Get-FileHash -LiteralPath $zipPath).Hash;allEntryHashesVerified=$true}
    limits=@('No Full verification','No foreground hardware acceptance','Two named-ambush feature checks remain failing','No whole-tree green claim after concurrent fixture edits','No causal routine-speed claim')
}
$summary | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath (Join-Path $deliverable 'summary.json') -Encoding utf8
[ordered]@{status=$routine.status;core='554 passed / 2 failed';wpf='75 passed / 0 failed';durationMs=$routine.durationMs;evidence=$summary.evidence;retainedBytes=$rootSize.Sum} | ConvertTo-Json -Depth 4
