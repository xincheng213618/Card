$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:\Users\17917\Desktop\Card'
& ./tools/Test-Changed.ps1 -CoreFilter @('match skill binding sources preserve instance and unique-program semantics','empty binding queries preserve exact states and issued obligations','content registry compiles whole catalog dependencies','execution plans') -ArtifactsPath 'C:\Users\17917\AppData\Local\Temp\Card-architecture-01a13336\verification' -Verbose
