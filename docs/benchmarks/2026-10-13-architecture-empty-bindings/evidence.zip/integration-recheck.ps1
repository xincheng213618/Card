$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/17917/Desktop/Card'
$taskDir='C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336/iteration10'
$verification='C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336/verification'
& ./tools/Test-Changed.ps1 -CoreFilter @('match skill binding sources preserve instance and unique-program semantics','empty binding queries preserve exact states and issued obligations','content registry compiles whole catalog dependencies','execution plans','Phase start card control:') -ArtifactsPath $verification -Verbose
$code=$LASTEXITCODE
$summary=Get-Content -LiteralPath "$verification/summary.json" -Raw | ConvertFrom-Json
Copy-Item -LiteralPath "$verification/summary.json" -Destination "$taskDir/integration-recheck-summary.json"
foreach($step in $summary.results) {
    $name=if($step.name -eq 'Build selected scope'){'build'}elseif($step.name -like 'Core*'){'core'}else{$null}
    if($name){Copy-Item -LiteralPath $step.log -Destination "$taskDir/integration-recheck-$name.log"}
}
exit $code
