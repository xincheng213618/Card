using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
var path = Path.GetFullPath(args[0]);
var assembly = Assembly.LoadFrom(path);
var shard = assembly.GetType("CardGame.Core.SkillBindingShard", true)!;
var stampType = assembly.GetType("CardGame.Core.SkillBindingIndexStamp", true)!;
var create = shard.GetMethod("Empty", BindingFlags.NonPublic | BindingFlags.Static)!;
object?[] arguments = [0, Activator.CreateInstance(stampType)];
for (var i = 0; i < 128; i++) _ = create.Invoke(null, arguments);
var samples = new List<object>();
for (var sample = 0; sample < 8; sample++) {
    var allocated = GC.GetAllocatedBytesForCurrentThread();
    var start = Stopwatch.GetTimestamp();
    for (var i = 0; i < 1000; i++) _ = create.Invoke(null, arguments);
    var elapsed = Stopwatch.GetElapsedTime(start).TotalMilliseconds;
    var bytes = GC.GetAllocatedBytesForCurrentThread() - allocated;
    samples.Add(new { Milliseconds = elapsed, AllocatedBytes = bytes, BytesPerShard = bytes / 1000d });
}
var result = new { Runtime = Environment.Version.ToString(), Assembly = path,
    AssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))),
    CallsPerSample = 1000, Samples = samples,
    Scope = "Internal Empty factory through the same warmed reflection invocation; not real match or screen performance." };
var json = JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
File.WriteAllText(args[1], json);
Console.WriteLine(json);
