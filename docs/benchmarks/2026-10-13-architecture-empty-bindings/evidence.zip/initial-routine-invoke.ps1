$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'C:/Users/17917/Desktop/Card'
$taskDir = 'C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336/iteration10'
$verification = 'C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336/verification'
$paths = @(& rg --files src tests tools -g '*.cs' -g '*.csproj' -g '*.json' -g '*.xaml' -g '*.resx' -g '*.ps1' -g '*.psd1' -g '*.props' -g '*.targets')
$paths += @(& rg --files -g '*.sln' -g 'Directory.Build.*' -g 'global.json' -g 'NuGet.Config')
$paths = @($paths | Sort-Object -Unique)
function Get-InputHashes {
    @($paths | ForEach-Object { [ordered]@{ path = $_; sha256 = (Get-FileHash -LiteralPath $_).Hash } })
}
$before = Get-InputHashes
$before | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$taskDir/routine-input-hashes.json" -Encoding utf8
Copy-Item -LiteralPath 'tools/Test-Changed.ps1' -Destination "$taskDir/Test-Changed.invoked.ps1"
Copy-Item -LiteralPath 'tools/VerificationScopes.psd1' -Destination "$taskDir/VerificationScopes.invoked.psd1"
Copy-Item -LiteralPath 'src/CardGame.Core/MatchSkillBindingIndex.cs' -Destination "$taskDir/MatchSkillBindingIndex.candidate.cs"
Copy-Item -LiteralPath 'tests/CardGame.Core.Tests/MatchSkillBindingIndexChecks.cs' -Destination "$taskDir/MatchSkillBindingIndexChecks.candidate.cs"
& ./tools/Test-Changed.ps1 -ArtifactsPath $verification -Verbose
$runCode = $LASTEXITCODE
$summary = Get-Content -LiteralPath "$verification/summary.json" -Raw | ConvertFrom-Json
Copy-Item -LiteralPath "$verification/summary.json" -Destination "$taskDir/routine-summary.json"
foreach ($step in $summary.results) {
    $name = if ($step.name -eq 'Build selected scope') { 'build' } elseif ($step.name -like 'Core*') { 'core' } elseif ($step.name -like 'WPF*') { 'wpf' } else { $null }
    if ($name) { Copy-Item -LiteralPath $step.log -Destination "$taskDir/routine-$name.log" }
}
$after = Get-InputHashes
$after | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$taskDir/routine-final-input-hashes.json" -Encoding utf8
$lookup = @{}
foreach ($item in $before) { $lookup[$item.path] = $item.sha256 }
$drift = @($after | Where-Object { $_.sha256 -ne $lookup[$_.path] })
[ordered]@{ inputCount = $before.Count; changedDuringRun = $drift } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$taskDir/routine-source-drift.json" -Encoding utf8
exit $runCode
