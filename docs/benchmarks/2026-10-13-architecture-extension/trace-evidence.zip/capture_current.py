import hashlib
import json
import pathlib
import shutil

root = pathlib.Path(__file__).resolve().parent
mapping = json.loads((root/'copy-map.json').read_text(encoding='utf-8'))
workspace = pathlib.Path(mapping['workspace'])
source = root.parent/'verification/bin/CardGame.Core.Tests/release'
target = root/'current-assemblies'
target.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assemblies = []
for name in ['CardGame.Core.dll', 'CardGame.Content.Standard.dll', 'CardGame.Core.Tests.dll']:
    original = source/name
    initial_hash = sha(original)
    shutil.copy2(original, target/name)
    assert initial_hash == sha(original) == sha(target/name), name
    assemblies.append({'name': name, 'source': str(original), 'sha256': initial_hash,
                       'size': original.stat().st_size, 'lastWriteNanoseconds': original.stat().st_mtime_ns})
changes = []
source_entries = []
for entry in mapping['entries']:
    current = workspace/entry['path']
    current_hash = sha(current) if current.exists() else None
    source_entries.append({'path': entry['path'], 'sha256': current_hash})
    if current_hash != entry['currentSha256']:
        changes.append({'path': entry['path'], 'operation': entry['operation'],
                        'copyTimeSha256': entry['currentSha256'], 'captureTimeSha256': current_hash})
unchanged_operations = {'current'}
unexpected = [change for change in changes if change['operation'] in unchanged_operations]
assert not unexpected, unexpected
report = {'assemblies': assemblies, 'sourceChangesSinceControlCopy': changes,
          'unexpectedSourceChanges': unexpected, 'captureTimeSourceFiles': source_entries}
(root/'current-identity.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({'assemblies': assemblies, 'sourceChangesSinceControlCopy': changes,
                  'unexpectedSourceChanges': unexpected}, indent=2))
