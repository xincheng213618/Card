using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;
using CardGame.Core;

if (args.Length != 2) throw new ArgumentException("Expected tests DLL and output JSON path.");
var tests = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var fixture = tests.GetType("PairedHandRecastChecks", throwOnError: true)!;
var scenarioType = fixture.GetNestedType("Scenario", BindingFlags.NonPublic)!;
var traces = new List<object>();
var activeScenario = "";
var label = "";
var sequence = 0;
GameEngine? observed = null;

object? Invoke(string method, params object?[] arguments)
{
    try { return fixture.GetMethod(method, BindingFlags.Static | BindingFlags.NonPublic)!.Invoke(null, arguments); }
    catch (TargetInvocationException ex) when (ex.InnerException is not null)
    {
        ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
        throw;
    }
}

void Capture(GameEngine game, string boundary)
{
    var checkpoint = game.CreateCheckpoint();
    var random = typeof(GameEngine).GetField("_random", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(game)!;
    traces.Add(new
    {
        Scenario = activeScenario,
        Sequence = sequence++,
        Boundary = boundary,
        game.Revision,
        Prompt = game.PendingDecision is null ? (JsonElement?)null : JsonSerializer.SerializeToElement(game.PendingDecision),
        Commands = JsonDocument.Parse(CommandJson.Serialize(game.AcceptedCommands)).RootElement.Clone(),
        Events = game.Events.Select(envelope => new
        {
            envelope.Id, envelope.ParentId, envelope.Sequence, envelope.Revision, envelope.CorrelationId,
            PayloadType = envelope.Payload.GetType().FullName,
            Payload = JsonSerializer.SerializeToElement(envelope.Payload, envelope.Payload.GetType())
        }).ToArray(),
        Movements = JsonSerializer.SerializeToElement(game.CardMovements),
        Zones = JsonSerializer.SerializeToElement(game.CreateCardZoneDiagnostics()),
        Views = Enumerable.Range(0, 4).Select(seat => new
        {
            Seat = seat,
            View = JsonDocument.Parse(SnapshotJson.Serialize(game.CreateSnapshot(seat))).RootElement.Clone()
        }).ToArray(),
        Checkpoint = JsonDocument.Parse(GameCheckpointJson.Serialize(checkpoint)).RootElement.Clone(),
        RandomState = random.GetType().GetProperty("State", BindingFlags.Instance | BindingFlags.Public)!.GetValue(random)
    });
}

void OnStateChanged(GameSnapshot snapshot)
{
    if (observed is not null) Capture(observed, label + ":committed");
}

void Observe(GameEngine game)
{
    if (observed is not null) observed.StateChanged -= OnStateChanged;
    observed = game;
    game.StateChanged += OnStateChanged;
}

void Step(GameEngine game, string name, Action action)
{
    label = name;
    action();
    Capture(game, name + ":settled");
}

void Cold(ref GameEngine game, ContentRegistry registry, string name)
{
    label = name;
    var next = GameReplay.Restore(GameCheckpointJson.Deserialize(GameCheckpointJson.Serialize(game.CreateCheckpoint())), registry);
    Observe(next);
    game = next;
    Capture(game, name + ":restored");
}

foreach (var scenario in new[] { "Normal", "SourceLoss" })
{
    activeScenario = scenario;
    sequence = 0;
    var pair = ((GameEngine, ContentRegistry))Invoke("Create", Enum.Parse(scenarioType, scenario))!;
    var (game, registry) = pair;
    Observe(game);
    Capture(game, "fixture-ready");
    var ownerCard = game.CreateSnapshot(0).Players[0].Hand[0].Id;
    var partnerCard = game.CreateSnapshot(1).Players[1].Hand[0].Id;
    PairedHandRecastStartedEvent? issued = null;
    Step(game, "begin", () => issued = (PairedHandRecastStartedEvent)Invoke("Begin", game, ownerCard, partnerCard)!);
    Cold(ref game, registry, "cold-partner-choice");
    Step(game, "select-partner", () => Invoke("SelectPartner", game, partnerCard));
    Step(game, "owner-cost", () => Invoke("CostBoundary", game, issued, 0, ownerCard, partnerCard));
    Cold(ref game, registry, "cold-owner-cost");
    Step(game, "continue-owner-cost", () => Invoke("Continue", game));
    if (scenario == "Normal")
    {
        Step(game, "owner-gain", () => Invoke("ReachGain", game, 0));
        Cold(ref game, registry, "cold-owner-gain");
        Step(game, "finish-owner-gain", () => Invoke("FinishGain", game));
    }
    Step(game, "partner-cost", () => Invoke("CostBoundary", game, issued, 1, ownerCard, partnerCard));
    Cold(ref game, registry, "cold-partner-cost");
    Step(game, "continue-partner-cost", () => Invoke("Continue", game));
    Step(game, "partner-gain", () => Invoke("ReachGain", game, 1));
    Cold(ref game, registry, "cold-partner-gain");
    Step(game, "finish-partner-gain", () => Invoke("FinishGain", game));
    Step(game, "return-play", () => Invoke("Play", game));
    Cold(ref game, registry, "cold-completed");
    Console.WriteLine($"{scenario}: {sequence} captured boundaries, revision {game.Revision}, {game.Events.Count} events, {game.AcceptedCommands.Count} accepted commands.");
}

if (observed is not null) observed.StateChanged -= OnStateChanged;
File.WriteAllText(args[1], JsonSerializer.Serialize(traces, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Wrote {traces.Count} boundaries to {args[1]}.");
