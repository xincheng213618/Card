import hashlib
import json
import pathlib
import re
import zipfile

workspace = pathlib.Path(r'C:\Users\17917\Desktop\Card')
root = pathlib.Path(__file__).resolve().parent
target = root / 'source'
root.joinpath('.owner').write_text('Card architecture comparison owned by /root/wpf_submission; root handles cleanup.\n', encoding='utf-8')

excluded = {
    'src/CardGame.Core/GameEngine.ProgramContinuations.cs',
    'src/CardGame.Core/GameEngine.ObserverSubtrees.cs',
    'src/CardGame.Core/ProgramChoiceDrafts.cs',
    'tests/CardGame.Core.Tests/ProgramContinuationChecks.cs',
    'tests/CardGame.Core.Tests/ProgramChoiceDraftChecks.cs',
    'tests/CardGame.Core.Tests/PairedHandRecastChecks.ObserverSubtrees.cs',
}
restored = {
    'src/CardGame.Core/GameEngine.Runtime.cs',
    'src/CardGame.Core/GameEngine.ConfiguredConversions.cs',
    'src/CardGame.Core/GameEngine.DeferredCards.cs',
    'src/CardGame.Core/GameEngine.StrategicPrograms.cs',
    'src/CardGame.Core/GameEngine.CaoRenPrograms.cs',
    'tests/CardGame.Core.Tests/PairedHandRecastChecks.cs',
    'tests/CardGame.Core.Tests/Fame2016ConversionChecks.cs',
    'tests/CardGame.Core.Tests/Fame2016DeferredChecks.cs',
    'tests/CardGame.Core.Tests/BoundaryCaoRenChecks.cs',
}
observers = {
    p.relative_to(workspace).as_posix()
    for p in workspace.joinpath('src/CardGame.Core').glob('*.cs')
    if 'return TryAdvanceObserverSubtree(' in p.read_text(encoding='utf-8-sig')
}
assert len(observers) == 23, len(observers)
restored |= observers
roots = ['src/CardGame.Core', 'src/CardGame.Content.Standard', 'tests/CardGame.Core.Tests', 'tests/Shared']
paths = [workspace/'global.json']
for rel in roots:
    paths += [p for p in workspace.joinpath(rel).rglob('*') if p.is_file()
              and not any(s in {'bin', 'obj', '.git'} for s in p.relative_to(workspace/rel).parts)]
sha = lambda b: hashlib.sha256(b).hexdigest()
entries = []
attribute_count = 0
registration_count = 0
assertion_count = 0
with zipfile.ZipFile(root.parent/'source-before.zip') as z:
    for p in sorted(paths):
        assert not p.is_symlink(), p
        rel = p.relative_to(workspace).as_posix()
        current = p.read_bytes()
        operation = 'current'
        output = current
        if rel in excluded:
            operation = 'excluded architecture addition'
            output = None
        elif rel in restored:
            operation = 'restore architecture baseline'
            output = z.read(rel)
        elif p.suffix == '.cs':
            content = current.decode('utf-8-sig')
            if rel.startswith('src/CardGame.Core/'):
                content, n = re.subn(r'^[ \t]*\[ProgramContinuation\(ProgramContinuationKind\.\w+,\s*\d+\)\]\r?\n', '', content, flags=re.M)
                attribute_count += n
                if n: operation = f'remove {n} continuation attribute(s)'
            if rel == 'src/CardGame.Core/GameEngine.SkillPrograms.cs':
                content, n = re.subn(r'^[ \t]*AssertParticipantTopView\(frame, paused\);\r?\n', '', content, flags=re.M)
                assert n == 1, n
                assertion_count += n
                operation = 'remove participant draft assertion'
            if rel == 'tests/CardGame.Core.Tests/Program.cs':
                content, n = re.subn(r'^[^\r\n]*(?:ProgramContinuationChecks\.OrderedRegistrationPreservesReturnBoundaries|PairedHandRecastChecks\.ObserverSubtreeRejectsUnrelatedEdgesAndResumesExactlyOnce|ProgramChoiceDraftChecks\.MultiStepBindingsPrivacyAndReplay)[^\r\n]*\r?\n', '', content, flags=re.M)
                assert n == 3, n
                registration_count += n
                operation = 'remove three architecture checks'
            if operation != 'current':
                output = content.encode('utf-8')
        if output is not None:
            dst = target/rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(output)
            assert sha(dst.read_bytes()) == sha(output)
        if operation == 'current':
            assert sha(output) == sha(current), rel
        entries.append({'path': rel, 'operation': operation, 'currentSha256': sha(current),
                        'controlSha256': sha(output) if output is not None else None})

assert excluded <= {e['path'] for e in entries}
assert restored <= {e['path'] for e in entries}
assert attribute_count == 160, attribute_count
assert assertion_count == 1 and registration_count == 3
for rel in ['src/CardGame.Core/Replay.cs', 'src/CardGame.Core/GameEngine.cs', 'src/CardGame.Core/SkillPrograms.cs']:
    assert next(e for e in entries if e['path'] == rel)['operation'] == 'current'
report = {'workspace': str(workspace), 'source': str(target), 'restored': sorted(restored),
          'excluded': sorted(excluded), 'observers': sorted(observers), 'attributesRemoved': attribute_count,
          'entries': entries}
root.joinpath('copy-map.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'copiedFiles': sum(e['controlSha256'] is not None for e in entries),
                  'restoredFiles': len(restored), 'excludedFiles': len(excluded),
                  'attributesRemoved': attribute_count, 'map': str(root/'copy-map.json')}, indent=2))
