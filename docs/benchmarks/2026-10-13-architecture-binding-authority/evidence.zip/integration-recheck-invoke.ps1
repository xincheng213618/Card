$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:\Users\17917\Desktop\Card'
& ./tools/Test-Changed.ps1 -CoreFilter @('Sole target protection:','match skill binding sources preserve instance and unique-program semantics','execution plans','content registry compiles whole catalog dependencies','skill executor preserves continuation metadata and immutable definition checks') -ArtifactsPath 'C:\Users\17917\AppData\Local\Temp\Card-architecture-01a13336\verification' -Verbose
