namespace CardGame.Core;

public sealed partial class GameEngine
{
    private const string HengyeSkillId = "mou:hengye";
    private const string HengyeGrowthUsageId = "growth";
    private const string YingboSkillId = "mou:yingbo";
    private const string RoundDamageCardHistorySkillId = "system:round-damage-card-history";
    private const string RoundDamageCardUsagePrefix = "card-name";

    private readonly HashSet<int> _roundTurnSeats = [];
    private int _roundNumber;
    private YingboGiftHandle? ActiveYingboGift
    {
        get => FindCardContinuationOwner(state => state.YingboGift?.Active == true) is { } id ? new(this, id) : null;
        set
        {
            var id = value?.OwnerFrameId ?? FindCardContinuationOwner(state => state.YingboGift?.Active == true);
            if (id is { } owner) UpdateCardContinuations(owner, state => state with
                { YingboGift = state.YingboGift is { } current ? current with { Active = value is not null } : null });
        }
    }

    private bool UsesFormalMouLuMeng =>
        HasClassicGeneralPackage;

    private void BeginRoundForTurn(CharacterState current)
    {
        if ((!UsesFormalMouLuMeng && !_contentRegistry.ProgramDependencies.UsesRoundTracking) ||
            _turnProgression.Kind == ActualTurnKind.Extra) return;

        if (_roundNumber == 0 || _roundTurnSeats.Contains(current.Seat))
        {
            ReturnDemonRoundHolds();
            _roundNumber++;
            _roundTurnSeats.Clear();
            _skillRuntimeState.ResetRound();
            AdvanceEventRulesAndQueueFact(new RoundStartedEvent(_roundNumber, current.Seat));
            AddLog("RoundStarted", $"第 {_roundNumber} 轮开始。", current.Seat);
        }

        _roundTurnSeats.Add(current.Seat);
    }

    private static bool IsDamageCardKind(CardKind kind) => kind is
        CardKind.Slash or CardKind.FireSlash or CardKind.ThunderSlash or
        CardKind.Duel or CardKind.BarbarianAssault or CardKind.ArrowBarrage or
        CardKind.FireAttack;

    private static string GetRoundDamageCardUsageId(CardKind kind) =>
        $"{RoundDamageCardUsagePrefix}.{kind}";

    private void RecordYingboCardUse(long resolutionId, int sourceSeat, CardKind cardKind)
    {
        if (!UsesFormalMouLuMeng || !IsDamageCardKind(cardKind)) return;

        var usageId = GetRoundDamageCardUsageId(cardKind);
        var wasUsedEarlier = _players.Any(player =>
            _skillRuntimeState.GetUsage(
                player.Seat,
                RoundDamageCardHistorySkillId,
                usageId,
                SkillUsageScope.Round) > 0);
        var source = _players[sourceSeat];
        if (source.IsAlive && HasRuntimeSkill(source, YingboSkillId))
        {
            if (wasUsedEarlier)
                TryMarkYingboRepeated(resolutionId);
            else
                TryMarkYingboUnrespondable(resolutionId);

            AdvanceEventRulesAndQueueFact(new YingboCardModeEvent(
                resolutionId,
                sourceSeat,
                cardKind,
                wasUsedEarlier,
                CannotBeRespondedTo: !wasUsedEarlier,
                ConvertsDamageToFire: wasUsedEarlier,
                DamageBonus: wasUsedEarlier ? 1 : 0));
            AddLog(
                "SkillTriggered",
                wasUsedEarlier
                    ? $"{source.Name} 的【英博】令本轮重复使用的【{CardCatalog.Get(cardKind).DisplayName}】伤害改为火焰且伤害 +1。"
                    : $"{source.Name} 的【英博】令本轮首次使用的【{CardCatalog.Get(cardKind).DisplayName}】不能被响应。",
                sourceSeat);
        }

        if (_skillRuntimeState.GetUsage(
                sourceSeat,
                RoundDamageCardHistorySkillId,
                usageId,
                SkillUsageScope.Round) == 0)
        {
            _skillRuntimeState.TryConsumeUsage(
                sourceSeat,
                RoundDamageCardHistorySkillId,
                usageId,
                SkillUsageScope.Round,
                limit: 1);
        }
    }

    private bool IsYingboUnrespondable(long resolutionId) =>
        UsesFormalMouLuMeng && (LifecycleCardUse(resolutionId)?.YingboUnrespondable == true);

    private bool IsYingboRepeated(long resolutionId) =>
        UsesFormalMouLuMeng && (LifecycleCardUse(resolutionId)?.YingboRepeated == true);

    private int GetHengyeGrowth(CharacterState player) =>
        UsesFormalMouLuMeng && HasRuntimeSkill(player, HengyeSkillId)
            ? _skillRuntimeState.GetUsage(
                player.Seat,
                HengyeSkillId,
                HengyeGrowthUsageId,
                SkillUsageScope.Game)
            : 0;

    private void ApplyHengyeGrowth(
        long damageFrameId,
        CharacterState source,
        CharacterState target,
        int amount)
    {
        if (!UsesFormalMouLuMeng || amount <= 0 || !source.IsAlive ||
            !HasRuntimeSkill(source, HengyeSkillId))
            return;

        var previous = GetHengyeGrowth(source);
        if (!_skillRuntimeState.TryConsumeUsage(
                source.Seat,
                HengyeSkillId,
                HengyeGrowthUsageId,
                SkillUsageScope.Game,
                limit: 3))
            return;

        var current = previous + 1;
        AdvanceEventRulesAndQueueFact(new SkillUsageConsumedEvent(
            source.Seat,
            HengyeSkillId,
            HengyeGrowthUsageId,
            SkillUsageScope.Game,
            current));
        AdvanceEventRulesAndQueueFact(new HengyeGrowthChangedEvent(
            damageFrameId,
            source.Seat,
            previous,
            current));
        AddLog(
            "SkillTriggered",
            $"{source.Name} 的【横野】成长至 {current}/3（摸牌数、出杀次数、攻击范围、手牌上限同步增加）。",
            source.Seat,
            target.Seat);
    }

    private void ResolveHengyeTurnStart(CharacterState player)
    {
        if (GetHengyeGrowth(player) < 3 || player.Hp >= player.MaxHp) return;

        var recoveryFrameId = BeginRecovery(0, player.Seat, player.Seat, 1);
        try
        {
            player.Hp++;
            AdvanceEventRulesAndQueueFact(new RecoveryAppliedEvent(player.Seat, player.Seat, 1, player.Hp));
            AddLog("SkillTriggered", $"{player.Name} 的【横野】已成长至 3，本回合开始时回复 1 点体力。", player.Seat);
        }
        finally
        {
            PopResolutionFrame(recoveryFrameId, ResolutionFrameKind.Recovery);
        }
    }

    private void ResetHengyeAfterKill(CharacterState? killer)
    {
        if (!UsesFormalMouLuMeng || killer is not { IsAlive: true } ||
            !HasRuntimeSkill(killer, HengyeSkillId))
            return;

        var previous = GetHengyeGrowth(killer);
        _skillRuntimeState.ResetSkill(killer.Seat, HengyeSkillId);
        AdvanceEventRulesAndQueueFact(new SkillResetEvent(killer.Seat, HengyeSkillId, previous));
        AddLog("SkillTriggered", $"{killer.Name} 杀死一名角色，重置【横野】至游戏开始时状态。", killer.Seat);
    }

    private bool TryBeginYingboGift(
        long resolutionId,
        int sourceSeat,
        Card card,
        CardKind cardKind,
        IReadOnlyList<Card> physicalCards,
        YingboGiftContinuation continuation,
        CardAttackHandle? attack = null,
        GroupCardHandle? group = null)
    {
        if (_winner != Winner.None ||
            !IsYingboUnrespondable(resolutionId) ||
            ActiveYingboGift is not null ||
            physicalCards is not [var physicalCard] ||
            physicalCard.Id != card.Id ||
            _cardZones.GetLocation(card.Id) != CardLocation.Processing)
            return false;

        var source = _players[sourceSeat];
        var targets = _players
            .Where(player => player.IsAlive && player.Seat != sourceSeat)
            .OrderBy(player => player.Seat)
            .ToArray();
        if (!source.IsAlive || !HasRuntimeSkill(source, YingboSkillId) || targets.Length == 0)
            return false;

        UpdateCardContinuations(resolutionId, state => state with { YingboGift = new(sourceSeat,
            new(card.Id, card.Kind, card.Suit, card.Rank), cardKind, continuation,
            attack?.ResolutionId, group?.OwnerFrameId) });
        var choices = targets.Select(target => new PromptChoice(
                new ChoiceId($"yingbo.gift.target-{target.Seat}.resolution-{resolutionId}"),
                $"将【{card.DisplayName}】交给 {target.Name}。",
                [card.Id],
                [target.Seat],
                new Dictionary<string, string> { ["action"] = "yingbo-gift" }))
            .Append(new PromptChoice(
                new ChoiceId($"yingbo.gift.skip.resolution-{resolutionId}"),
                "不交出此牌。",
                [],
                [],
                new Dictionary<string, string> { ["action"] = "yingbo-skip" }))
            .ToArray();
        _pendingDecision = new PendingDecision(
            DecisionKind.Yingbo,
            sourceSeat,
            $"【{card.DisplayName}】结算完毕，是否发动【英博】将此牌交给一名其他角色？",
            [card.Id],
            targets.Select(target => target.Seat).ToArray(),
            SourceSeat: sourceSeat,
            IncomingCard: cardKind)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            Choices = choices
        };
        _status = source.IsHuman ? EngineStatus.AwaitingHumanResponse : EngineStatus.Running;
        return true;
    }

    private CommandResult SubmitYingboPromptAnswer(PromptChoice selected)
    {
        if (ActiveYingboGift is null || _pendingDecision is not { Kind: DecisionKind.Yingbo })
            return Reject(CommandErrorCode.InvalidPrompt, "没有等待响应的英博交牌选择。");

        return Accept(() => HumanYingboCore(
            selected,
            advanceToHumanBoundary: _options.AdvanceAfterHumanCommands));
    }

    private void HumanYingboCore(PromptChoice selected, bool advanceToHumanBoundary)
    {
        RequireHumanDecision(DecisionKind.Yingbo);
        ResolveYingboGiftChoice(selected);
        AdvanceRulesAndPublishState();
        if (advanceToHumanBoundary) AdvanceToHumanBoundary();
    }

    private void ResolveYingboGiftChoice(PromptChoice selected)
    {
        var pending = ActiveYingboGift ??
            throw new InvalidOperationException("There is no Yingbo gift to resolve.");
        if (_pendingDecision is not { Kind: DecisionKind.Yingbo, PlayerSeat: var ownerSeat } ||
            ownerSeat != pending.SourceSeat)
            throw new InvalidOperationException("The Yingbo gift prompt lost its owner.");

        var action = selected.Parameters.GetValueOrDefault("action");
        int? targetSeat = null;
        if (action == "yingbo-gift" && selected.Cards is [var cardId] &&
            cardId == pending.Card.Id && selected.Targets is [var selectedTarget] &&
            IsValidPlayerSeat(selectedTarget) && selectedTarget != pending.SourceSeat &&
            _players[selectedTarget].IsAlive)
        {
            targetSeat = selectedTarget;
            MoveCard(
                pending.Card,
                CardLocation.Processing,
                CardLocation.Hand(selectedTarget),
                new CardMoveReason("skill.yingbo.gift"));
        }
        else if (action == "yingbo-skip" && selected.Cards.Count == 0 && selected.Targets.Count == 0)
        {
            MoveCard(
                pending.Card,
                CardLocation.Processing,
                CardLocation.DiscardPile,
                CardMoveReasons.UseFinished);
        }
        else
        {
            throw new InvalidOperationException("The Yingbo gift choice is malformed or no longer legal.");
        }

        AdvanceEventRulesAndQueueFact(new YingboGiftResolvedEvent(
            pending.ResolutionId,
            pending.SourceSeat,
            pending.Card.Id,
            pending.CardKind,
            targetSeat));
        AddLog(
            targetSeat is null ? "SkillSkipped" : "SkillTriggered",
            targetSeat is { } recipient
                ? $"{_players[pending.SourceSeat].Name} 发动【英博】，将【{pending.Card.DisplayName}】交给 {_players[recipient].Name}。"
                : $"{_players[pending.SourceSeat].Name} 未发动【英博】交牌。",
            pending.SourceSeat,
            targetSeat);

        ActiveYingboGift = null;
        ClearPendingDecision();
        if (pending.Continuation == YingboGiftContinuation.Attack)
        {
            var attack = pending.Attack ??
                throw new InvalidOperationException("The Yingbo attack gift lost its card continuation.");
            var completion = CaptureAttackCompletion(attack);
            if (!FinishAttack(attack, allowYingboGift: false))
            {
                CompleteAttackAfterCardResolution(completion);
            }
        }
        else
        {
            FinishGroupAttack(
                pending.Group ?? throw new InvalidOperationException("The Yingbo group gift lost its card continuation."),
                allowYingboGift: false);
        }
    }

    private bool IsAiYingboPending() =>
        ActiveYingboGift is { SourceSeat: var sourceSeat } &&
        _pendingDecision is { Kind: DecisionKind.Yingbo, PlayerSeat: var decisionSeat } &&
        sourceSeat == decisionSeat && !_players[sourceSeat].IsHuman;

    private void ResolvePendingAiYingbo()
    {
        if (!IsAiYingboPending())
            throw new InvalidOperationException("There is no AI Yingbo gift to resolve.");

        // Giving a card is optional. The baseline AI avoids leaking role information
        // and deterministically keeps the card in the discard pile.
        var selected = _pendingDecision!.Choices.Single(choice =>
            choice.Parameters.GetValueOrDefault("action") == "yingbo-skip");
        ResolveYingboGiftChoice(selected);
        AdvanceRulesAndPublishState();
    }

    private void AssertYingboInvariant()
    {
        if (ActiveYingboGift is null)
        {
            if (_pendingDecision?.Kind == DecisionKind.Yingbo)
                throw new InvalidOperationException("A Yingbo prompt cannot exist without its card continuation.");
            return;
        }

        var pending = ActiveYingboGift;
        if (!UsesFormalMouLuMeng ||
            _pendingDecision is not { Kind: DecisionKind.Yingbo, IsPrivate: true } decision ||
            decision.PlayerSeat != pending.SourceSeat ||
            _cardZones.GetLocation(pending.Card.Id) != CardLocation.Processing ||
            !IsYingboUnrespondable(pending.ResolutionId))
        {
            throw new InvalidOperationException(
                "A Yingbo gift must retain its owner, private prompt and physical card in Processing.");
        }
    }

    private sealed class YingboGiftHandle(GameEngine engine, long ownerId) : ICardContinuationHandle
    {
        public long OwnerFrameId => ownerId;
        public long ResolutionId => ownerId;
        private YingboGiftState State => engine.GetCardContinuations(ownerId).YingboGift ??
            throw new InvalidOperationException("Yingbo gift lost its owner state.");
        public int SourceSeat => State.SourceSeat;
        public Card Card => engine.ReadCardAppearance(State.Card);
        public CardKind CardKind => State.CardKind;
        public YingboGiftContinuation Continuation => State.Continuation;
        public CardAttackHandle? Attack => State.AttackOwnerId is { } id ? new(engine, id) : null;
        public GroupCardHandle? Group => State.GroupOwnerId is { } id ? new(engine, id) : null;
    }
}
