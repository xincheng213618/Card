namespace CardGame.Core;

public sealed partial class GameEngine
{
    private bool RoundGainedEquipmentDrawFirstChild(ProgramSkillFrame frame, ResolutionFrame child)
    {
        if (frame.RoundGainedEquipmentDrawReceipt is not { } receipt || !ValidRoundGainedEquipmentDraw(frame)) return false;
        if (child is CardsMovedTriggerWindowFrame moved)
            return moved.ResumeProgramFrameId is null && moved.Batch.Id == moved.Id && moved.Batch.ParentFrameId == frame.Id &&
                moved.Batch.AwaitingProgramFrameId == frame.Id && moved.Batch.OriginOwnerSeat == frame.OwnerSeat &&
                moved.Batch.OriginSkillId == frame.SkillId && moved.Batch.OriginSkillInstanceId == frame.SkillInstanceId &&
                moved.Batch.Movements.Count > 0 && moved.Batch.Movements.All(m => _cardMovements.Contains(m) &&
                    m.Sequence > receipt.MovementSequenceBefore && m.Sequence <= receipt.MovementSequenceAfter &&
                    m.Reason.Value == RoundGainedEquipmentDrawReason && m.From == CardLocation.DrawPile && m.To == CardLocation.Hand(frame.OwnerSeat));
        if (child is ProgramLifecycleTriggerWindowFrame skills && skills.Window == SkillProgramTriggerWindow.SkillsChanged)
            return skills.ResumeProgramFrameId == frame.Id && skills.Continuation == ProgramLifecycleContinuation.ResumeParentProgram &&
                skills.CandidateIndex >= 0 && skills.CandidateIndex <= skills.Candidates.Count;
        return child is ProgramLifecycleTriggerWindowFrame state && state.Continuation == ProgramLifecycleContinuation.ResumeCharacterStateChange &&
            state.ResumeProgramFrameId == frame.Id && state.CharacterStateContinuation == CharacterStateContinuation.Program &&
            state.CandidateIndex >= 0 && state.CandidateIndex <= state.Candidates.Count &&
            CompleteProgramEventHistory().OfType<CharacterStateChangedEvent>().Any(e => e.Change.Id == state.Id && e.Change.ParentFrameId == frame.Id &&
                e.Change.TargetSeat == state.OwnerSeat && e.Change.Window == state.Window);
    }

    private bool RoundGainedEquipmentDrawStructuralEdge(ResolutionFrame parent, ResolutionFrame child) =>
        parent is ProgramSkillFrame root && RoundGainedEquipmentDrawFirstChild(root, child) ||
        parent is ProgramCardTriggerWindowFrame window && child is ProgramSkillFrame { RoundGainedEquipmentDrawReceipt: not null } reward &&
            reward.WindowContext?.ParentFrameId == window.Id && ValidRoundGainedEquipmentDraw(reward);

    private ProgramSkillFrame? RoundGainedEquipmentDrawObserverRoot() => FindProgramObserverRoot(
        static (engine, root, child) => engine.RoundGainedEquipmentDrawFirstChild(root, child),
        static (engine, index) => engine.SameNameHandObserverSuffix(index));

    private bool IsRoundGainedEquipmentDrawDying() => ActiveDying is { } dying && RoundGainedEquipmentDrawObserverRoot() is { } root &&
        _resolutionStack.FindIndex(f => f.Id == dying.Id) > _resolutionStack.FindIndex(f => f.Id == root.Id);
    private bool HasRoundGainedEquipmentDrawCardObserver(long useId) => RoundGainedEquipmentDrawObserverRoot() is { } root &&
        root.RoundGainedEquipmentDrawReceipt!.Qualification.CardUseFrameId == useId;
    private bool HasRoundGainedEquipmentDrawDamageObserver(long id) => HasRoundGainedEquipmentDrawObserver(id, false);
    private bool HasRoundGainedEquipmentDrawBeforeDamageObserver(long id) => HasRoundGainedEquipmentDrawObserver(id, true);
    private bool HasRoundGainedEquipmentDrawObserver(long id, bool before)
    {
        var index = _resolutionStack.FindIndex(f => f.Id == id && (before ? f is BeforeDamageProgramWindowFrame : f is DamageTriggerWindowFrame));
        if (index < 0 || RoundGainedEquipmentDrawObserverRoot() is not { } root) return false;
        var rootIndex = _resolutionStack.FindIndex(f => f.Id == root.Id);
        if (index > rootIndex) return true;
        for (var child = index + 1; child <= rootIndex; child++)
            if (!RoundGainedEquipmentDrawStructuralEdge(_resolutionStack[child - 1], _resolutionStack[child]) &&
                !DyingSuitsStructuralEdge(_resolutionStack[child - 1], _resolutionStack[child]) &&
                !ResponseCompletionStructuralEdge(_resolutionStack[child - 1], _resolutionStack[child]) &&
                !OrderedPrintedSkillLossStructuralEdge(_resolutionStack[child - 1], _resolutionStack[child]) &&
                !OrderedPrintedSkillLossSkillsChangedEdge(_resolutionStack[child - 1], _resolutionStack[child])) return false;
        return index < rootIndex;
    }

    private bool AllowsRoundGainedEquipmentDrawNestedDamage(ProgramSkillFrame observer, int target, int amount,
        ProgramParticipantReference? source, DamageNature? nature, bool sourceLess)
    {
        if (sourceLess || observer.AttackAttempt is not null || observer.InstructionIndex < 1 || _resolutionStack.LastOrDefault()?.Id != observer.Id ||
            observer.WindowContext?.Window is not (SkillProgramTriggerWindow.CardsGained or SkillProgramTriggerWindow.CardsMoved or
                SkillProgramTriggerWindow.DiscardPileReceived or SkillProgramTriggerWindow.AfterHpRecovered or SkillProgramTriggerWindow.AfterHpLost or
                SkillProgramTriggerWindow.AfterHealthChanged or SkillProgramTriggerWindow.SkillsChanged) ||
            RoundGainedEquipmentDrawObserverRoot() is not { } root || root.Id == observer.Id) return false;
        var effect = ProgramInstructionResolver.Default.Resolve(observer, _contentRegistry.GetSkill(observer.SkillId).Program!)
            .GetPausedInstruction(observer.InstructionIndex).Effect;
        return effect.Op == SkillProgramEffectOp.Damage && effect.Amount == amount && effect.ActorReference == source && effect.DamageNature == nature &&
            target == (effect.TargetReference is { } reference ? ResolveProgramParticipant(observer, reference) : ResolveProgramEffectTarget(observer, effect.Target));
    }

    private bool TryAdvanceRoundGainedEquipmentDrawSubtree()
    {
        if (_pendingDecision is not null || RoundGainedEquipmentDrawObserverRoot() is null) return false;
        return TryAdvanceObserverSubtree(advanceRecoveryReplacement: true);
    }
}
