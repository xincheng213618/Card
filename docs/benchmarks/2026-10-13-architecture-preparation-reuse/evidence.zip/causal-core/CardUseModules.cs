﻿namespace CardGame.Core;

[Flags]
public enum CardUseCategories
{
    None = 0,
    Basic = 1,
    InstantTrick = 2,
    DelayedTrick = 4,
    Equipment = 8
}

public sealed record GrantNextCardTargetAdjustment(
    CardUseCategories Categories,
    int MinimumTargets = 1,
    bool AllowAdd = true,
    bool AllowRemove = true,
    bool IgnoreExtraTargetDistance = true);

public sealed record ForbidCardUseUntilTurnEnd(
    CardUseCategories Categories);

/// <summary>The stable content binding that granted a turn-scoped card-use effect.</summary>
public sealed record CardUseEffectSource(
    string SkillId,
    string BindingId,
    int OwnerSeat,
    string SkillInstanceId);

public sealed record TurnCardTargetAdjustment(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    CardUseCategories Categories,
    int MinimumTargets,
    bool AllowAdd,
    bool AllowRemove,
    bool IgnoreExtraTargetDistance);

public sealed record TurnCardUseProhibition(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    CardUseCategories Categories);

/// <summary>
/// A card-damage modifier with explicit expiry and source matching. Omitted settings
/// preserve the original owner-used/current-turn contract; chain propagation never matches.
/// </summary>
public sealed record TurnCardDamageModifier(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    IReadOnlyList<CardKind> CardKinds,
    int Amount,
    SkillProgramDamageModifierExpiration Expiration = SkillProgramDamageModifierExpiration.CurrentTurnEnd,
    SkillProgramDamageModifierSourceScope SourceScope = SkillProgramDamageModifierSourceScope.OwnerUsed);

public sealed record TurnCardActionProhibition(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    IReadOnlyList<CardKind> CardKinds,
    IReadOnlyList<CardActionType> ActionTypes)
{
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public IReadOnlyList<Suit>? Suits { get; init; }
}

public sealed record TurnHandCardColorRestriction(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    int AffectedSeat,
    bool IsRed)
{
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingDefault)]
    public bool RequiresChromaticSuit { get; init; }
}

public sealed record TurnRuleModifier(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    SkillRuleQuery Query,
    SkillRuleOperation Operation,
    int Amount,
    IReadOnlyList<CardKind>? CardKinds = null,
    [property: System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    int? AffectedSeat = null,
    [property: System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    ProgramHpLossModifierOrigin? PaidHpLossOrigin = null)
{
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingDefault)]
    public SkillProgramDamageModifierExpiration Expiration { get; init; }
}

public sealed record TurnCardTargetRestriction(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    SkillProgramCardTargetRestriction Restriction,
    int? TargetSeat = null,
    // A self-only restriction normally binds to the granting frame's owner. A skill can instead
    // name another character as the subject, so the subject is stored separately and falls back
    // to Source.OwnerSeat for every grant made before this option existed.
    int? SubjectSeat = null);

public sealed record TurnCardConversion(
    long GrantSequence,
    int TurnNumber,
    int TurnSeat,
    long ParentFrameId,
    int EffectIndex,
    CardUseEffectSource Source,
    string SourceBind,
    SkillProgramCardColorRelation ColorRelation,
    bool BoundCardIsRed,
    CardKind OutputKind)
{
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public ProgramPaidColorConversionOrigin? PaidColorOrigin { get; init; }
}

public sealed record CardTargetAdjustmentGrantedEvent(TurnCardTargetAdjustment Adjustment) : IGameEvent;

public sealed record CardUseProhibitionGrantedEvent(TurnCardUseProhibition Prohibition) : IGameEvent;

public sealed record CardDamageModifierGrantedEvent(TurnCardDamageModifier Modifier) : IGameEvent;
public sealed record CardActionProhibitionGrantedEvent(TurnCardActionProhibition Prohibition) : IGameEvent;
public sealed record HandCardColorRestrictionGrantedEvent(TurnHandCardColorRestriction Restriction) : IGameEvent;
public sealed record TurnRuleModifierGrantedEvent(TurnRuleModifier Modifier) : IGameEvent;
public sealed record CardTargetRestrictionGrantedEvent(TurnCardTargetRestriction Restriction) : IGameEvent;
public sealed record CardConversionGrantedEvent(TurnCardConversion Conversion) : IGameEvent;

public sealed record ProgramCardDamageModifiedEvent(
    long ResolutionId,
    CardUseEffectSource Source,
    int TargetSeat,
    CardKind? CardKind,
    int BaseAmount,
    int ModifiedAmount) : IGameEvent;

/// <summary>Public evidence that a passive program cap rewrote an attack's damage (公清 set-to-one).</summary>
public sealed record ProgramDamageCappedEvent(
    long ResolutionId,
    CardUseEffectSource Source,
    int SourceSeat,
    int TargetSeat,
    CardKind? CardKind,
    int BaseAmount,
    int CappedAmount) : IGameEvent;

public sealed record TurnCardUseEffectsExpiredEvent(
    int TurnNumber,
    int TurnSeat,
    IReadOnlyList<long> GrantSequences) : IGameEvent;

/// <summary>Maps the final effective card kind to the categories used by generic rules.</summary>
public static class CardUseCategoryCatalog
{
    public const CardUseCategories All = CardUseCategories.Basic |
                                         CardUseCategories.InstantTrick |
                                         CardUseCategories.DelayedTrick |
                                         CardUseCategories.Equipment;

    public static CardUseCategories Get(CardKind effectiveKind)
    {
        if (EquipmentCatalog.IsEquipment(effectiveKind)) return CardUseCategories.Equipment;
        if (effectiveKind is CardKind.Indulgence or CardKind.SupplyShortage or CardKind.Lightning)
            return CardUseCategories.DelayedTrick;
        return CardCatalog.Get(effectiveKind).CategoryName switch
        {
            "基本牌" => CardUseCategories.Basic,
            "锦囊牌" => CardUseCategories.InstantTrick,
            _ => throw new InvalidOperationException(
                $"Card kind '{effectiveKind}' has no supported card-use category.")
        };
    }

    internal static bool IsValid(CardUseCategories categories) =>
        categories != CardUseCategories.None && (categories & ~All) == 0;
}

/// <summary>
/// Deterministic turn-scoped state. Checkpoints rebuild it from the accepted
/// command prefix; stable frame/effect keys make a resumed instruction idempotent.
/// </summary>
internal sealed partial class TurnCardUseEffectStore
{
    private readonly List<TurnCardTargetAdjustment> _targetAdjustments = [];
    private readonly List<TurnCardUseProhibition> _prohibitions = [];
    private readonly List<TurnCardDamageModifier> _damageModifiers = [];
    private readonly List<TurnCardActionProhibition> _actionProhibitions = [];
    private readonly List<TurnHandCardColorRestriction> _handColorRestrictions = [];
    private readonly List<TurnRuleModifier> _ruleModifiers = [];
    private readonly List<TurnCardTargetRestriction> _targetRestrictions = [];
    private readonly List<TurnCardConversion> _conversions = [];
    private long _grantSequence;

    internal IReadOnlyList<TurnCardTargetAdjustment> TargetAdjustments => _targetAdjustments;
    internal IReadOnlyList<TurnCardUseProhibition> Prohibitions => _prohibitions;
    internal IReadOnlyList<TurnCardDamageModifier> DamageModifiers => _damageModifiers;
    internal IReadOnlyList<TurnCardActionProhibition> ActionProhibitions => _actionProhibitions;
    internal IReadOnlyList<TurnHandCardColorRestriction> HandColorRestrictions => _handColorRestrictions;
    internal IReadOnlyList<TurnRuleModifier> RuleModifiers => _ruleModifiers;
    internal IReadOnlyList<TurnCardTargetRestriction> TargetRestrictions => _targetRestrictions;
    internal IReadOnlyList<TurnCardConversion> Conversions => _conversions;

    internal TurnCardTargetAdjustment GrantTargetAdjustment(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        GrantNextCardTargetAdjustment effect)
    {
        var existing = _targetAdjustments.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || existing.Categories != effect.Categories ||
                existing.MinimumTargets != effect.MinimumTargets || existing.AllowAdd != effect.AllowAdd ||
                existing.AllowRemove != effect.AllowRemove ||
                existing.IgnoreExtraTargetDistance != effect.IgnoreExtraTargetDistance)
            {
                throw new InvalidOperationException("A target-adjustment grant key changed its meaning.");
            }
            return existing;
        }

        var granted = new TurnCardTargetAdjustment(
            ++_grantSequence,
            turnNumber,
            turnSeat,
            parentFrameId,
            effectIndex,
            source,
            effect.Categories,
            effect.MinimumTargets,
            effect.AllowAdd,
            effect.AllowRemove,
            effect.IgnoreExtraTargetDistance);
        _targetAdjustments.Add(granted);
        return granted;
    }

    internal TurnCardUseProhibition GrantProhibition(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        ForbidCardUseUntilTurnEnd effect)
    {
        var existing = _prohibitions.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || existing.Categories != effect.Categories)
            {
                throw new InvalidOperationException("A card-use prohibition grant key changed its meaning.");
            }
            return existing;
        }

        var granted = new TurnCardUseProhibition(
            ++_grantSequence,
            turnNumber,
            turnSeat,
            parentFrameId,
            effectIndex,
            source,
            effect.Categories);
        _prohibitions.Add(granted);
        return granted;
    }

    internal TurnCardDamageModifier GrantDamageModifier(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        IReadOnlyList<CardKind> cardKinds,
        int amount,
        SkillProgramDamageModifierExpiration expiration = SkillProgramDamageModifierExpiration.CurrentTurnEnd,
        SkillProgramDamageModifierSourceScope sourceScope = SkillProgramDamageModifierSourceScope.OwnerUsed)
    {
        var frozenKinds = Array.AsReadOnly(cardKinds.Distinct().Order().ToArray());
        var existing = _damageModifiers.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || !existing.CardKinds.SequenceEqual(frozenKinds) ||
                existing.Amount != amount || existing.Expiration != expiration ||
                existing.SourceScope != sourceScope)
            {
                throw new InvalidOperationException("A card-damage modifier grant key changed its meaning.");
            }
            return existing;
        }

        var granted = new TurnCardDamageModifier(
            ++_grantSequence,
            turnNumber,
            turnSeat,
            parentFrameId,
            effectIndex,
            source,
            frozenKinds,
            amount,
            expiration,
            sourceScope);
        _damageModifiers.Add(granted);
        return granted;
    }

    internal TurnCardActionProhibition GrantActionProhibition(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        IReadOnlyList<CardKind> cardKinds,
        IReadOnlyList<CardActionType> actionTypes, IReadOnlyList<Suit>? suits = null)
    {
        IReadOnlyList<Suit>? frozenSuits = suits is null ? null : Array.AsReadOnly(suits.Distinct().Order().ToArray());
        var frozenKinds = Array.AsReadOnly(cardKinds.Distinct().Order().ToArray());
        var frozenActions = Array.AsReadOnly(actionTypes.Distinct().Order().ToArray());
        var existing = _actionProhibitions.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || !existing.CardKinds.SequenceEqual(frozenKinds) ||
                !existing.ActionTypes.SequenceEqual(frozenActions) || !(existing.Suits ?? []).SequenceEqual(frozenSuits ?? []))
                throw new InvalidOperationException("A card-action prohibition grant key changed its meaning.");
            return existing;
        }

        var granted = new TurnCardActionProhibition(
            ++_grantSequence, turnNumber, turnSeat, parentFrameId, effectIndex, source,
            frozenKinds, frozenActions) { Suits = frozenSuits };
        _actionProhibitions.Add(granted);
        return granted;
    }

    internal TurnRuleModifier GrantRuleModifier(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        SkillRuleQuery query,
        SkillRuleOperation operation,
        int amount,
        IReadOnlyList<CardKind>? cardKinds = null,
        int? affectedSeat = null, ProgramHpLossModifierOrigin? hpLossOrigin = null,
        SkillProgramDamageModifierExpiration expiration = SkillProgramDamageModifierExpiration.CurrentTurnEnd)
    {
        IReadOnlyList<CardKind> frozenKinds = cardKinds is null ? [] : Array.AsReadOnly(cardKinds.ToArray());
        var existing = _ruleModifiers.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || existing.Query != query ||
                existing.Operation != operation || existing.Amount != amount || existing.AffectedSeat != affectedSeat || existing.PaidHpLossOrigin != hpLossOrigin || existing.Expiration != expiration ||
                !(existing.CardKinds ?? []).SequenceEqual(frozenKinds))
                throw new InvalidOperationException("A turn rule-modifier grant key changed its meaning.");
            return existing;
        }

        var granted = new TurnRuleModifier(
            ++_grantSequence, turnNumber, turnSeat, parentFrameId, effectIndex, source,
            query, operation, amount, frozenKinds, affectedSeat, hpLossOrigin) { Expiration = expiration };
        _ruleModifiers.Add(granted);
        return granted;
    }

    internal TurnHandCardColorRestriction GrantHandColorRestriction(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        int affectedSeat,
        bool isRed,
        bool requiresChromaticSuit = false)
    {
        var existing = _handColorRestrictions.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || existing.AffectedSeat != affectedSeat || existing.IsRed != isRed ||
                existing.RequiresChromaticSuit != requiresChromaticSuit)
                throw new InvalidOperationException("A hand-color restriction grant key changed its meaning.");
            return existing;
        }

        var granted = new TurnHandCardColorRestriction(
            ++_grantSequence, turnNumber, turnSeat, parentFrameId, effectIndex, source, affectedSeat, isRed)
        { RequiresChromaticSuit = requiresChromaticSuit };
        _handColorRestrictions.Add(granted);
        return granted;
    }

    internal TurnCardTargetRestriction GrantTargetRestriction(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        SkillProgramCardTargetRestriction restriction,
        int? targetSeat = null,
        int? subjectSeat = null)
    {
        var existing = _targetRestrictions.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || existing.Restriction != restriction ||
                existing.TargetSeat != targetSeat || existing.SubjectSeat != subjectSeat)
                throw new InvalidOperationException("A card-target restriction grant key changed its meaning.");
            return existing;
        }

        var granted = new TurnCardTargetRestriction(
            ++_grantSequence, turnNumber, turnSeat, parentFrameId, effectIndex, source, restriction, targetSeat,
            subjectSeat);
        _targetRestrictions.Add(granted);
        return granted;
    }

    internal TurnCardConversion GrantConversion(
        int turnNumber,
        int turnSeat,
        long parentFrameId,
        int effectIndex,
        CardUseEffectSource source,
        string sourceBind,
        SkillProgramCardColorRelation colorRelation,
        bool boundCardIsRed,
        CardKind outputKind,
        ProgramPaidColorConversionOrigin? paidColorOrigin = null)
    {
        var existing = _conversions.SingleOrDefault(item =>
            item.ParentFrameId == parentFrameId && item.EffectIndex == effectIndex);
        if (existing is not null)
        {
            if (existing.TurnNumber != turnNumber || existing.TurnSeat != turnSeat ||
                existing.Source != source || existing.SourceBind != sourceBind ||
                existing.ColorRelation != colorRelation || existing.BoundCardIsRed != boundCardIsRed ||
                existing.OutputKind != outputKind || existing.PaidColorOrigin != paidColorOrigin)
                throw new InvalidOperationException("A card-conversion grant key changed its meaning.");
            return existing;
        }

        var granted = new TurnCardConversion(
            ++_grantSequence, turnNumber, turnSeat, parentFrameId, effectIndex, source,
            sourceBind, colorRelation, boundCardIsRed, outputKind) { PaidColorOrigin = paidColorOrigin };
        _conversions.Add(granted);
        return granted;
    }

    internal bool IsCardUseForbidden(
        int turnNumber,
        int turnSeat,
        int actorSeat,
        CardKind effectiveKind,
        CardActionType actionType)
    {
        var category = CardUseCategoryCatalog.Get(effectiveKind);
        return actionType == CardActionType.Use && _prohibitions.Any(item =>
            item.TurnNumber == turnNumber &&
            item.TurnSeat == turnSeat &&
            item.Source.OwnerSeat == actorSeat &&
            (item.Categories & category) != 0) ||
            _actionProhibitions.Any(item =>
                item.TurnNumber == turnNumber &&
                item.TurnSeat == turnSeat &&
                item.Source.OwnerSeat == actorSeat &&
                item.CardKinds.Contains(effectiveKind) &&
                item.ActionTypes.Contains(actionType));
    }

    internal bool IsHandColorRestricted(
        int turnNumber,
        int turnSeat,
        int affectedSeat,
        bool isRed,
        bool isColorless = false) =>
        _handColorRestrictions.Any(item =>
            item.TurnNumber == turnNumber && item.TurnSeat == turnSeat &&
            item.AffectedSeat == affectedSeat && item.IsRed == isRed &&
            (!item.RequiresChromaticSuit || !isColorless));

    internal IReadOnlyList<TurnRuleModifier> GetRuleModifiers(
        int turnNumber,
        int turnSeat,
        int actorSeat,
        SkillRuleQuery query,
        CardKind? effectiveCardKind = null) =>
        _ruleModifiers.Where(item =>
                (item.Expiration == SkillProgramDamageModifierExpiration.NextOwnerTurnStart ||
                 item.TurnNumber == turnNumber && item.TurnSeat == turnSeat) &&
                (item.AffectedSeat ?? item.Source.OwnerSeat) == actorSeat && item.Query == query &&
                (item.CardKinds is null || item.CardKinds.Count == 0 ||
                 effectiveCardKind is { } kind && item.CardKinds.Contains(kind)))
            .OrderBy(item => item.GrantSequence)
            .ToArray();

    internal bool HasTargetRestriction(
        int turnNumber,
        int turnSeat,
        int actorSeat,
        SkillProgramCardTargetRestriction restriction,
        int? targetSeat = null) =>
        _targetRestrictions.Any(item =>
            item.TurnNumber == turnNumber && item.TurnSeat == turnSeat &&
            (item.SubjectSeat ?? item.Source.OwnerSeat) == actorSeat && item.Restriction == restriction &&
            item.TargetSeat == targetSeat);

    internal IReadOnlyList<TurnCardConversion> GetConversions(
        int turnNumber,
        int turnSeat,
        int actorSeat,
        CardKind outputKind,
        bool inputIsRed) =>
        _conversions.Where(item =>
                item.PaidColorOrigin is null && item.TurnNumber == turnNumber && item.TurnSeat == turnSeat &&
                item.Source.OwnerSeat == actorSeat && item.OutputKind == outputKind &&
                item.ColorRelation == SkillProgramCardColorRelation.OppositeBoundCard &&
                item.BoundCardIsRed != inputIsRed)
            .OrderBy(item => item.GrantSequence)
            .ToArray();

    internal IReadOnlyList<TurnCardTargetAdjustment> GetTargetAdjustments(
        int turnNumber,
        int turnSeat,
        int actorSeat,
        CardKind effectiveKind)
    {
        var category = CardUseCategoryCatalog.Get(effectiveKind);
        return _targetAdjustments
            .Where(item =>
                item.TurnNumber == turnNumber &&
                item.TurnSeat == turnSeat &&
                item.Source.OwnerSeat == actorSeat &&
                (item.Categories & category) != 0)
            .OrderBy(item => item.GrantSequence)
            .ToArray();
    }

    internal IReadOnlyList<TurnCardDamageModifier> GetDamageModifiers(
        int turnNumber,
        int turnSeat,
        int sourceSeat,
        int cardUserSeat,
        CardKind effectiveKind,
        bool isChainPropagation)
    {
        if (isChainPropagation) return [];
        return _damageModifiers
            .Where(item =>
                (item.Expiration == SkillProgramDamageModifierExpiration.NextOwnerTurnStart ||
                 item.TurnNumber == turnNumber && item.TurnSeat == turnSeat) &&
                item.Source.OwnerSeat == sourceSeat &&
                (item.SourceScope == SkillProgramDamageModifierSourceScope.DamageSource ||
                 sourceSeat == cardUserSeat) &&
                item.CardKinds.Contains(effectiveKind))
            .OrderBy(item => item.GrantSequence)
            .ToArray();
    }

    internal bool ConsumeTargetAdjustment(long grantSequence)
    {
        var index = _targetAdjustments.FindIndex(item => item.GrantSequence == grantSequence);
        if (index < 0) return false;
        _targetAdjustments.RemoveAt(index);
        return true;
    }

    internal IReadOnlyList<long> ExpireTurn(int turnNumber, int turnSeat)
    {
        var expired = ExpiringJudgedRankSlashPolicies(turnNumber, turnSeat).Concat(ExpiringInspectedHandDistances(turnNumber, turnSeat)).Concat(ExpiringTargetCardQuotaAllowances(turnNumber, turnSeat)).Concat(ExpiringHandCategoryRestrictions(turnNumber, turnSeat)).Concat(ExpiringBoundSlashBenefits(turnNumber, turnSeat)).Concat(ExpiringHandLimitKindExemptions(turnNumber, turnSeat)).Concat(ExpiringHandLimitExemptCards(turnNumber, turnSeat)).Concat(ExpiringRedSlashPolicies(turnNumber, turnSeat)).Concat(_targetAdjustments
            .Where(item => item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
            .Select(item => item.GrantSequence))
            .Concat(_prohibitions
                .Where(item => item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Concat(_damageModifiers
                .Where(item => item.Expiration == SkillProgramDamageModifierExpiration.CurrentTurnEnd &&
                               item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Concat(_actionProhibitions
                .Where(item => item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Concat(_handColorRestrictions
                .Where(item => item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Concat(_ruleModifiers
                .Where(item => item.Expiration == SkillProgramDamageModifierExpiration.CurrentTurnEnd &&
                               item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Concat(_recoveryModifiers
                .Where(item => item.Expiration == SkillProgramDamageModifierExpiration.CurrentTurnEnd &&
                               item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Concat(_targetRestrictions
                .Where(item => item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Concat(_conversions
                .Where(item => item.TurnNumber == turnNumber && item.TurnSeat == turnSeat)
                .Select(item => item.GrantSequence))
            .Order()
            .ToArray();
        if (expired.Length == 0) return expired;
        var expiredSet = expired.ToHashSet();
        _targetAdjustments.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _prohibitions.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _damageModifiers.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _actionProhibitions.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _handColorRestrictions.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _ruleModifiers.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _recoveryModifiers.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _targetRestrictions.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        _conversions.RemoveAll(item => expiredSet.Contains(item.GrantSequence));
        ExpireRedSlashPolicies(expiredSet);
        ExpireHandLimitExemptCards(expiredSet);
        ExpireHandLimitKindExemptions(expiredSet);
        ExpireBoundSlashBenefits(expiredSet);
        ExpireHandCategoryRestrictions(expiredSet);
        ExpireTargetCardQuotaAllowances(expiredSet);
        ExpireInspectedHandDistances(expiredSet);
        ExpireJudgedRankSlashPolicies(expiredSet);
        return expired;
    }

    internal IReadOnlyList<long> ExpireDamageModifiersAtOwnerTurnStart(int ownerSeat, int turnNumber) =>
        ExpireDamageModifiers(item =>
            item.Expiration == SkillProgramDamageModifierExpiration.NextOwnerTurnStart &&
            item.Source.OwnerSeat == ownerSeat && item.TurnNumber < turnNumber);

    internal IReadOnlyList<long> ExpireDamageModifiersOnDeath(int ownerSeat) =>
        ExpireDamageModifiers(item =>
            item.Expiration == SkillProgramDamageModifierExpiration.NextOwnerTurnStart &&
            item.Source.OwnerSeat == ownerSeat);

    private IReadOnlyList<long> ExpireDamageModifiers(Func<TurnCardDamageModifier, bool> predicate)
    {
        var expired = _damageModifiers.Where(predicate).Select(item => item.GrantSequence).Order().ToArray();
        if (expired.Length > 0)
            _damageModifiers.RemoveAll(item => predicate(item));
        return expired;
    }

    internal void AssertInvariants()
    {
        var all = _judgedRankSlashPolicies.Select(item => item.GrantSequence).Concat(_targetAdjustments.Select(item => item.GrantSequence))
            .Concat(_prohibitions.Select(item => item.GrantSequence))
            .Concat(_damageModifiers.Select(item => item.GrantSequence))
            .Concat(_actionProhibitions.Select(item => item.GrantSequence))
            .Concat(_handColorRestrictions.Select(item => item.GrantSequence))
            .Concat(_ruleModifiers.Select(item => item.GrantSequence))
            .Concat(_recoveryModifiers.Select(item => item.GrantSequence))
            .Concat(_targetRestrictions.Select(item => item.GrantSequence))
            .Concat(_conversions.Select(item => item.GrantSequence))
            .Concat(_handCategoryRestrictions.Select(item => item.GrantSequence))
            .Concat(_handLimitKindExemptions.Select(item => item.GrantSequence))
            .Concat(_slashSuitAllowances.Select(item => item.GrantSequence))
            .Concat(_firstRoundGameUsageRefunds.Select(item => item.GrantSequence))
            .Concat(_inspectedHandDistances.Select(item => item.GrantSequence)).ToArray();
        if (all.Length != all.Distinct().Count() || all.Any(sequence => sequence <= 0) ||
            all.Any(sequence => sequence > _grantSequence) || JudgedRankSlashPoliciesAreInvalid() ||
            _targetAdjustments.Any(item => !CardUseCategoryCatalog.IsValid(item.Categories) ||
                item.MinimumTargets < 1 || !item.AllowAdd && !item.AllowRemove) ||
            _prohibitions.Any(item => !CardUseCategoryCatalog.IsValid(item.Categories)) ||
            _damageModifiers.Any(item => item.Amount <= 0 || item.CardKinds.Count == 0 ||
                item.CardKinds.Distinct().Count() != item.CardKinds.Count ||
                !Enum.IsDefined(item.Expiration) || !Enum.IsDefined(item.SourceScope) ||
                item.TurnNumber <= 0 || item.Source.OwnerSeat < 0) ||
            _actionProhibitions.Any(item => item.CardKinds.Count == 0 && item.Suits is not { Count: > 0 } || item.Suits is { Count: 0 } ||
                item.Suits is not null && (item.CardKinds.Count != 0 || !item.ActionTypes.SequenceEqual([CardActionType.Use]) || item.Suits.Distinct().Count() != item.Suits.Count || item.Suits.Any(suit => !Enum.IsDefined(suit))) || item.ActionTypes.Count == 0 ||
                item.CardKinds.Distinct().Count() != item.CardKinds.Count ||
                item.ActionTypes.Distinct().Count() != item.ActionTypes.Count) ||
            _handColorRestrictions.Any(item => item.AffectedSeat < 0) || HandCategoryRestrictionsAreInvalid() || HandLimitKindExemptionsAreInvalid() || BoundSlashBenefitsAreInvalid() ||
            RecoveryModifiersAreInvalid() || _ruleModifiers.Any(item =>
                !Enum.IsDefined(item.Expiration) || item.AffectedSeat is < 0 || item.PaidHpLossOrigin is not null && !PaidHpLossProgram.IsValidModifierOrigin(item) ||
                item.Query == SkillRuleQuery.HandLimit &&
                    (item.Operation != SkillRuleOperation.Add || item.Amount is < -20 or > 20 || item.Amount == 0 || item.CardKinds is { Count: > 0 }) ||
                item.Query == SkillRuleQuery.OutgoingDistance &&
                    (item.Operation != SkillRuleOperation.Add || item.PaidHpLossOrigin is null && item.Amount is < -20 or > 20 || item.Amount == 0 || item.CardKinds is { Count: > 0 }) ||
                item.Query == SkillRuleQuery.SlashLimit &&
                    (item.Operation != SkillRuleOperation.Add || item.Amount < -20 || item.Amount == 0) ||
                item.Query == SkillRuleQuery.CardUseDistanceLimit &&
                    (item.Operation != SkillRuleOperation.Unlimited || item.Amount != 0 ||
                     item.CardKinds is { Count: > 0 } distanceKinds && distanceKinds.Distinct().Count() != distanceKinds.Count) ||
                item.Query == SkillRuleQuery.SlashDistanceLimit &&
                    item.Operation != SkillRuleOperation.Unlimited ||
                item.Query == SkillRuleQuery.AttackRange &&
                    item.Operation != SkillRuleOperation.Unlimited ||
                item.Query == SkillRuleQuery.CardTargetCount &&
                    (item.Operation != SkillRuleOperation.Add || item.Amount <= 0 ||
                     item.CardKinds is not { Count: > 0 } cardKinds ||
                     cardKinds.Distinct().Count() != cardKinds.Count) ||
                item.Query == SkillRuleQuery.CardEffectImmunity &&
                    (item.Operation != SkillRuleOperation.Set || item.Amount != 1 || item.CardKinds is not { Count: > 0 } ||
                     item.CardKinds.Any(kind => !GrantTurnCardEffectImmunityProgramOperationDescriptor.CardEffectImmunityKinds.Contains(kind))) ||
                item.Query is not (SkillRuleQuery.DrawCount or SkillRuleQuery.HandLimit or SkillRuleQuery.SlashLimit or SkillRuleQuery.CardUseDistanceLimit or SkillRuleQuery.SlashDistanceLimit or
                    SkillRuleQuery.AttackRange or SkillRuleQuery.CardTargetCount or SkillRuleQuery.CardEffectImmunity or SkillRuleQuery.OutgoingDistance)) ||
            _targetRestrictions.Any(item => item.Restriction == SkillProgramCardTargetRestriction.SelfOnly
                ? item.TargetSeat is not null || item.SubjectSeat < 0
                : item.TargetSeat is null or < 0) ||
            _conversions.Any(item => string.IsNullOrWhiteSpace(item.SourceBind) ||
                item.ColorRelation != SkillProgramCardColorRelation.OppositeBoundCard ||
                item.OutputKind != CardKind.Duel))
        {
            throw new InvalidOperationException("Turn card-use effects are inconsistent.");
        }
    }
}
