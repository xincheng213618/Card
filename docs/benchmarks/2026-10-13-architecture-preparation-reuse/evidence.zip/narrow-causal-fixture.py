from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).parent
repo_source = Path(r'C:\Users\17917\Desktop\Card\tests\CardGame.Core.Tests\SoleTargetProtectionChecks.cs')
source = repo_source.read_text(encoding='utf-8-sig')
headers = list(re.finditer(r'^    (public|private) static .*$', source, re.MULTILINE))
selected = 'EligibilityRejectsRedTrickAndOwnUseAndPreservesPrivateCost'
output = source
removed = []
selected_text = None
for index in range(len(headers) - 1, -1, -1):
    match = headers[index]
    if match[1] != 'public':
        continue
    end = headers[index + 1].start() if index + 1 < len(headers) else len(source)
    text = source[match.start():end]
    if selected in match[0]:
        selected_text = text
    else:
        removed.append(match[0].strip())
        output = output[:match.start()] + output[end:]
if selected_text is None or output.count(selected_text) != 1:
    raise RuntimeError('The selected original method was not preserved exactly')
destination = root / 'causal-probe/SoleTargetProtectionChecks.cs'
destination.write_text(output, encoding='utf-8', newline='')
report = {'currentOriginalSha256': hashlib.sha256(repo_source.read_bytes()).hexdigest(),
          'diagnosticSubsetSha256': hashlib.sha256(output.encode()).hexdigest(),
          'selectedMethodPreservedExactly': True,
          'selectedMethod': selected,
          'excludedUncalledPublicMethods': removed,
          'note': 'Only the temporary diagnostic copy excludes unrelated methods needing newer in-progress frame APIs; all selected method assertions, fixture setup and private helpers are retained.'}
(root / 'causal-fixture-subset.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
