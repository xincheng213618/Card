from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).parent
repo = Path(r'C:\Users\17917\Desktop\Card')
if '01a13336-b0c2-7472-a49f-7e3458841d28' not in (root / '.owner').read_text(encoding='utf-8-sig'):
    raise RuntimeError('Unexpected ownership')
source_path = root / 'causal-core/GameEngine.ProgramTurnPhase.cs'
original = source_path.read_bytes()
anchor = b'var action = nativeWindows || HasSoleTargetProtectionParticipant'
if original.count(anchor) != 1:
    raise RuntimeError('Isolated source does not have the reviewed participant condition')
output = root / 'causal-output'
expected_owner = '01a13336-b0c2-7472-a49f-7e3458841d28 isolated causal diagnostic outputs'
if output.exists():
    if (output / '.owner').read_text(encoding='utf-8-sig') != expected_owner:
        raise RuntimeError('Existing causal output has different ownership')
else:
    output.mkdir()
    (output / '.owner').write_text(expected_owner, encoding='utf-8')
reports = []

def run(command, log_path):
    with log_path.open('w', encoding='utf-8') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        print(log_path.read_text(encoding='utf-8')[-5000:])
        raise RuntimeError('Diagnostic command failed: ' + str(log_path))

try:
    for variant, condition in (
        ('participant', anchor),
        ('catalog', b'var action = nativeWindows || HasSoleTargetProtectionCapability'),
        ('removed', b'var action = nativeWindows'),
    ):
        source_path.write_bytes(original.replace(anchor, condition))
        run(['dotnet', 'build', str(root / 'causal-core/CardGame.Core.csproj'), '-c', 'Release', '--artifacts-path', str(output / 'core')], root / f'causal-{variant}-build.log')
        if variant == 'participant':
            run(['dotnet', 'build', str(root / 'causal-probe/CausalProbe.csproj'), '-c', 'Release', '--artifacts-path', str(output / 'probe')], root / 'causal-probe-build.log')
        executables = list((output / 'probe/bin').rglob('CardGame.CausalProbe.dll'))
        if len(executables) != 1:
            raise RuntimeError('Expected one diagnostic assembly')
        runtime = output / 'runtime' / variant
        runtime.mkdir(parents=True, exist_ok=True)
        for file in executables[0].parent.iterdir():
            if file.is_file():
                shutil.copy2(file, runtime / file.name)
        core_dll = output / 'core/bin/CardGame.Core/release/CardGame.Core.dll'
        shutil.copy2(core_dll, runtime / 'CardGame.Core.dll')
        result_path = root / f'causal-{variant}-results.json'
        run(['dotnet', str(runtime / 'CardGame.CausalProbe.dll'), str(result_path)], root / f'causal-{variant}-run.log')
        report = json.loads(result_path.read_text(encoding='utf-8'))
        reports.append({'variant': variant, 'conditionSourceSha256': hashlib.sha256(source_path.read_bytes()).hexdigest(), **report})
        print(json.dumps({'variant': variant, 'checks': [{'name': r['Name'], 'passed': r['Passed']} for r in report['Results']]}), flush=True)
    (root / 'causal-comparison.json').write_text(json.dumps({'soleChangedExpression': True, 'reports': reports}, indent=2), encoding='utf-8')
finally:
    source_path.write_bytes(original)
    subprocess.run(['python', '-B', str(repo / 'tools/cleanup_temp.py'), '--add', str(output), '--root', str(root), '--reason', 'Isolated causal diagnostic assemblies and source results retained until comparison, inspection and evidence archive are complete.'], check=True)
