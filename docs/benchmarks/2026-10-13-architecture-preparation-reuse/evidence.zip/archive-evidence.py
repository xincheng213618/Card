from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).parent
repo = Path(r'C:\Users\17917\Desktop\Card')
destination = repo / 'docs/benchmarks/2026-10-13-architecture-preparation-reuse'
if destination.exists():
    raise RuntimeError('Inspect existing evidence instead of replacing it')
checks = json.loads((root / 'routine-input-closeout-check.json').read_text(encoding='utf-8-sig'))
own = [entry for entry in checks if entry['path'].replace('\\', '/') in (
    'tests/CardGame.Wpf.Tests/HandResponseChecks.cs',
    'tests/CardGame.Wpf.Tests/NativeWeaponFeedbackChecks.cs')]
if len(own) != 2 or not all(entry['matches'] for entry in own):
    raise RuntimeError('Own WPF sources changed since the verified snapshot')
with zipfile.ZipFile(root / 'after-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for entry in own:
        archive.writestr(entry['path'].replace('\\', '/'), (repo / entry['path']).read_bytes())
destination.mkdir(parents=True)
count = 0
with zipfile.ZipFile(destination / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in root.rglob('*'):
        if not file.is_file():
            continue
        relative = file.relative_to(root)
        # Preserve the complete isolated source and per-variant Core assemblies,
        # while leaving generated SDK/cache/runtime duplicate outputs queued.
        if relative.parts[0] == 'registry-benchmark-output':
            continue
        if relative.parts[0] == 'causal-output' and not (
            len(relative.parts) == 4 and relative.parts[1] == 'runtime' and file.name == 'CardGame.Core.dll'):
            continue
        archive.write(file, relative.as_posix())
        count += 1
archive_path = destination / 'evidence.zip'
task_root = root.parent
retained_bytes = sum(file.stat().st_size for file in task_root.rglob('*') if file.is_file())
routine = json.loads((root / 'routine-summary.json').read_text(encoding='utf-8-sig'))
summary = {
    'date': '2026-10-13',
    'scope': 'Reuse immutable weapon registry and one original hand-response Play prefix; preserve every actual load and assertion',
    'focused': {'wpfPassed': 2, 'corePassed': 1, 'coreFailed': 1, 'durationMs': 48891,
                'actualHandLoads': 17, 'independentCachedBaselinesBefore': 3, 'independentCachedBaselinesAfter': 2},
    'componentBenchmark': json.loads((root / 'registry-benchmark-results.json').read_text(encoding='utf-8')),
    'componentGain': {'removedRegistryBuilds': 2, 'sumMedianBuildMs': 14.3347,
                      'sumMedianBuildAllocatedBytes': 11065596,
                      'limit': 'Bounded preparation component; not total routine or screen performance'},
    'routine': {'status': routine['status'], 'durationMs': routine['durationMs'],
                'corePassed': 530, 'coreFailed': 2, 'coreTotal': 532, 'wpfPassed': 74,
                'buildMs': 14326, 'coreMs': 76649, 'wpfMs': 89462, 'manualFull': False},
    'failedChecks': ['Sole target protection: actual Slash and black trick substitution',
                    'Sole target protection: real paid source loss resumes once'],
    'integration': 'Legacy exact-producer and zero-entity eligibility checks pass in the later routine. Concurrent project work corrected the participant condition and version source; own product code was not changed.',
    'causalEvidence': 'Only one isolated action-creation expression differs. Catalog condition fails legacy provenance; participant condition passes it. Removing the condition prevents the actual zero-entity protection receipt. Selected original method assertions/helpers are preserved; unrelated uncalled newer-API methods excluded only from temporary diagnostic copy.',
    'source': {'routineInputs': len(checks), 'ownWpfMatchesRoutine': True,
               'changedInputs': [entry['path'] for entry in checks if not entry['matches']],
               'limit': 'Current entire checkout is not claimed green; routine failures and concurrent input changes retained'},
    'evidence': {'files': count, 'bytes': archive_path.stat().st_size,
                 'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest()},
    'retention': {'taskRoot': str(task_root), 'measuredBytes': retained_bytes,
                  'blockedNewOutput': str(root / 'registry-benchmark-output'),
                  'reason': 'Exact output cleanup rejected by automatic approval as blocked by policy; no deletion retry. Prior blocked outputs remain protected. Recovery and causal evidence retained for continuing goal.',
                  'queue': 'tools/cleanup_queue.json'}
}
(destination / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
