from pathlib import Path

root = Path(__file__).parent
folder = root / 'registry-benchmark'
if folder.exists():
    raise RuntimeError('Inspect existing benchmark before replacing it')
folder.mkdir()
(folder / 'RegistryBench.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><LangVersion>12</LangVersion></PropertyGroup>
  <ItemGroup><Reference Include="CardGame.Core"><HintPath>..\\causal-output\\core\\bin\\CardGame.Core\\release\\CardGame.Core.dll</HintPath><Private>true</Private></Reference>
    <Reference Include="CardGame.Content.Standard"><HintPath>..\\..\\iteration6\\candidate\\CardGame.Content.Standard.dll</HintPath><Private>true</Private></Reference>
    <Compile Include="C:\\Users\\17917\\Desktop\\Card\\tests\\Shared\\StoneAxeScenario.cs" Link="StoneAxeScenario.cs" /></ItemGroup>
</Project>''', encoding='utf-8')
(folder / 'Program.cs').write_text('''using System.Diagnostics;
using System.Text.Json;
using CardGame.Core;
var results = new List<object>();
foreach (var weapon in new[] { CardKind.StoneAxe, CardKind.QinglongCrescentBlade }) {
    var decision = weapon == CardKind.StoneAxe ? DecisionKind.StoneAxe : DecisionKind.QinglongCrescentBlade;
    var witness = StoneAxeScenario.FindHumanTrigger(weapon: weapon, expectedDecision: decision);
    var expected = witness.Game.ContentRegistry;
    if (StoneAxeScenario.CreateRegistry(weapon).ContentHash != expected.ContentHash) throw new Exception("Registry fingerprint differs");
    var timings = new List<double>(); var allocations = new List<long>();
    for (var sample = 0; sample < 10; sample++) {
        var bytes = GC.GetAllocatedBytesForCurrentThread(); var started = Stopwatch.GetTimestamp();
        var registry = StoneAxeScenario.CreateRegistry(weapon);
        var elapsed = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
        var allocated = GC.GetAllocatedBytesForCurrentThread() - bytes;
        if (registry.ContentHash != expected.ContentHash) throw new Exception("Registry changed");
        timings.Add(elapsed); allocations.Add(allocated);
    }
    var reuseBytes = GC.GetAllocatedBytesForCurrentThread(); var reuseStarted = Stopwatch.GetTimestamp();
    for(var sample=0; sample<1000; sample++) {
        if (!ReferenceEquals(witness.Game.ContentRegistry, expected)) throw new Exception("Registry identity changed");
    }
    var reuseMs = Stopwatch.GetElapsedTime(reuseStarted).TotalMilliseconds;
    var reuseAllocated = GC.GetAllocatedBytesForCurrentThread()-reuseBytes;
    timings.Sort(); allocations.Sort();
    results.Add(new { Weapon=weapon.ToString(), Samples=10, MedianBuildMs=(timings[4]+timings[5])/2,
        MedianBuildAllocatedBytes=(allocations[4]+allocations[5])/2, ThousandReferenceReadsMs=reuseMs,
        ThousandReferenceReadsAllocatedBytes=reuseAllocated, ContentHash=expected.ContentHash });
}
File.WriteAllText(args[0], JsonSerializer.Serialize(results, new JsonSerializerOptions {WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(results));
''', encoding='utf-8')
print(folder)
