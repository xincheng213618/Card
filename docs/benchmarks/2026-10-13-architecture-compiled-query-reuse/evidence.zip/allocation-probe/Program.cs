using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

var path = Path.GetFullPath(args[0]);
var assembly = Assembly.LoadFrom(path);
var method = assembly.GetType("CardGame.Core.GameEngine", true)!
    .GetMethod("FreezeViewDictionary", BindingFlags.NonPublic | BindingFlags.Static)!
    .MakeGenericMethod(typeof(string), typeof(int));
var candidate = method.CreateDelegate<Func<IReadOnlyDictionary<string, int>?, IReadOnlyDictionary<string, int>?>>();
Func<IReadOnlyDictionary<string, int>?, IReadOnlyDictionary<string, int>?> baseline = Before;
IReadOnlyDictionary<string, int> input = new Dictionary<string, int>();
for (var i = 0; i < 256; i++) { _ = baseline(input); _ = candidate(input); }
var samples = new List<object>();
for (var i = 0; i < 8; i++) {
    var first = i % 2 == 0 ? baseline : candidate;
    var second = i % 2 == 0 ? candidate : baseline;
    var a = Measure(first);
    var b = Measure(second);
    samples.Add(new { Index = i, Baseline = i % 2 == 0 ? a : b, Candidate = i % 2 == 0 ? b : a });
}
var result = new {
    Runtime = Environment.Version.ToString(), CallsPerSample = 10000,
    CandidateAssembly = path,
    CandidateAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))),
    Scope = "Exact pre-change expression compiled in this probe versus the actual private candidate factory, invoked through the same delegate signature. Empty dictionary only; not a before/after whole-binary, match, or screen measurement.",
    Samples = samples
};
var json = JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
File.WriteAllText(args[1], json);
Console.WriteLine(json);
Measurement Measure(Func<IReadOnlyDictionary<string, int>?, IReadOnlyDictionary<string, int>?> freeze) {
    var allocated = GC.GetAllocatedBytesForCurrentThread();
    var start = Stopwatch.GetTimestamp();
    for (var i = 0; i < 10000; i++) _ = freeze(input);
    var milliseconds = Stopwatch.GetElapsedTime(start).TotalMilliseconds;
    var bytes = GC.GetAllocatedBytesForCurrentThread() - allocated;
    return new(milliseconds, bytes, bytes / 10000d);
}
// Exact expression from PlayerViewProjector.cs.before, specialized to string/int.
static IReadOnlyDictionary<string, int>? Before(IReadOnlyDictionary<string, int>? values) => values is null ? null :
    new ReadOnlyDictionary<string, int>(values.ToDictionary(item => item.Key, item => item.Value));
sealed record Measurement(double Milliseconds, long AllocatedBytes, double BytesPerCall);
