$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/17917/Desktop/Card'
$taskRoot=[IO.Path]::GetFullPath('C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336')
$taskDir=Join-Path $taskRoot 'iteration11'
$deliverable=[IO.Path]::GetFullPath('docs/benchmarks/2026-10-13-architecture-compiled-query-reuse')
$routine=Get-Content -LiteralPath (Join-Path $taskDir 'routine-summary.json') -Raw | ConvertFrom-Json
$failures=@(foreach($kind in @('core','wpf')){
    $lines=Get-Content -LiteralPath (Join-Path $taskDir "routine-$kind.log")
    for($i=0;$i -lt $lines.Count;$i++){if($lines[$i] -match '\[FAIL\]'){[ordered]@{scope=$kind;failure=$lines[$i];detail=$lines[$i+1]}}}
})
$failures | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $taskDir 'routine-failures.json') -Encoding utf8
$probe=Get-Content -LiteralPath (Join-Path $taskDir 'empty-dictionary-allocation.json') -Raw | ConvertFrom-Json
$beforeTimes=@($probe.Samples.Baseline.Milliseconds | Sort-Object)
$afterTimes=@($probe.Samples.Candidate.Milliseconds | Sort-Object)
$allocation=[ordered]@{scope=$probe.Scope;runtime=$probe.Runtime;baselineBytesPerCall=@($probe.Samples.Baseline.BytesPerCall | Sort-Object -Unique);candidateBytesPerCall=@($probe.Samples.Candidate.BytesPerCall | Sort-Object -Unique);medianBaselineMillisecondsPer10000=($beforeTimes[3]+$beforeTimes[4])/2;medianCandidateMillisecondsPer10000=($afterTimes[3]+$afterTimes[4])/2;candidateAssemblySha256=$probe.CandidateAssemblySha256}
$files=@(Get-ChildItem -LiteralPath $taskDir -File -Recurse -Force | Sort-Object FullName)
$manifest=@(foreach($file in $files){if($file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked evidence'};[ordered]@{path=[IO.Path]::GetRelativePath($taskDir,$file.FullName).Replace('\','/');length=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}})
$manifest | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $deliverable 'evidence-manifest.json') -Encoding utf8
$zipPath=Join-Path $deliverable 'evidence.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Preserve existing archive before update'}
[IO.Compression.ZipFile]::CreateFromDirectory($taskDir,$zipPath,[IO.Compression.CompressionLevel]::Optimal,$false)
$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{
    if($zip.Entries.Count -ne $manifest.Count){throw 'Archive count mismatch'}
    foreach($item in $manifest){
        $entry=$zip.GetEntry($item.path)
        if($null -eq $entry -or $entry.Length -ne $item.length){throw "Archive entry mismatch: $($item.path)"}
        $stream=$entry.Open()
        try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
        if($hash -ne $item.sha256){throw "Archive hash mismatch: $($item.path)"}
    }
}finally{$zip.Dispose()}
$summary=[ordered]@{
    generatedAt=[DateTimeOffset]::Now.ToString('O')
    structural=Get-Content -LiteralPath (Join-Path $taskDir 'structural-results.json') -Raw | ConvertFrom-Json
    ownedInputs=Get-Content -LiteralPath (Join-Path $taskDir 'owned-final-source-hashes.json') -Raw | ConvertFrom-Json
    focused=[ordered]@{corePassed=13;coreFailed=0;wpfPassed=4;wpfFailed=0;run=Get-Content -LiteralPath (Join-Path $taskDir 'focused-summary.json') -Raw | ConvertFrom-Json}
    routine=[ordered]@{corePassed=556;coreFailed=2;coreTotal=558;wpfPassed=75;wpfFailed=0;run=$routine;failures=$failures;parallelScopes=$true}
    drift=Get-Content -LiteralPath (Join-Path $taskDir 'routine-source-drift.json') -Raw | ConvertFrom-Json
    allocation=$allocation
    evidence=[ordered]@{path=$zipPath;files=$manifest.Count;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Get-FileHash -LiteralPath $zipPath).Hash;allEntryHashesVerified=$true}
    cleanup=[ordered]@{taskRoot=$taskRoot;taskTemporaryPath=$taskDir;probeOutputReused=Join-Path $taskRoot 'iteration10/allocation-probe-output';newBuildOutputDirectories=0;blockedDeletionRetried=$false;verificationReasonsRestored=$true;disposableTaskEvidence='archive verified; cleanup pending'}
    limits=@('No manual Full','No foreground desktop acceptance','Two concurrent named-ambush failures remain','Later fixture changes unverified','Source-expression component allocation comparison only')
}
$summary | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $deliverable 'summary.json') -Encoding utf8
[ordered]@{archive=$summary.evidence;allocation=$allocation;routineStatus=$routine.status;routineDurationMs=$routine.durationMs} | ConvertTo-Json -Depth 5
