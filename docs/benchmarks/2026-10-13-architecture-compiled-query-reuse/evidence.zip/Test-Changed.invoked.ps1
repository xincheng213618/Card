#requires -Version 7.0
<#
.SYNOPSIS
Builds an isolated test scope once, then registers bulky outputs for manual cleanup.

.EXAMPLE
./tools/Test-Changed.ps1
# Routine shared mechanisms and representative UI checks; see VerificationScopes.psd1.

.EXAMPLE
./tools/Test-Changed.ps1 -CoreFilter @('draw-phase', 'lifecycle programs')

.EXAMPLE
./tools/Test-Changed.ps1 -WpfFilter 'public reveal'
# Binaries and renders remain available until the user runs tools/cleanup_temp.py.

.EXAMPLE
./tools/Test-Changed.ps1 -Full
#>
[CmdletBinding()]
param(
    [string[]] $CoreFilter,
    [string[]] $WpfFilter,
    [switch] $Full,
    [string] $ArtifactsPath,
    [switch] $KeepArtifacts,
    [string] $CleanupDatabase = (Join-Path $PSScriptRoot 'cleanup_queue.json')
)

$ErrorActionPreference = 'Stop'
$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$coreProject = Join-Path $repoRoot 'tests/CardGame.Core.Tests/CardGame.Core.Tests.csproj'
$wpfProject = Join-Path $repoRoot 'tests/CardGame.Wpf.Tests/CardGame.Wpf.Tests.csproj'
$solution = Join-Path $repoRoot 'CardGame.sln'

if ([string]::IsNullOrWhiteSpace($ArtifactsPath)) {
    $normalizedRoot = $repoRoot.TrimEnd([IO.Path]::DirectorySeparatorChar).ToUpperInvariant()
    $bytes = [Text.Encoding]::UTF8.GetBytes($normalizedRoot)
    $hashBytes = [Security.Cryptography.SHA256]::HashData($bytes)
    $hash = [Convert]::ToHexString($hashBytes).Substring(0, 12).ToLowerInvariant()
    $ArtifactsPath = Join-Path ([IO.Path]::GetTempPath()) "CardGame-TestChanged-$hash"
}
$ArtifactsPath = [IO.Path]::GetFullPath($ArtifactsPath).TrimEnd([IO.Path]::DirectorySeparatorChar)
$summaryPath = Join-Path $ArtifactsPath 'summary.json'
$logRoot = Join-Path $ArtifactsPath 'logs'
$ownerPath = Join-Path $ArtifactsPath '.test-changed-owner.json'

$started = [DateTimeOffset]::Now
$steps = [Collections.Generic.List[object]]::new()
$status = 'config-error'
$message = $null
$exitCode = 1
$lock = $null
$ownsLock = $false
$ownsArtifacts = $false
$buildStarted = $false
$routine = $false
$cleanup = [ordered]@{ status = 'not-needed'; queued = @(); database = [IO.Path]::GetFullPath($CleanupDatabase); message = $null }

function Assert-ArtifactOwnership {
    # Refuse source roots, drive roots and linked paths before creating or removing anything.
    $prefix = $ArtifactsPath + [IO.Path]::DirectorySeparatorChar
    if ($repoRoot.Equals($ArtifactsPath, [StringComparison]::OrdinalIgnoreCase) -or
        $repoRoot.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or
        [string]::IsNullOrEmpty([IO.Path]::GetFileName($ArtifactsPath))) {
        throw 'ArtifactsPath must be a dedicated output directory, not a source ancestor or drive root.'
    }
    for ($ancestor = [IO.DirectoryInfo]::new($ArtifactsPath); $null -ne $ancestor; $ancestor = $ancestor.Parent) {
        if ($ancestor.Exists -and ($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw "ArtifactsPath cannot pass through a linked directory: '$($ancestor.FullName)'."
        }
    }
    if (Test-Path -LiteralPath $ownerPath) {
        $owner = Get-Content -LiteralPath $ownerPath -Raw | ConvertFrom-Json
        if ($owner.formatVersion -ne 1 -or $owner.repository -ne $repoRoot -or $owner.artifactsPath -ne $ArtifactsPath) {
            throw "ArtifactsPath is owned by a different checkout: '$ArtifactsPath'."
        }
    }
    elseif (Test-Path -LiteralPath $summaryPath) {
        $previous = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json
        if ($previous.repository -ne $repoRoot -or $previous.artifactsPath -ne $ArtifactsPath) {
            throw "Existing verification outputs have a different owner: '$ArtifactsPath'."
        }
    }
    elseif ((Test-Path -LiteralPath $ArtifactsPath) -and
        @(Get-ChildItem -LiteralPath $ArtifactsPath -Force | Where-Object Name -ne '.test-changed.lock').Count -gt 0) {
        throw "ArtifactsPath is not empty and has no matching verification owner: '$ArtifactsPath'."
    }
}

function Register-VerificationOutputs {
    Assert-ArtifactOwnership
    $resolvedRoot = (Resolve-Path -LiteralPath $ArtifactsPath).Path
    $targets = @(foreach ($name in @('bin', 'obj', 'renders')) {
        $candidate = Join-Path $resolvedRoot $name
        if (Test-Path -LiteralPath $candidate) { $candidate }
    })
    if ($targets.Count -eq 0) { return }
    & python -B (Join-Path $PSScriptRoot 'cleanup_temp.py') --database $cleanup.database --add @targets --root $resolvedRoot --lock-root $resolvedRoot --reason "Test-Changed verification output ($status); safe to clean after inspection."
    if ($LASTEXITCODE -ne 0) { throw "Could not register outputs in '$($cleanup.database)'. Retained '$ArtifactsPath'." }
    $cleanup.queued = $targets
    $cleanup.status = 'queued'
}

function Invoke-LoggedStep {
    param([string] $Name, [string] $LogName, [scriptblock] $Action)
    $stepStarted = [DateTimeOffset]::Now
    $logPath = Join-Path $logRoot $LogName
    Write-Host "==> $Name"
    $global:LASTEXITCODE = 0
    try {
        & $Action 2>&1 | Tee-Object -LiteralPath $logPath | Out-Host
        $code = if ($null -eq $global:LASTEXITCODE) { 0 } else { $global:LASTEXITCODE }
    }
    catch {
        $_ | Out-String | Tee-Object -LiteralPath $logPath -Append | Out-Host
        $code = 1
    }
    $ended = [DateTimeOffset]::Now
    $steps.Add([ordered]@{
        name = $Name; status = $(if ($code -eq 0) { 'passed' } else { 'failed' })
        exitCode = $code; durationMs = [int64]($ended - $stepStarted).TotalMilliseconds
        log = $logPath
    })
    return $code
}

function Find-TestAssembly {
    param([string] $AssemblyName)
    $projectName = [IO.Path]::GetFileNameWithoutExtension($AssemblyName)
    $projectOutput = Join-Path $ArtifactsPath "bin/$projectName/release"
    $assemblyPath = Join-Path $projectOutput $AssemblyName
    $runtimeName = [IO.Path]::ChangeExtension($AssemblyName, '.runtimeconfig.json')
    if (-not (Test-Path -LiteralPath $assemblyPath) -or
        -not (Test-Path -LiteralPath (Join-Path $projectOutput $runtimeName))) {
        throw "The selected project has no runnable Release output at '$assemblyPath'."
    }
    return $assemblyPath
}

function Invoke-TestAssembly {
    param([string] $Assembly, [string] $Scope, [string[]] $Filters, [switch] $RunFull)
    [string[]] $testArguments = if ($Scope -eq 'WPF') {
        @(Join-Path $ArtifactsPath 'renders')
    } else { @() }
    if ($VerbosePreference -eq 'Continue') { $testArguments += '--verbose' }
    if ($RunFull) {
        return Invoke-LoggedStep "$Scope full checks" "$($Scope.ToLowerInvariant())-full.log" { & dotnet $Assembly @testArguments }
    }
    $filterArguments = @($Filters | ForEach-Object { "--filter=$_" })
    return Invoke-LoggedStep "$Scope selected checks ($($Filters.Count) filters, union)" "$($Scope.ToLowerInvariant())-selected.log" {
        & dotnet $Assembly @testArguments @filterArguments
    }
}

function Invoke-ParallelTestAssemblies {
    param([string] $CoreAssembly, [string] $WpfAssembly)
    $command = Get-Command dotnet -ErrorAction Stop
    while ($command -is [Management.Automation.AliasInfo]) { $command = $command.ResolvedCommand }
    $prefixArguments = @()
    if ($command -is [Management.Automation.ApplicationInfo]) { $executable = $command.Source }
    elseif ($command -is [Management.Automation.ExternalScriptInfo]) {
        $executable = Join-Path $PSHOME $(if ($IsWindows) { 'pwsh.exe' } else { 'pwsh' })
        $prefixArguments = @('-NoLogo', '-NoProfile', '-File', $command.Source)
    }
    else { throw 'Parallel verification requires dotnet to resolve to an executable or script.' }

    $children = [Collections.Generic.List[object]]::new()
    $failed = 0
    try {
        foreach ($scope in @('Core', 'WPF')) {
            $filters = if ($scope -eq 'Core') { $CoreFilter } else { $WpfFilter }
            $assembly = if ($scope -eq 'Core') { $CoreAssembly } else { $WpfAssembly }
            $name = if ($Full) { "$scope full checks" } else { "$scope selected checks ($($filters.Count) filters, union)" }
            $logName = "$($scope.ToLowerInvariant())-$(if ($Full) { 'full' } else { 'selected' }).log"
            $logPath = Join-Path $logRoot $logName
            $arguments = @($assembly)
            if ($scope -eq 'WPF') { $arguments += Join-Path $ArtifactsPath 'renders' }
            if ($VerbosePreference -eq 'Continue') { $arguments += '--verbose' }
            if (-not $Full) { $arguments += @($filters | ForEach-Object { "--filter=$_" }) }
            $info = [Diagnostics.ProcessStartInfo]::new()
            $info.FileName = $executable
            $info.UseShellExecute = $false
            $info.CreateNoWindow = $true
            $info.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
            $info.WorkingDirectory = $repoRoot
            $info.RedirectStandardOutput = $true
            $info.RedirectStandardError = $true
            $info.StandardOutputEncoding = [Text.UTF8Encoding]::new($false)
            $info.StandardErrorEncoding = [Text.UTF8Encoding]::new($false)
            foreach ($argument in @($prefixArguments) + @($arguments)) { $info.ArgumentList.Add($argument) }
            $process = [Diagnostics.Process]::new()
            $process.StartInfo = $info
            $child = [pscustomobject]@{
                Name = $name; LogPath = $logPath; Process = $process; StartedAt = [DateTimeOffset]::Now
                Writer = [IO.StreamWriter]::new($logPath, $false, [Text.UTF8Encoding]::new($false))
                Started = $false; LaunchFailed = $false; Completed = $false; StdOut = $null; StdErr = $null; Result = $null
            }
            $child.Writer.AutoFlush = $true
            $children.Add($child)
            Write-Host "==> $name (parallel)"
            try {
                [void]$process.Start()
                $child.Started = $true
                $child.StdOut = $process.StandardOutput.ReadLineAsync()
                $child.StdErr = $process.StandardError.ReadLineAsync()
            }
            catch {
                $child.LaunchFailed = $true
                $child.Writer.WriteLine($_.Exception.ToString())
                Write-Host $_.Exception.Message
            }
        }
        while (@($children | Where-Object { -not $_.Completed }).Count -gt 0) {
            foreach ($child in $children) {
                if ($child.Completed) { continue }
                foreach ($stream in @('StdOut', 'StdErr')) {
                    while ($null -ne $child.$stream -and $child.$stream.IsCompleted) {
                        $line = $child.$stream.GetAwaiter().GetResult()
                        if ($null -eq $line) { $child.$stream = $null; break }
                        $child.Writer.WriteLine($line)
                        Write-Host $line
                        $child.$stream = if ($stream -eq 'StdOut') { $child.Process.StandardOutput.ReadLineAsync() }
                            else { $child.Process.StandardError.ReadLineAsync() }
                    }
                }
                if ($child.LaunchFailed -or ($null -eq $child.StdOut -and $null -eq $child.StdErr -and $child.Process.HasExited)) {
                    $ended = [DateTimeOffset]::Now
                    $code = if ($child.LaunchFailed) { 1 } else { $child.Process.ExitCode }
                    if ($code -ne 0) { $failed = 1 }
                    $child.Result = [ordered]@{
                        name = $child.Name; status = $(if ($code -eq 0) { 'passed' } else { 'failed' })
                        exitCode = $code; durationMs = [int64]($ended - $child.StartedAt).TotalMilliseconds
                        log = $child.LogPath; startedAt = $child.StartedAt.ToString('O'); endedAt = $ended.ToString('O')
                        processId = $(if ($child.Started) { $child.Process.Id } else { $null })
                    }
                    $child.Completed = $true
                }
            }
            if (@($children | Where-Object { -not $_.Completed }).Count -gt 0) { Start-Sleep -Milliseconds 20 }
        }
        foreach ($child in $children) { $steps.Add($child.Result) }
    }
    finally {
        # No reader or child may outlive the artifact lease, including an interrupted parent.
        $cleanupErrors = [Collections.Generic.List[Exception]]::new()
        foreach ($child in $children) {
            try {
                if ($child.Started) {
                    try {
                        if (-not $child.Process.HasExited) { $child.Process.Kill($true) }
                    }
                    catch { $cleanupErrors.Add($_.Exception) }
                    # If termination races with exit or fails, keep the lease until
                    # this child has actually ended before considering the next one.
                    $child.Process.WaitForExit()
                }
            }
            catch { $cleanupErrors.Add($_.Exception) }
            finally {
                try { $child.Writer.Dispose() }
                catch { $cleanupErrors.Add($_.Exception) }
                finally {
                    try { $child.Process.Dispose() }
                    catch { $cleanupErrors.Add($_.Exception) }
                }
            }
        }
        if ($cleanupErrors.Count -gt 0) { throw [AggregateException]::new('Parallel runner cleanup failed.', $cleanupErrors) }
    }
    return $failed
}

try {
    Assert-ArtifactOwnership
    [IO.Directory]::CreateDirectory($ArtifactsPath) | Out-Null
    try {
        $lockPath = Join-Path $ArtifactsPath '.test-changed.lock'
        $lock = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        $ownsLock = $true
    }
    catch [IO.IOException] {
        $status = 'lock-busy'
        $message = "Another Test-Changed run owns '$ArtifactsPath'."
        throw
    }
    Assert-ArtifactOwnership
    [ordered]@{ formatVersion = 1; repository = $repoRoot; artifactsPath = $ArtifactsPath } |
        ConvertTo-Json | Set-Content -LiteralPath $ownerPath -Encoding utf8
    $ownsArtifacts = $true
    [IO.Directory]::CreateDirectory($logRoot) | Out-Null

    $CoreFilter = @($CoreFilter | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $WpfFilter = @($WpfFilter | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($Full -and ($CoreFilter.Count -gt 0 -or $WpfFilter.Count -gt 0)) {
        throw '-Full cannot be combined with -CoreFilter or -WpfFilter.'
    }
    if (-not $Full -and $CoreFilter.Count -eq 0 -and $WpfFilter.Count -eq 0) {
        if ($PSBoundParameters.ContainsKey('CoreFilter') -or $PSBoundParameters.ContainsKey('WpfFilter')) {
            throw 'Explicit filters cannot all be empty; omit filter parameters for the routine scope.'
        }
        $routine = $true
        $routineScope = Import-PowerShellDataFile -LiteralPath (Join-Path $PSScriptRoot 'VerificationScopes.psd1')
        $CoreFilter = @($routineScope.Core)
        $WpfFilter = @($routineScope.Wpf)
        Write-Host 'Routine scope: shared mechanisms and representative UI; use -Full for all registered checks.'
    }
    $CoreFilter = @($CoreFilter | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $WpfFilter = @($WpfFilter | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if (-not $Full -and $CoreFilter.Count -eq 0 -and $WpfFilter.Count -eq 0) {
        throw 'The selected verification scope is empty; no build or checks were started.'
    }

    $status = 'run-failed'
    $buildTarget = if ($Full -or ($CoreFilter.Count -gt 0 -and $WpfFilter.Count -gt 0)) {
        $solution
    } elseif ($WpfFilter.Count -gt 0) {
        $wpfProject
    } else {
        $coreProject
    }
    $buildStarted = $true
    $buildCode = Invoke-LoggedStep 'Build selected scope' 'build.log' {
        & dotnet build $buildTarget -c Release --artifacts-path $ArtifactsPath
    }
    if ($buildCode -ne 0) {
        $status = 'build-failed'
        $message = 'The selected scope did not build; checks were not started.'
    }
    else {
        $testFailed = 0
        if (($Full -or $CoreFilter.Count -gt 0) -and ($Full -or $WpfFilter.Count -gt 0)) {
            $coreAssembly = Find-TestAssembly 'CardGame.Core.Tests.dll'
            $wpfAssembly = Find-TestAssembly 'CardGame.Wpf.Tests.dll'
            $testFailed = Invoke-ParallelTestAssemblies $coreAssembly $wpfAssembly
        }
        elseif ($CoreFilter.Count -gt 0) {
            $coreAssembly = Find-TestAssembly 'CardGame.Core.Tests.dll'
            if ((Invoke-TestAssembly $coreAssembly 'Core' $CoreFilter) -ne 0) { $testFailed = 1 }
        }
        elseif ($WpfFilter.Count -gt 0) {
            $wpfAssembly = Find-TestAssembly 'CardGame.Wpf.Tests.dll'
            if ((Invoke-TestAssembly $wpfAssembly 'WPF' $WpfFilter) -ne 0) { $testFailed = 1 }
        }
        if ($testFailed -eq 0) { $status = 'passed'; $exitCode = 0 }
        else { $status = 'test-failed'; $message = 'One or more selected checks failed.' }
    }
}
catch {
    if ($null -eq $message) { $message = $_.Exception.Message }
    Write-Host "ERROR: $message" -ForegroundColor Red
}
finally {
    if ($ownsArtifacts -and $buildStarted) {
        try {
            Register-VerificationOutputs
            if ($KeepArtifacts) { Write-Host '-KeepArtifacts is no longer needed; outputs remain until manual cleanup.' }
        }
        catch {
            $cleanup.status = 'registration-failed'
            $cleanup.message = $_.Exception.Message
            if ($status -eq 'passed') { $status = 'cleanup-registration-failed'; $message = $cleanup.message }
            $exitCode = 1
            Write-Warning "Cleanup registration failed: $($cleanup.message)"
        }
    }
    $ended = [DateTimeOffset]::Now
    $summary = [ordered]@{
        status = $status
        mode = $(if ($Full) { 'full' } elseif ($routine) { 'routine' } else { 'targeted' })
        repository = $repoRoot
        artifactsPath = $ArtifactsPath
        coreFilters = @($CoreFilter)
        wpfFilters = @($WpfFilter)
        startedAt = $started.ToString('O')
        durationMs = [int64]($ended - $started).TotalMilliseconds
        message = $message
        results = @($steps)
        cleanup = $cleanup
    }
    try {
        if ($ownsArtifacts) {
            $summary | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $summaryPath -Encoding utf8
            Write-Host "Summary: $summaryPath"
        }
    }
    finally {
        if ($null -ne $lock) { $lock.Dispose() }
    }
    Write-Host "Status: $status"
}
exit $exitCode
