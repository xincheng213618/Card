﻿namespace CardGame.Core;

/// <summary>Generic lifecycle-program host. It contains no character or skill ids.</summary>
public sealed partial class GameEngine
{
    private SkillProgramStepOutcome StartProgramPindian(
        ProgramSkillFrame frame,
        ProgramParticipantReference opponentReference,
        string resultBind,
        SkillProgramCardSetVisibility visibility)
    {
        var eventOpponent = opponentReference.Kind == ProgramParticipantRef.EventTarget &&
            frame.WindowContext is { Window: SkillProgramTriggerWindow.AfterDamageApplied, TargetSeat: { } };
        var phaseOpponent = opponentReference.Kind == ProgramParticipantRef.SelectedTarget &&
            (frame.WindowContext is { Window: SkillProgramTriggerWindow.PlayPhaseStarting } ||
             IsExactOwnPlayEndingPindian(frame, opponentReference, resultBind, visibility) || IsForeignActualTurnPindian(frame));
        if (!eventOpponent && (frame.TriggerId is not null && !phaseOpponent ||
                opponentReference.Kind != ProgramParticipantRef.SelectedTarget ||
                frame.SelectedTargetSeats.Count != 1 ||
                _cardZones.CardsAt(CardLocation.Processing).Count != 0) ||
            frame.PindianResultBindings.Any(item => item.Name == resultBind) || HasPendingProgramBoundCards)
            throw new InvalidOperationException(
                "Program Pindian requires an active selected opponent or a damage-event opponent and no pending program cards.");
        var opponentSeat = eventOpponent ? frame.WindowContext!.TargetSeat!.Value :
            frame.SelectedTargetSeats.Single();
        var source = _players[frame.OwnerSeat];
        var opponent = _players[opponentSeat];
        if (!source.IsAlive || !opponent.IsAlive || opponentSeat == frame.OwnerSeat || !CanBePindianTarget(source.Seat, opponentSeat) ||
            GetHand(source).Count == 0 || GetHand(opponent).Count == 0)
            throw new InvalidOperationException("Program Pindian participants no longer have legal hand cards.");
        var skill = _contentRegistry!.GetSkill(frame.SkillId);
        BeginSharedPindian(
            frame.Id,
            new SkillPromptPresentation(frame.SkillId, skill.Name, $"{skill.Name} · 拼点", skill.Description),
            frame.OwnerSeat,
            opponentSeat,
            programResultBind: resultBind,
            programResultVisibility: visibility);
        return SkillProgramStepOutcome.AwaitChild;
    }

    private ProgramPhaseSchedule? _programPhaseSchedule;

    private bool IsExactOwnPlayEndingPindian(ProgramSkillFrame frame, ProgramParticipantReference opponentReference,
        string resultBind, SkillProgramCardSetVisibility visibility)
    {
        if (!IsExactOwnPlayEndingProgram(frame) || frame.InstructionIndex <= 0 ||
            _resolutionStack.LastOrDefault()?.Id != frame.Id) return false;
        var effect = ProgramInstructionResolver.Default.Resolve(frame, _contentRegistry.GetSkill(frame.SkillId).Program!)
            .GetPausedInstruction(frame.InstructionIndex).Effect;
        return effect.Op == SkillProgramEffectOp.StartPindian && effect.OpponentReference == opponentReference &&
            effect.ResultBind == resultBind && effect.Visibility == visibility &&
            effect.Condition.Kind == SkillProgramConditionKind.Always;
    }

    private bool HasProgramLifecycleBoundaryFrame()
    {
        if (_resolutionStack.FirstOrDefault() is not ProgramLifecycleTriggerWindowFrame frame)
            return false;
        if (frame.OwnerSeat != _currentSeat && frame.CharacterStateContinuation is null || frame.CandidateIndex < 0 ||
            frame.CandidateIndex >= frame.Candidates.Count)
            throw new InvalidOperationException("The lifecycle boundary frame lost its owner or candidate cursor.");
        if (frame.Window == SkillProgramTriggerWindow.DrawPhaseEnded &&
            (frame.DrawPhaseEndedDelayedEffects is not { } effects || effects is < 0 or > 15 ||
                (effects & (int)DelayedTurnEffects.SkipDrawPhase) != 0 || frame.Continuation != ProgramLifecycleContinuation.CompleteDrawPhaseEnded) ||
            frame.Window != SkillProgramTriggerWindow.DrawPhaseEnded && frame.DrawPhaseEndedDelayedEffects is not null)
            throw new InvalidOperationException("Draw end continuation must describe an actual completed draw phase.");
        if (frame.Window == SkillProgramTriggerWindow.PlayEnding && _phase != TurnPhase.Play && !IsTerminalPhaseHandDebtBoundary(frame))
            throw new InvalidOperationException("A PlayEnding lifecycle frame must remain in its Play phase.");
        if (frame.Window is (SkillProgramTriggerWindow.DrawPhaseStarting or
            SkillProgramTriggerWindow.AfterNormalDraw or SkillProgramTriggerWindow.DrawPhaseEnded) && _phase != TurnPhase.Draw)
            throw new InvalidOperationException("A DrawPhaseStarting lifecycle frame must remain in its Draw phase.");
        if (frame.Window == SkillProgramTriggerWindow.DiscardPhaseStarting && _phase != TurnPhase.Discard)
            throw new InvalidOperationException("A DiscardPhaseStarting lifecycle frame must remain in its Discard phase.");
        if (frame.Window == SkillProgramTriggerWindow.DiscardPhaseEnded && _phase != TurnPhase.Discard)
            throw new InvalidOperationException("A DiscardPhaseEnded lifecycle frame must remain in its Discard phase.");
        if (frame.Window != SkillProgramTriggerWindow.DrawPhaseStarting && frame.NormalDrawAdjustment != 0)
            throw new InvalidOperationException("Only a DrawPhaseStarting lifecycle frame may adjust normal draws.");
        if (frame.Window == SkillProgramTriggerWindow.GameStarting && _phase != TurnPhase.NotStarted)
            throw new InvalidOperationException("A game-starting lifecycle frame must precede the first turn.");
        if (frame.Window == SkillProgramTriggerWindow.RoundStarting &&
            (frame.Continuation != ProgramLifecycleContinuation.RoundProgramsTurnStart || _roundNumber <= 0 ||
             _turnProgression.Kind == ActualTurnKind.Extra))
            throw new InvalidOperationException("A round-starting boundary requires its normal turn continuation and actual round.");
        if (frame.Window is not (SkillProgramTriggerWindow.RoundStarting or SkillProgramTriggerWindow.GameStarting or SkillProgramTriggerWindow.TurnStartBeforeNormalFlow or
            SkillProgramTriggerWindow.DrawPhaseStarting or
            SkillProgramTriggerWindow.AfterNormalDraw or SkillProgramTriggerWindow.DrawPhaseEnded or
            SkillProgramTriggerWindow.PlayEnding or
            SkillProgramTriggerWindow.DiscardPhaseStarting or
            SkillProgramTriggerWindow.DiscardPhaseEnded or SkillProgramTriggerWindow.JudgmentPhaseStarting or
            SkillProgramTriggerWindow.CharacterTurnedOver or SkillProgramTriggerWindow.CharacterTurnedFaceUp or SkillProgramTriggerWindow.CharacterEnteredChain))
            throw new InvalidOperationException("This lifecycle window cannot own a clean phase boundary.");
        return true;
    }

    private bool HasTurnEndingBoundaryFrame()
    {
        if (_resolutionStack.FirstOrDefault() is not TurnEndingBoundaryFrame frame)
            return false;
        if (frame.OwnerSeat != _currentSeat || frame.TurnNumber != _turnNumber ||
            frame.Facts is null || frame.ItemIndex < 0 || frame.ItemIndex >= frame.Items.Count)
            throw new InvalidOperationException("The turn-ending boundary lost its owner, turn or item cursor.");
        if (_resolutionStack.Count == 1 && frame.Step == ResolutionFrameStep.AwaitingResponse)
        {
            var decisionKind = frame.Items[frame.ItemIndex].Kind switch
            {
                TurnEndingBoundaryItemKind.Program => DecisionKind.ProgramTrigger,
                _ => throw new InvalidOperationException("Unsupported turn-ending item kind.")
            };
            if (_pendingDecision?.Kind != decisionKind)
                throw new InvalidOperationException("The turn-ending boundary is waiting without its matching prompt.");
        }
        return true;
    }

    private bool HasPlayPhaseStartingBoundaryFrame()
    {
        if (_resolutionStack.FirstOrDefault() is not PlayPhaseStartingBoundaryFrame frame)
            return false;
        if (frame.OwnerSeat != _currentSeat || frame.ItemIndex < 0 ||
            frame.ItemIndex > frame.Items.Count)
            throw new InvalidOperationException("The play-phase-starting boundary lost its owner or item cursor.");
        if (_phase != TurnPhase.Play)
            throw new InvalidOperationException("A play-phase-starting boundary must remain in its Play phase.");
        if (_resolutionStack.Count == 1 && frame.Step == ResolutionFrameStep.AwaitingResponse)
        {
            var decisionKind = frame.Items[frame.ItemIndex].Kind switch
            {
                TurnEndingBoundaryItemKind.Program => DecisionKind.ProgramTrigger,
                _ => throw new InvalidOperationException("Unsupported play-phase-starting item kind.")
            };
            if (_pendingDecision?.Kind != decisionKind)
                throw new InvalidOperationException("The play-phase-starting boundary is waiting without its matching prompt.");
        }
        return true;
    }

    private void BeginNormalTurnStartAfterProgramBindings(CharacterState current)
    {
        BeginTurnStartAfterProgramLifecycle(current);
    }

    private void CompleteCurrentPlayPhase()
    {
        if (TryBeginPlayEndingProgramWindow(_players[_currentSeat])) return;
        CompletePlayPhaseAfterProgramWindow();
    }

    private void CompletePlayPhaseAfterProgramWindow()
    {
        CloseCurrentPlayPhaseSkillGrants("play-phase-ended");
        _programPhaseColorRestrictions.Clear();
        ResetPlayPhaseProgramStates(_currentSeat);
        if (ResumeScheduledProgramPhase()) return;
        BeginDiscardPhase();
    }

    private ProgramSkillFrame GetActiveProgramFrame(long frameId) =>
        _resolutionStack.LastOrDefault() is ProgramSkillFrame frame && frame.Id == frameId
            ? frame
            : throw new InvalidOperationException($"Program frame {frameId} is not active.");

    private SkillProgramTrigger GetProgramTrigger(ProgramSkillFrame frame)
    {
        var triggerId = frame.TriggerId ??
            throw new InvalidOperationException("The active program frame is not a trigger binding.");
        var program = _contentRegistry.GetSkill(frame.SkillId).Program ??
            throw new InvalidOperationException("The active program binding has no definition.");
        if (program.GameplayHash != frame.GameplayHash)
            throw new InvalidOperationException("The active program binding definition changed.");
        return ProgramInstructionResolver.Default.Resolve(program, ProgramInstructionSourceKind.Trigger, triggerId).Trigger!;
    }

    private static string GetProgramBindingId(ProgramSkillFrame frame) =>
        frame.TriggerId ?? frame.ActivationId;

    private void SetProgramCardSet(
        long frameId,
        string bind,
        IReadOnlyList<int> cardIds,
        SkillProgramCardSetVisibility visibility,
        IReadOnlyList<CardLocation>? sourceLocations = null,
        Suit? frozenRevealedSuit = null, int? selectionActorSeat = null)
    {
        var frame = GetActiveProgramFrame(frameId);
        if (frame.CardSetBindings.Any(binding => binding.Name == bind))
            throw new InvalidOperationException($"Program card-set binding '{bind}' already exists.");
        var ids = cardIds.ToArray();
        var locations = (sourceLocations ?? ids
            .Select(cardId => _cardZones.GetLocation(cardId)).ToArray()).ToArray();
        if (selectionActorSeat is { } actor && !IsValidPlayerSeat(actor))
            throw new InvalidOperationException("The selection producer has an invalid actual actor.");
        if (ids.Distinct().Count() != ids.Length || ids.Length != locations.Length)
            throw new InvalidOperationException("A program card-set binding requires unique cards and aligned source locations.");
        ReplaceRuntimeTop(frame with
        {
            CardSetBindings = Array.AsReadOnly(frame.CardSetBindings
                .Append(new ProgramSkillCardSetBinding(
                    bind,
                    Array.AsReadOnly(ids),
                    visibility,
                    Array.AsReadOnly(locations))
                { FrozenRevealedSuit = frozenRevealedSuit, SelectionActorSeat = HasForeignDiscardCapability ? selectionActorSeat : null })
                .ToArray())
        });
    }

    private ProgramSkillCardSetBinding GetProgramCardSet(ProgramSkillFrame frame, string bind) =>
        frame.CardSetBindings.SingleOrDefault(binding => binding.Name == bind) ??
        throw new InvalidOperationException($"Program card-set binding '{bind}' is unavailable.");

    private SkillProgramStepOutcome ScheduleProgramPhase(
        ProgramSkillFrame frame,
        TurnPhase phase,
        SkillProgramPhaseContinuation continuation,
        int? beneficiarySeat = null)
    {
        var playEndingGrant = frame.WindowContext?.Window == SkillProgramTriggerWindow.PlayEnding;
        if (phase is not (TurnPhase.Play or TurnPhase.Draw) || continuation != SkillProgramPhaseContinuation.BeforeNormalPreparation ||
            frame.WindowContext is not { } context ||
            context.Window is not (SkillProgramTriggerWindow.TurnStartBeforeNormalFlow or SkillProgramTriggerWindow.PlayEnding) ||
            context.OwnerSeat != frame.OwnerSeat || _programPhaseSchedule is not null ||
            GetActiveProgramFrame(frame.Id) != frame ||
            playEndingGrant && (phase != TurnPhase.Play || beneficiarySeat is null))
            throw new InvalidOperationException("The configured phase insertion does not match a clean turn-start or play-ending boundary.");
        // A play-ending grant belongs to the living current turn player; a
        // turn-start insertion keeps inserting for the program owner itself.
        var beneficiary = playEndingGrant ? beneficiarySeat!.Value : frame.OwnerSeat;
        if (playEndingGrant && (beneficiary != _currentSeat || !_players[beneficiary].IsAlive))
            throw new InvalidOperationException("A play-ending phase insertion requires the living current turn player.");

        if (_resolutionStack.Count < 2 ||
            _resolutionStack[^2] is not ProgramLifecycleTriggerWindowFrame parent ||
            parent.Id != context.ParentFrameId)
            throw new InvalidOperationException("The inserted phase lost its lifecycle parent window.");
        PopResolutionFrame(frame.Id, ResolutionFrameKind.ProgramSkill);
        PopResolutionFrame(parent.Id, ResolutionFrameKind.ProgramLifecycleTriggerWindow);
        _programPhaseSchedule = new ProgramPhaseSchedule(frame, parent, phase, continuation)
        { DiscardRecoveryReturnPhase = playEndingGrant ? null : CurrentActualDiscardRecoveryPhase() };
        AdvanceEventRulesAndQueueFact(new ProgramPhaseScheduledEvent(
            frame.Id, frame.SkillId, frame.TriggerId!, frame.OwnerSeat, phase, Started: true));
        if (phase == TurnPhase.Play) EnterPlayPhase(_players[beneficiary]);
        else
        {
            StartActualDiscardRecoveryPhase(ActualDiscardRecoveryPhaseKind.Draw, frame.OwnerSeat);
            if (!TryBeginDrawPhaseProgramWindow(_players[frame.OwnerSeat], false))
            {
                DrawCards(_players[frame.OwnerSeat], GetTurnDrawCount(_players[frame.OwnerSeat]), true);
                CompleteTurnStartAfterDraw(_players[frame.OwnerSeat], DelayedTurnEffects.None);
            }
        }
        return SkillProgramStepOutcome.AwaitChild;
    }

    private bool ResumeScheduledProgramPhase()
    {
        if (_programPhaseSchedule is not { } schedule) return false;
        var frame = FreezeGrantedEntityPhaseEnd(schedule.Frame);
        _programPhaseSchedule = null;
        AdvanceEventRulesAndQueueFact(new ProgramPhaseScheduledEvent(
            frame.Id, frame.SkillId, frame.TriggerId!, frame.OwnerSeat, schedule.Phase, Started: false));
        if (_winner != Winner.None || !_players[frame.OwnerSeat].IsAlive)
        {
            ClearActualDiscardRecoveryPhase();
            CompleteDetachedProgramBinding(frame, completed: false);
            return true;
        }
        RestoreActualDiscardRecoveryPhase(schedule);
        // Turn-start insertion temporarily entered Play. Restore its original
        // coarse phase before normal draw and after-draw triggers resume.
        if (schedule.ParentFrame.Window == SkillProgramTriggerWindow.TurnStartBeforeNormalFlow)
            _phase = TurnPhase.Draw;
        PushRuntimeFrame(schedule.ParentFrame);
        if (!HasRuntimeSkillInstance(_players[frame.OwnerSeat], frame.SkillId, frame.SkillInstanceId) && !IsReturningGrantedEntityPhase(frame))
        {
            CompleteDetachedProgramBinding(frame, completed: false);
            AdvanceProgramLifecycleCursor(schedule.ParentFrame);
            AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
            return true;
        }
        PushRuntimeFrame(frame);
        AdvanceRuntimeProgram(frame.Id);
        return true;
    }

    private void CancelScheduledProgramPhase()
    {
        if (_programPhaseSchedule is not { } schedule) return;
        _programPhaseSchedule = null;
        ClearActualDiscardRecoveryPhase();
        AdvanceEventRulesAndQueueFact(new ProgramPhaseScheduledEvent(
            schedule.Frame.Id,
            schedule.Frame.SkillId,
            schedule.Frame.TriggerId!,
            schedule.Frame.OwnerSeat,
            schedule.Phase,
            Started: false));
        CompleteDetachedProgramBinding(schedule.Frame, completed: false);
    }

    private void RecoverProgramTargetTo(
        long frameId,
        int ownerSeat,
        int targetSeat,
        SkillProgramNumberExpression expression,
        int minimumValue,
        bool clampToMaxHp)
    {
        _ = GetActiveProgramFrame(frameId);
        var target = _players[targetSeat];
        var value = expression switch
        {
            SkillProgramNumberExpression.IntegerConstant => minimumValue,
            SkillProgramNumberExpression.LivingFactionCount => GetLivingFactionCount(),
            SkillProgramNumberExpression.LivingPlayersMinHp => GetLivingPlayersMinHp(),
            _ => throw new InvalidOperationException($"Unsupported numeric expression '{expression}'.")
        };
        value = Math.Max(minimumValue, value);
        // Recovery never raises HP above MaxHp. The flag remains part of the
        // serialized primitive contract for forward-compatible numeric policies.
        value = Math.Min(target.MaxHp, value);
        var amount = Math.Max(0, value - target.Hp);
        if (amount == 0) return;
        if (TryQueueRecoveryReplacement(frameId, ownerSeat, targetSeat, amount,
            new(RecoveryAttemptProducer.Program, GetActiveProgramFrame(frameId).InstructionIndex))) return;
        var recovery = BeginRecovery(frameId, ownerSeat, targetSeat, amount);
        target.Hp += amount;
        AdvanceEventRulesAndQueueFact(new RecoveryAppliedEvent(ownerSeat, targetSeat, amount, target.Hp));
        PopResolutionFrame(recovery, ResolutionFrameKind.Recovery);
    }

    private void DiscardProgramOwnedZoneCards(
        ProgramSkillFrame frame,
        IReadOnlyList<CardZoneKind> zones,
        CardMoveReason reason)
    {
        var active = GetActiveProgramFrame(frame.Id);
        if (active.OwnerSeat != frame.OwnerSeat || active.SkillId != frame.SkillId ||
            active.ActivationId != frame.ActivationId)
        {
            throw new InvalidOperationException("Owned-zone discard requires the active program binding.");
        }

        var owner = _players[frame.OwnerSeat];
        var discarded = 0;
        foreach (var zone in zones)
        {
            var (cards, location) = zone switch
            {
                CardZoneKind.Hand => (GetHand(owner).ToArray(), CardLocation.Hand(owner.Seat)),
                CardZoneKind.Equipment => (GetEquipment(owner).ToArray(), CardLocation.Equipment(owner.Seat)),
                CardZoneKind.Judgment => (GetJudgment(owner).ToArray(), CardLocation.Judgment(owner.Seat)),
                _ => throw new InvalidOperationException($"Unsupported owned discard zone '{zone}'.")
            };
            foreach (var card in cards)
            {
                if (IsSelfHandCategoryDiscardForbidden(owner.Seat, card, location, OwnedCardMoveIntent.Discard)) continue;
                MoveCard(card, location, CardLocation.DiscardPile, reason);
                discarded++;
            }
        }

        AdvanceEventRulesAndQueueFact(new ProgramOwnedZoneCardsDiscardedEvent(
            frame.Id,
            frame.SkillId,
            GetProgramBindingId(frame),
            frame.OwnerSeat,
            Array.AsReadOnly(zones.ToArray()),
            discarded));
    }

    private void SetProgramChainedState(ProgramSkillFrame frame, bool chained, int targetSeat)
    {
        var active = GetActiveProgramFrame(frame.Id);
        if (active.OwnerSeat != frame.OwnerSeat || active.SkillId != frame.SkillId ||
            active.ActivationId != frame.ActivationId)
        {
            throw new InvalidOperationException("Chained-state mutation requires the active program binding.");
        }

        var wasChained = _players[targetSeat].IsChained;
        _players[targetSeat].IsChained = ResolveEnteringChain(_players[targetSeat], chained || HasCardPolicy(_players[targetSeat], SkillProgramCardPolicyKind.ForceChained));
        if (!wasChained && _players[targetSeat].IsChained)
            RecordCharacterStateChange(targetSeat, SkillProgramTriggerWindow.CharacterEnteredChain);
        AdvanceEventRulesAndQueueFact(new ProgramChainedStateSetEvent(
            frame.Id,
            frame.SkillId,
            GetProgramBindingId(frame),
            frame.OwnerSeat,
            _players[targetSeat].IsChained,
            targetSeat));
    }

    private void ChangeProgramMaximumHp(ProgramSkillFrame frame, int amount, string? sourceSkillId = null)
    {
        var active = GetActiveProgramFrame(frame.Id);
        if (active.OwnerSeat != frame.OwnerSeat || active.SkillId != frame.SkillId ||
            active.TriggerId != frame.TriggerId)
        {
            throw new InvalidOperationException("Maximum-HP mutation requires the active program binding.");
        }

        var owner = _players[frame.OwnerSeat];
        var previous = owner.MaxHp;
        if (sourceSkillId is not null && sourceSkillId != frame.SkillId &&
            !HasRuntimeSkillInstance(owner, sourceSkillId, GetRuntimeSkillInstanceId(owner, sourceSkillId)))
            throw new InvalidOperationException("Maximum-HP attribution requires the owner's actual source skill instance.");
        owner.MaxHp = Math.Max(1, checked(owner.MaxHp + amount));
        owner.Hp = Math.Min(owner.Hp, owner.MaxHp);
        AdvanceEventRulesAndQueueFact(new MaximumHpChangedEvent(
            owner.Seat,
            owner.MaxHp - previous,
            owner.MaxHp,
            sourceSkillId ?? frame.SkillId));
    }

    private void GrantProgramSkills(ProgramSkillFrame frame, IReadOnlyList<string> skillIds)
    {
        var active = GetActiveProgramFrame(frame.Id);
        if (active.OwnerSeat != frame.OwnerSeat || active.SkillId != frame.SkillId ||
            active.TriggerId != frame.TriggerId)
        {
            throw new InvalidOperationException("Runtime-skill grants require the active program binding.");
        }

        var owner = _players[frame.OwnerSeat];
        var acquired = IsDyingOwnerReplacementBinding(active)
            ? AcquireDyingOwnerReplacementSkills(active, skillIds)
            : AcquireRuntimeSkills(owner, frame.SkillId, skillIds);
        if ((_contentRegistry!.GetSkill(frame.SkillId).Tags & SkillTag.Awakening) != 0)
        {
            AdvanceEventRulesAndQueueFact(new SkillAwakenedEvent(
                owner.Seat,
                frame.SkillId,
                owner.MaxHp,
                acquired));
        }
    }

    private void TurnOverProgramTarget(long frameId, int ownerSeat, int targetSeat)
    {
        _ = GetActiveProgramFrame(frameId);
        var target = _players[targetSeat];
        var wasFaceDown = target.IsFaceDown;
        target.IsFaceDown = !target.IsFaceDown;
        if (!target.IsFaceDown) RecordCharacterStateChange(targetSeat, SkillProgramTriggerWindow.CharacterTurnedFaceUp);
        RecordCharacterTurnedOver(targetSeat, wasFaceDown);
        AddLog("SkillEffect", $"{target.Name} 的武将牌翻面。", ownerSeat, targetSeat);
    }

    private void SetProgramTargetFaceState(long frameId, int ownerSeat, int targetSeat, bool faceDown)
    {
        _ = GetActiveProgramFrame(frameId);
        var target = _players[targetSeat];
        var wasFaceDown = target.IsFaceDown;
        target.IsFaceDown = faceDown;
        if (wasFaceDown && !faceDown) RecordCharacterStateChange(targetSeat, SkillProgramTriggerWindow.CharacterTurnedFaceUp);
        RecordCharacterTurnedOver(targetSeat, wasFaceDown);
        AddLog("SkillEffect",
            faceDown ? $"{target.Name} 的武将牌保持或变为背面。" : $"{target.Name} 的武将牌保持或变为正面。",
            ownerSeat,
            targetSeat);
    }

    private SkillProgramStepOutcome StartProgramJudgment(
        ProgramSkillFrame frame,
        int targetSeat,
        string reason,
        string resultBind,
        SkillProgramCardSetVisibility visibility,
        int sourceSeat)
    {
        if (_resolutionStack.LastOrDefault() is not ProgramSkillFrame current || current.Id != frame.Id ||
            !MatchesProgramJudgmentInstruction(frame, targetSeat, reason, resultBind, visibility))
        {
            throw new InvalidOperationException(
                "A program judgment requires an active program target and public result.");
        }

        _ = BeginJudgment(
            attack: ActiveCardAttack,
            targetSeat,
            reason,
            frame.Id,
            sourceCard: frame.WindowContext?.CardUse?.EffectiveKind,
            JudgmentContinuationKind.ProgramSkill,
            sourceSeat: sourceSeat,
            programResultBind: resultBind,
            programResultVisibility: visibility);
        return SkillProgramStepOutcome.AwaitChild;
    }

    private bool IsValidProgramJudgmentContinuation(JudgmentFrame pending,
        ProgramSkillFrame? frame)
    {
        if (pending.Continuation != JudgmentContinuationKind.ProgramSkill || frame is null ||
            pending.ParentFrameId != frame.Id ||
            pending.ProgramResultBind is not { } bind ||
            pending.ProgramResultVisibility is not { } visibility)
            return false;
        if (!MatchesProgramJudgmentInstruction(frame, pending.TargetSeat, pending.Reason,
                bind, visibility))
            return false;
        var judged = ProgramInstructionResolver.Default.Resolve(frame,
                _contentRegistry!.GetSkill(frame.SkillId).Program!)
            .Instructions;
        if (frame.InstructionIndex < 1 || frame.InstructionIndex > judged.Count ||
            judged[frame.InstructionIndex - 1] is not { Op: SkillProgramEffectOp.StartJudgment or SkillProgramEffectOp.StartOwnedDamagePointJudgment or SkillProgramEffectOp.JudgeDamageTargetThenOfferSuitDiscard } effect)
            return true;
        var expectedSourceSeat = effect.SourceRef is { } sourceRef
            ? ResolveProgramParticipant(frame, sourceRef)
            : frame.OwnerSeat;
        return pending.SourceSeat == expectedSourceSeat;
    }

    private bool MatchesProgramJudgmentInstruction(ProgramSkillFrame frame, int targetSeat,
        string reason, string resultBind, SkillProgramCardSetVisibility visibility)
    {
        if (visibility != SkillProgramCardSetVisibility.Public || string.IsNullOrWhiteSpace(reason) ||
            string.IsNullOrWhiteSpace(resultBind) ||
            (ProgramEntryCapabilities.For(frame.WindowContext?.Window) & ProgramContextCapability.Judgment) == 0 ||
            !_contentRegistry.Skills.TryGetValue(frame.SkillId, out var definition) ||
            definition.Program is not { } program || program.GameplayHash != frame.GameplayHash)
            return false;
        var instructions = ProgramInstructionResolver.Default.Resolve(frame, program).Instructions;
        if (frame.InstructionIndex < 1 || frame.InstructionIndex > instructions.Count ||
            instructions[frame.InstructionIndex - 1] is not
            { Op: SkillProgramEffectOp.StartJudgment or SkillProgramEffectOp.StartOwnedDamagePointJudgment or SkillProgramEffectOp.RepeatJudgment or SkillProgramEffectOp.SuppressCurrentSlashTargetAndJudgeSuitDiscard or SkillProgramEffectOp.JudgeDamageTargetThenOfferSuitDiscard } effect ||
            reason != effect.JudgmentReason || resultBind != effect.ResultBind)
            return false;
        if (effect.Op == SkillProgramEffectOp.RepeatJudgment &&
            (frame.RepeatedJudgment is not { } repeated ||
             repeated.Reason != reason || repeated.ResultBind != resultBind))
            return false;
        if (effect.Op == SkillProgramEffectOp.JudgeDamageTargetThenOfferSuitDiscard)
            return IsDamageJudgmentInstructionTarget(frame, targetSeat);
        return effect.Target switch
        {
            SkillProgramEffectTarget.Owner => targetSeat == frame.OwnerSeat,
            SkillProgramEffectTarget.SelectedTarget =>
                frame.SelectedTargetSeats is [var selectedSeat] && targetSeat == selectedSeat,
            _ => false
        };
    }

    private void RevealProgramTopCards(
        long frameId,
        int ownerSeat,
        int amount,
        SkillProgramNumberExpression? numberExpression,
        string resultBind,
        SkillProgramCardSetVisibility visibility)
    {
        var frame = GetActiveProgramFrame(frameId);
        var revealCount = numberExpression switch
        {
            null => amount,
            SkillProgramNumberExpression.OwnerLostHp =>
                Math.Max(0, _players[ownerSeat].MaxHp - _players[ownerSeat].Hp),
            _ => throw new InvalidOperationException(
                $"Unsupported reveal number expression '{numberExpression}'.")
        };
        var revealed = new List<Card>(revealCount);
        var reason = new CardMoveReason($"skill-program.{frame.SkillId}.{GetProgramBindingId(frame)}.reveal");
        for (var index = 0; index < revealCount; index++)
        {
            if (DrawOneToProcessing(reason) is not { } card) break;
            revealed.Add(card);
        }
        SetProgramCardSet(frameId, resultBind, revealed.Select(card => card.Id).ToArray(), visibility);
        if (visibility == SkillProgramCardSetVisibility.Public)
            AdvanceEventRulesAndQueueFact(new ProgramCardsRevealedEvent(
                frameId, frame.SkillId, GetProgramBindingId(frame), frame.OwnerSeat, resultBind,
                Array.AsReadOnly(revealed.Select(ToSnapshot).ToArray())));
    }

    private void FilterProgramBoundCards(
        long frameId,
        string sourceBind,
        string resultBind,
        IReadOnlyList<Suit> suits,
        ProgramParticipantReference? effectiveSuitFor,
        IReadOnlyList<SkillProgramCardCategory> categories,
        IReadOnlyList<EquipmentSlot> equipmentSlots,
        IReadOnlyList<CardKind> cardKinds,
        string? matchSuitOfBind)
    {
        var frame = GetActiveProgramFrame(frameId);
        var source = GetProgramCardSet(frame, sourceBind);
        var matchedSuit = matchSuitOfBind is null ? (Suit?)null :
            GetProgramCardSet(frame, matchSuitOfBind).FrozenRevealedSuit ??
            throw new InvalidOperationException("The referenced public suit is unavailable.");
        var effectiveSuitSeat = effectiveSuitFor is null ? (int?)null : ResolveProgramParticipant(frame, effectiveSuitFor);
        var selected = source.CardIds.Select((cardId, index) =>
            {
                var location = source.SourceLocations[index];
                if (_cardZones.GetLocation(cardId) != location)
                    throw new InvalidOperationException(
                        "A bound card left its frozen source before its configured filter.");
                var card = _cardZones.CardsAt(location).Single(current => current.Id == cardId);
                return (Card: card, Location: location);
            })
            .Where(item =>
            {
                var suit = effectiveSuitSeat is { } seat ? EffectiveSuit(_players[seat], item.Card) : item.Card.Suit;
                return matchedSuit is { } required
                    ? suit == required
                    : ProgramCardSetFilter.Matches(item.Card.Kind, suit, suits, categories, equipmentSlots, cardKinds);
            })
            .ToArray();
        SetProgramCardSet(
            frameId,
            resultBind,
            selected.Select(item => item.Card.Id).ToArray(),
            source.Visibility,
            selected.Select(item => item.Location).ToArray(), selectionActorSeat: source.SelectionActorSeat);
    }

    private void DrawProgramCards(
        long frameId,
        int targetSeat,
        int amount,
        SkillProgramNumberExpression? numberExpression,
        string? resultBind,
        SkillProgramCardSetVisibility visibility,
        CardMoveReason reason)
    {
        var frame = GetActiveProgramFrame(frameId);
        var target = _players[targetSeat];
        var drawCount = numberExpression switch
        {
            null => amount,
            SkillProgramNumberExpression.CurrentHandEmptyTwoOtherwiseOne => GetHand(target).Count == 0 ? 2 : 1,
            SkillProgramNumberExpression.EquipmentHalfCeilingPlusOne => (GetEquipment(target).Count + 1) / 2 + 1,
            SkillProgramNumberExpression.CurrentTurnUsedCardCategoryCount => CurrentTurnCategoryDrawCount(frame, targetSeat),
            SkillProgramNumberExpression.ActualTurnDeathBenefits => ActualTurnDeathDrawCount(frame, targetSeat),
            SkillProgramNumberExpression.CategoryTargetTurnUsage => GetProgramCategoryTargetTurnUsage(frame),
            SkillProgramNumberExpression.SelectedTargetsHandGreaterThanLord => CountSelectedTargetsHandGreaterThanLord(frame),
            SkillProgramNumberExpression.OwnerLostHp => GetProgramOwnerLostHp(frame),
            SkillProgramNumberExpression.LostHpMinusHandCount => Math.Max(0, target.MaxHp - Math.Max(0, target.Hp) - GetHand(target).Count),
            SkillProgramNumberExpression.LivingFactionCount => GetLivingFactionCount(),
            SkillProgramNumberExpression.LivingPlayersMinHp => GetLivingPlayersMinHp(),
            SkillProgramNumberExpression.TargetMaxHpMinusHandCount =>
                Math.Max(0, target.MaxHp - GetHand(target).Count),
            SkillProgramNumberExpression.CurrentAttackRange =>
                frame.WindowContext?.Facts is { } facts && facts.CurrentAttackRange > 0
                    ? facts.CurrentAttackRange
                    : GetAttackRange(target.Seat),
            SkillProgramNumberExpression.HandLimitMinusHandCount =>
                Math.Max(0, GetHandLimit(target) - GetHand(target).Count),
            SkillProgramNumberExpression.TurnOwnerDiscardPhaseHandDiscardCount => TurnOwnerDiscardPhaseHandDiscardCount,
            _ => throw new InvalidOperationException(
                $"Unsupported draw number expression '{numberExpression}'.")
        };
        var fixedRecipientSequenceBefore = frame.FixedRecipient is null ? 0 : PairBenefitSequence;
        var drawn = DrawCards(target, drawCount, log: true, reason);
        if (frame.FixedRecipient is not null) CaptureFixedRecipientDraw(frameId, targetSeat, reason, fixedRecipientSequenceBefore, drawn.Count);
        if (frame.WindowContext?.JudgmentReplacement is { } replacement)
        {
            var active = GetActiveProgramFrame(frameId);
            ReplaceRuntimeTop(active with
            {
                WindowContext = active.WindowContext! with
                {
                    JudgmentReplacement = replacement with { DrawnCards = replacement.DrawnCards + drawn.Count }
                }
            });
        }
        if (resultBind is not null)
        {
            SetProgramCardSet(
                frameId,
                resultBind,
                drawn,
                visibility,
                drawn.Select(_ => CardLocation.Hand(targetSeat)).ToArray());
        }
    }

    private void DrawProgramSelectedTargets(long frameId, int amount, CardMoveReason reason)
    {
        var frame = GetActiveProgramFrame(frameId);
        if (amount < 1 || frame.SelectedTargetSeats.Count == 0 ||
            frame.SelectedTargetSeats.Distinct().Count() != frame.SelectedTargetSeats.Count)
            throw new InvalidOperationException("The selected-target draw has invalid participants.");
        foreach (var seat in frame.SelectedTargetSeats)
        {
            if (_players[seat].IsAlive)
                DrawProgramCards(frameId, seat, amount, null, null,
                    SkillProgramCardSetVisibility.Private, reason);
        }
    }

    private IReadOnlyList<int> GetProgramTargetSeats(
        int ownerSeat,
        SkillProgramTargetKind targetKind,
        ProgramSkillWindowContext? windowContext = null,
        PlayerMarkerKind? marker = null,
        ProgramParticipantReference? actorReference = null)
    {
        if (targetKind == SkillProgramTargetKind.LivingWhoseAttackRangeIncludesLord)
        {
            var lord = _players.SingleOrDefault(p => p.IsAlive && p.Role == Role.Lord);
            return lord is null ? [] : _players.Where(p => p.IsAlive && p.Seat != lord.Seat && IsWithinAttackRange(p.Seat, lord.Seat)).Select(p => p.Seat).ToArray();
        }
        if (targetKind == SkillProgramTargetKind.OtherLivingNonLord)
            return _players.Where(p => p.IsAlive && p.Seat != ownerSeat && p.Role != Role.Lord).Select(p => p.Seat).ToArray();
        if (targetKind == SkillProgramTargetKind.OtherLivingNotLastRoundFocus)
            return _players.Where(p => p.IsAlive && p.Seat != ownerSeat && !CompleteProgramEventHistory().OfType<DemonRoundFocusEvent>().Any(e => e.Source.OwnerSeat == ownerSeat && e.TargetSeat == p.Seat && e.RoundNumber == _roundNumber - 1)).Select(p => p.Seat).ToArray();
        if (targetKind is SkillProgramTargetKind.ExclusiveRendeBeneficiary or SkillProgramTargetKind.ExclusiveQingnangBeneficiary)
            return ExclusiveSupportTargets(ownerSeat, targetKind == SkillProgramTargetKind.ExclusiveRendeBeneficiary ? "magic:rende" : "magic:qingnang")
                .Where(seat => targetKind != SkillProgramTargetKind.ExclusiveQingnangBeneficiary || _players[seat].Hp < _players[seat].MaxHp).ToArray();
        if (targetKind == SkillProgramTargetKind.OtherLivingWithoutEndingSupport)
        {
            var frame = _resolutionStack.LastOrDefault() as ProgramSkillFrame;
            return _players.Where(p => p.IsAlive && p.Seat != ownerSeat && !CompleteProgramEventHistory().OfType<DemonSupportGrantedEvent>().Any(e => e.FrameId == frame?.Id && e.RecipientSeat == p.Seat)).Select(p => p.Seat).ToArray();
        }
        if (targetKind == SkillProgramTargetKind.CurrentTurnPlayer)
            return _players[_currentSeat].IsAlive ? [_currentSeat] : [];
        windowContext ??= _resolutionStack.LastOrDefault() switch
        {
            ProgramSkillFrame program => program.WindowContext,
            ProgramCardTriggerWindowFrame cardWindow when cardWindow.CandidateIndex < cardWindow.Candidates.Count =>
                CreateCardActionProgramContext(cardWindow, cardWindow.Candidates[cardWindow.CandidateIndex]),
            TurnEndingBoundaryFrame ending when ending.ItemIndex < ending.Items.Count &&
                ending.Items[ending.ItemIndex].Candidate is { } candidate =>
                CreateTurnEndingProgramContext(ending, candidate, ending.Items[ending.ItemIndex].Facts),
            _ => null
        };
        if (targetKind == SkillProgramTargetKind.EventTargetWithHand)
            return windowContext?.TargetSeat is { } eventSeat && _players[eventSeat].IsAlive &&
                GetHand(_players[eventSeat]).Count > 0 ? [eventSeat] : [];
        if (targetKind == SkillProgramTargetKind.EventTarget)
        {
            if (windowContext is { Window: SkillProgramTriggerWindow.CharacterTurnedOver or SkillProgramTriggerWindow.CharacterTurnedFaceUp or
                SkillProgramTriggerWindow.CharacterEnteredChain or SkillProgramTriggerWindow.DyingEntering or
                SkillProgramTriggerWindow.CardsMoved or SkillProgramTriggerWindow.CardsGained or
                SkillProgramTriggerWindow.DiscardPileReceived, TargetSeat: { } changedSeat })
                return _players[changedSeat].IsAlive ? [changedSeat] : [];
            if (windowContext is { Window: SkillProgramTriggerWindow.TurnEnding, TargetSeat: { } endingSeat } &&
                _resolutionStack.OfType<TurnEndingBoundaryFrame>().SingleOrDefault(item =>
                    item.Id == windowContext.ParentFrameId && item.OwnerSeat == endingSeat) is not null)
                return _players[endingSeat].IsAlive ? [endingSeat] : [];
            if (windowContext is
                {
                    Window: SkillProgramTriggerWindow.AfterDamageApplied or
                        SkillProgramTriggerWindow.DamageAppliedBeforeDying,
                    TargetSeat: { } damageSeat
                })
                return _players[damageSeat].IsAlive ? [damageSeat] : [];
            var actionId = windowContext?.CardUse?.CardActionId ??
                throw new InvalidOperationException("Event-target selection requires card-action context.");
            var parent = _resolutionStack.OfType<ProgramCardTriggerWindowFrame>()
                .SingleOrDefault(item => item.Id == windowContext.ParentFrameId && item.Action.ActionId == actionId) ??
                throw new InvalidOperationException("Event-target selection lost its parent card action.");
            var frozenTargets = parent.Action.TargetSeats.Count > 0
                ? parent.Action.TargetSeats
                : parent.Candidates.Select(candidate => candidate.OpponentSeat)
                    .Where(seat => seat >= 0).Distinct().ToArray();
            return frozenTargets.Distinct().Where(seat => _players[seat].IsAlive).Order().ToArray();
        }
        if (targetKind == SkillProgramTargetKind.OtherLegalCurrentCardTarget)
            return GetProgramCardUseRoleTargets(ownerSeat, windowContext);
        if (targetKind == SkillProgramTargetKind.CurrentArrowBarrageTargets)
            return GetCurrentArrowBarrageTargets(ownerSeat, windowContext);
        if (targetKind == SkillProgramTargetKind.CurrentCardUseTargets)
        {
            if (windowContext is not
                {
                    Window: SkillProgramTriggerWindow.CardUseBeforeTargetEffects or SkillProgramTriggerWindow.CardUseTargetsFinalized,
                    CardUse: { } cardUse
                } ||
                _resolutionStack.OfType<ProgramCardTriggerWindowFrame>().LastOrDefault() is not { } window ||
                window.Id != windowContext.ParentFrameId ||
                window.Action.ActionId != cardUse.CardActionId ||
                window.ParentFrameId != cardUse.ParentCardUseFrameId ||
                window.Action.Type != CardActionType.Use ||
                _resolutionStack.OfType<CardUseFrame>().SingleOrDefault(item => item.Id == window.ParentFrameId) is not { } parent ||
                parent.Action?.ActionId != cardUse.CardActionId)
                throw new InvalidOperationException("Current card-use targets require their frozen active card action.");
            return (cardUse.DesignatedTargetSeats ?? window.Action.EffectiveDesignatedTargetSeats)
                .Distinct().Where(seat => _players[seat].IsAlive &&
                    parent.IneffectiveTargetSeats?.Contains(seat) != true).ToArray();
        }
        if (targetKind == SkillProgramTargetKind.OtherLivingInBoundParticipantAttackRange)
        {
            if (actorReference is not { } reference ||
                _resolutionStack.LastOrDefault() is not ProgramSkillFrame frame)
                throw new InvalidOperationException("Attack-range target selection lost its bound participant.");
            var actorSeat = ResolveProgramParticipant(frame, reference);
            if (!_players[actorSeat].IsAlive) return [];
            return _players.Where(target => target.IsAlive && target.Seat != actorSeat &&
                    IsWithinAttackRange(actorSeat, target.Seat))
                .Select(target => target.Seat).Order().ToArray();
        }
        if (targetKind == SkillProgramTargetKind.MaximumAttributedMarker)
        {
            if (marker is not { } markerKind)
                throw new InvalidOperationException("Maximum attributed-marker selection requires a marker kind.");
            return GameRules.GetMaximumMarkerCandidates(_players.Select(player =>
                new PlayerMarkerCandidateState(
                    player.Seat,
                    player.IsAlive,
                    GetMarkerSourceCount(player, markerKind, ownerSeat))));
        }
        return _players
            .Where(target => target.IsAlive && targetKind switch
            {
                SkillProgramTargetKind.OtherLiving => target.Seat != ownerSeat,
                SkillProgramTargetKind.OtherLivingMale =>
                    target.Seat != ownerSeat && target.Gender == GeneralGender.Male,
                SkillProgramTargetKind.AnyLivingMale => target.Gender == GeneralGender.Male,
                SkillProgramTargetKind.OtherWoundedMale =>
                    target.Seat != ownerSeat && target.Gender == GeneralGender.Male &&
                    target.Hp < target.MaxHp,
                SkillProgramTargetKind.OtherLivingInAttackRange =>
                    target.Seat != ownerSeat &&
                    IsWithinAttackRange(ownerSeat, target.Seat),
                SkillProgramTargetKind.OtherLivingWhoseAttackRangeIncludesOwner =>
                    target.Seat != ownerSeat &&
                    IsWithinAttackRange(target.Seat, ownerSeat),
                SkillProgramTargetKind.OtherLivingWithQinggangSword =>
                    target.Seat != ownerSeat &&
                    HasWeaponAbility(target, CardKind.QinggangSword),
                SkillProgramTargetKind.OtherLivingSlashable =>
                    CanUseProvidedSlashTarget(_players[ownerSeat], target),
                SkillProgramTargetKind.SlashRedirectable =>
                    ActiveCardAttack is { } pendingSlash &&
                    pendingSlash.TargetSeat == ownerSeat &&
                    IsProgramSlashRedirectTarget(pendingSlash, ownerSeat, target.Seat),
                SkillProgramTargetKind.OtherLivingVirtualSlashTarget =>
                    target.Seat != ownerSeat &&
                    (windowContext?.Window != SkillProgramTriggerWindow.RoundStarting ||
                     _players[ownerSeat].IsAlive &&
                     !IsCardUseForbidden(ownerSeat, CardKind.Slash, CardActionType.Use) &&
                     !HasTurnCardTargetRestriction(ownerSeat, SkillProgramCardTargetRestriction.SelfOnly)) &&
                    !IsDirectedCardTargetProhibited(ownerSeat, target.Seat, CardKind.Slash) &&
                    !IsSlashProhibited(target),
                SkillProgramTargetKind.OtherLivingDelayedTrickTarget =>
                    IsProgramDiscardedDelayedTrickTarget(ownerSeat, target, windowContext),
                SkillProgramTargetKind.AnyLivingWithHand => GetHand(target).Count > 0,
                SkillProgramTargetKind.OtherLivingWithHand =>
                    target.Seat != ownerSeat && GetHand(target).Count > 0,
                SkillProgramTargetKind.OtherLivingWithFewerHandCards =>
                    target.Seat != ownerSeat && GetHand(target).Count > 0 &&
                    GetHand(target).Count < GetHand(_players[ownerSeat]).Count,
                SkillProgramTargetKind.OtherLivingWuFactionWithHand =>
                    target.Seat != ownerSeat && GetHand(target).Count > 0 &&
                    GetEffectiveFactionId(target) == "wu",
                SkillProgramTargetKind.OtherLivingWithHandOrEquipment =>
                    target.Seat != ownerSeat && GetHand(target).Count + GetEquipment(target).Count > 0,
                SkillProgramTargetKind.OtherLivingWithDiscardableHandOrEquipment =>
                    target.Seat != ownerSeat && HasDiscardableHeBy(ownerSeat, target.Seat),
                SkillProgramTargetKind.OtherLivingEmptyHand =>
                    target.Seat != ownerSeat && GetHand(target).Count == 0,
                SkillProgramTargetKind.OtherLivingHandAtMostOwner =>
                    target.Seat != ownerSeat && GetHand(target).Count <= GetHand(_players[ownerSeat]).Count,
                SkillProgramTargetKind.OtherLivingWithHandHpGreaterThanOwner =>
                                    target.Seat != ownerSeat && GetHand(target).Count > 0 &&
                                    target.Hp > _players[ownerSeat].Hp,
                SkillProgramTargetKind.OtherLivingHandAtLeastOwner =>
                                    target.Seat != ownerSeat && GetHand(target).Count > 0 &&
                                    GetHand(target).Count >= GetHand(_players[ownerSeat]).Count,
                SkillProgramTargetKind.OtherLivingUnequalHandPair => target.Seat != ownerSeat &&
                    _players.Any(peer => peer.IsAlive && peer.Seat != ownerSeat && peer.Seat != target.Seat &&
                        GetHand(peer).Count != GetHand(target).Count),
                SkillProgramTargetKind.OtherLivingPair => target.Seat != ownerSeat &&
                    _players.Count(peer => peer.IsAlive && peer.Seat != ownerSeat) >= 2,
                SkillProgramTargetKind.LivingPairDistinct =>
                    _players.Count(peer => peer.IsAlive) >= 2,
                SkillProgramTargetKind.EquipmentExchangePair =>
                    _players.Any(peer => IsProgramEquipmentExchangePair(ownerSeat, target.Seat, peer.Seat)),
                SkillProgramTargetKind.OtherLivingLeastHandCount => target.Seat != ownerSeat &&
                    GetHand(target).Count ==
                    _players.Where(peer => peer.IsAlive && peer.Seat != ownerSeat)
                        .Select(peer => GetHand(peer).Count).Min(),
                SkillProgramTargetKind.OtherLivingAtDistanceOne =>
                    target.Seat != ownerSeat && GetCombatDistance(ownerSeat, target.Seat) == 1,
                SkillProgramTargetKind.AnyLivingHighestHp => target.Hp == _players.Where(player => player.IsAlive).Max(player => player.Hp),
                SkillProgramTargetKind.AnyLivingLeastHandCount => GetHand(target).Count == _players.Where(player => player.IsAlive).Min(player => GetHand(player).Count),
                SkillProgramTargetKind.OtherLivingHighestHand => target.Seat != ownerSeat && GetHand(target).Count == _players.Where(player => player.IsAlive && player.Seat != ownerSeat).Max(player => GetHand(player).Count),
                SkillProgramTargetKind.AnyLivingHighestHand => GetHand(target).Count == _players.Where(player => player.IsAlive).Max(player => GetHand(player).Count),
                SkillProgramTargetKind.AnyLiving => true,
                SkillProgramTargetKind.OtherWounded =>
                    target.Seat != ownerSeat && target.Hp < target.MaxHp,
                SkillProgramTargetKind.AnyWounded => target.Hp < target.MaxHp,
                SkillProgramTargetKind.AnyLivingHandBelowMaxHp =>
                    GetHand(target).Count < target.MaxHp,
                SkillProgramTargetKind.OtherLivingExceptSource =>
                    target.Seat != ownerSeat && target.Seat != windowContext?.SourceSeat,
                SkillProgramTargetKind.EventSource =>
                    target.Seat == windowContext?.SourceSeat,
                _ => false
            })
            .Select(target => target.Seat)
            .Order()
            .ToArray();
    }

    private bool IsProgramTargetEligible(int ownerSeat, SkillProgramTargetKind targetKind,
        IReadOnlyList<CardZoneKind> zones, int targetSeat, PlayerMarkerKind? marker = null,
        ProgramSkillWindowContext? windowContext = null,
        ProgramParticipantReference? actorReference = null)
    {
        if (!GetProgramTargetSeats(ownerSeat, targetKind, windowContext, marker, actorReference).Contains(targetSeat)) return false;
        if (zones.Count == 0) return true;
        var target = _players[targetSeat];
        return zones.Any(zone => zone switch
        {
            CardZoneKind.Hand => GetHand(target).Count > 0,
            CardZoneKind.Equipment => GetEquipment(target).Count > 0,
            CardZoneKind.Judgment => GetJudgment(target).Count > 0,
            _ => false
        });
    }

    private SkillProgramStepOutcome SelectProgramTargets(
        long frameId,
        int ownerSeat,
        SkillProgramTargetKind targetKind,
        int minimumTargets,
        int maximumTargets,
        SkillProgramNumberExpression? numberExpression,
        SkillProgramTargetAiOrder aiOrder)
    {
        var frame = GetActiveProgramFrame(frameId);
        var paused = ProgramInstructionResolver.Default.Resolve(frame, _contentRegistry.GetSkill(frame.SkillId).Program!)
            .GetPausedInstruction(frame.InstructionIndex).Effect;
        if (paused is { Op: SkillProgramEffectOp.SelectTargets,
                NumberExpression: SkillProgramNumberExpression.BoundCardCount, SourceBind: not null })
            return SelectProgramNamedBoundTargets(frame, paused);
        var targetSeats = GetProgramTargetSeats(ownerSeat, targetKind, frame.WindowContext);
        var expressionMaximum = numberExpression switch
        {
            SkillProgramNumberExpression.EventMovedCardCount => frame.WindowContext?.Window == SkillProgramTriggerWindow.CardsMoved ? frame.WindowContext.Facts?.MovedCardCount ?? 0 : throw new InvalidOperationException("Moved-card target count requires its owning movement window."),
            SkillProgramNumberExpression.BoundCardCount => frame.CardSetBindings.Last().CardIds.Count,
            SkillProgramNumberExpression.CurrentHandCount => GetHand(_players[ownerSeat]).Count,
            SkillProgramNumberExpression.CurrentHp => Math.Max(0, _players[ownerSeat].Hp),
            SkillProgramNumberExpression.OwnerLostHpAtLeastOne => Math.Max(1, _players[ownerSeat].MaxHp - _players[ownerSeat].Hp),
            SkillProgramNumberExpression.PlannedNormalDrawCount =>
                GetProgramPlannedNormalDrawCount(frame),
            _ => maximumTargets
        };
        var cappedMaximum = Math.Min(Math.Min(maximumTargets, expressionMaximum), targetSeats.Count);
        if (numberExpression == SkillProgramNumberExpression.BoundCardCount)
            minimumTargets = expressionMaximum;
        if ((minimumTargets < 1 && !(minimumTargets == 0 && targetKind is SkillProgramTargetKind.OtherLivingWithHand or SkillProgramTargetKind.OtherLivingWithoutEndingSupport)) || cappedMaximum < minimumTargets)
        {
            CancelProgramBindingAndCleanup(frame, "没有足够的合法技能目标，技能结算已取消。");
            return SkillProgramStepOutcome.AwaitChild;
        }

        var selections = new List<IReadOnlyList<int>>();
        var current = new List<int>();
        AddSelections(0);

        void AddSelections(int next)
        {
            if (current.Count >= minimumTargets)
            {
                var seats = current.ToArray();
                if (targetKind == SkillProgramTargetKind.EquipmentExchangePair &&
                    !IsProgramEquipmentExchangePair(ownerSeat, seats[0], seats[1])) return;
                if (targetKind is SkillProgramTargetKind.OtherLivingUnequalHandPair or
                    SkillProgramTargetKind.OtherLivingPair)
                {
                    if (targetKind == SkillProgramTargetKind.OtherLivingUnequalHandPair &&
                        GetHand(_players[seats[0]]).Count == GetHand(_players[seats[1]]).Count)
                        return;
                    Array.Sort(seats, (left, right) =>
                        GetHand(_players[left]).Count.CompareTo(GetHand(_players[right]).Count));
                }
                if (targetKind == SkillProgramTargetKind.LivingPairDistinct)
                {
                    // Ordered pair: the first pick is the card source, the second the
                    // destination, so both permutations are exposed as distinct options.
                    selections.Add(Array.AsReadOnly(seats));
                    selections.Add(Array.AsReadOnly(new[] { seats[1], seats[0] }));
                }
                else
                {
                    selections.Add(Array.AsReadOnly(seats));
                    if (targetKind == SkillProgramTargetKind.OtherLivingMale)
                        selections.Add(Array.AsReadOnly(new[] { seats[1], seats[0] }));
                }
            }
            if (current.Count == cappedMaximum) return;
            for (var index = next; index < targetSeats.Count; index++)
            {
                current.Add(targetSeats[index]);
                AddSelections(index + 1);
                current.RemoveAt(current.Count - 1);
            }
        }

        if (selections.Count == 0)
        {
            CancelProgramBindingAndCleanup(frame, "没有符合目标关系的角色组合，技能结算已取消。");
            return SkillProgramStepOutcome.AwaitChild;
        }

        var choices = selections.Select(selection =>
        {
            var seats = selection.ToArray();
            var names = string.Join("、", seats.Select(seat => _players[seat].Name));
            var id = string.Join("-", seats.Select(seat =>
                seat.ToString(System.Globalization.CultureInfo.InvariantCulture)));
            return new PromptChoice(
                new ChoiceId($"program-targets.frame-{frameId}.seats-{id}"),
                seats.Length == 0 ? (targetKind == SkillProgramTargetKind.OtherLivingWithoutEndingSupport ? "不授予此技能。" : "不获得手牌。") : $"选择 {names}。",
                [],
                seats,
                new Dictionary<string, string>
                {
                    ["program-action"] = "select-targets",
                    ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["target-kind"] = targetKind.ToString(),
                    ["minimum-targets"] = minimumTargets.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["maximum-targets"] = (numberExpression is SkillProgramNumberExpression.PlannedNormalDrawCount or SkillProgramNumberExpression.OwnerLostHpAtLeastOne ||
                        targetKind == SkillProgramTargetKind.CurrentCardUseTargets
                        ? cappedMaximum : maximumTargets).ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["target-ai-order"] = aiOrder.ToString()
                });
        }).ToArray();
        var presentation = _contentRegistry!.GetSkill(frame.SkillId);
        var displayedMaximum = numberExpression is SkillProgramNumberExpression.PlannedNormalDrawCount or SkillProgramNumberExpression.OwnerLostHpAtLeastOne ||
            targetKind == SkillProgramTargetKind.CurrentCardUseTargets
            ? cappedMaximum : maximumTargets;
        var targetCountText = minimumTargets == displayedMaximum
            ? minimumTargets.ToString(System.Globalization.CultureInfo.InvariantCulture)
            : $"{minimumTargets} 至 {displayedMaximum}";
        _pendingDecision = new PendingDecision(
            DecisionKind.ProgramTrigger,
            ownerSeat,
            $"【{presentation.Name}】请选择 {targetCountText} 名目标角色。",
            [],
            targetSeats,
            frame.WindowContext?.SourceSeat)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            TargetSeat = ownerSeat,
            SkillPrompt = new SkillPromptPresentation(
                frame.SkillId,
                presentation.Name,
                $"{presentation.Name} · 选择目标",
                presentation.Description),
            Choices = Array.AsReadOnly(choices)
        };
        _status = _players[ownerSeat].IsHuman
            ? EngineStatus.AwaitingHumanResponse
            : EngineStatus.Running;
        return SkillProgramStepOutcome.AwaitChoice;
    }

    private int GetProgramPlannedNormalDrawCount(ProgramSkillFrame frame)
    {
        if (frame.WindowContext is not
            { Window: SkillProgramTriggerWindow.DrawPhaseStarting, ParentFrameId: var parentId } ||
            _resolutionStack.Count < 2 ||
            _resolutionStack[^2] is not ProgramLifecycleTriggerWindowFrame parent ||
            parent.Id != parentId || parent.NormalDrawReplaced)
            throw new InvalidOperationException(
                "A planned normal-draw target limit requires its active draw-phase parent.");
        var baseDrawCount = parent.FrozenBaseDrawCount ?? GetTurnDrawCount(_players[frame.OwnerSeat]);
        if (parent.FrozenBaseDrawCount is null)
            ReplaceRuntimeFrame(_resolutionStack[^2].Id, parent with { FrozenBaseDrawCount = baseDrawCount });
        return Math.Max(0, checked(baseDrawCount + parent.NormalDrawAdjustment));
    }

    private void TakeProgramRandomHandCards(
        long frameId,
        int ownerSeat,
        int amountPerTarget,
        CardMoveReason reason)
    {
        var frame = GetActiveProgramFrame(frameId);
        if (amountPerTarget != 1 || frame.SelectedTargetSeats.Count == 0 ||
            frame.SelectedTargetSeats.Distinct().Count() != frame.SelectedTargetSeats.Count)
            throw new InvalidOperationException("The configured random hand-card transfer has invalid targets or amount.");

        var selection = _contentRegistry!.GetSkill(frame.SkillId).Program!.Triggers
            .Single(trigger => trigger.Id == frame.TriggerId).Effects
            .Single(effect => effect.Op == SkillProgramEffectOp.SelectTargets);
        var usesFrozenEligibility = selection.TargetKind == SkillProgramTargetKind.OtherLivingHandAtLeastOwner;
        var validTargets = usesFrozenEligibility ? [] :
            GetProgramTargetSeats(ownerSeat, SkillProgramTargetKind.OtherLivingWithHand);
        var takenSeats = new List<int>();
        foreach (var targetSeat in frame.SelectedTargetSeats)
        {
            if (!usesFrozenEligibility && !validTargets.Contains(targetSeat))
                throw new InvalidOperationException("A selected random hand-card target is no longer legal.");
            var target = _players[targetSeat];
            if (usesFrozenEligibility && (!target.IsAlive || GetHand(target).Count == 0))
                continue;
            var hand = GetHand(target);
            var card = hand[_random.Next(hand.Count)];
            MoveCard(card, CardLocation.Hand(targetSeat), CardLocation.Processing, reason);
            MoveCard(card, CardLocation.Processing, CardLocation.Hand(ownerSeat), reason);
            takenSeats.Add(targetSeat);
        }
        AdvanceEventRulesAndQueueFact(new ProgramRandomHandCardsTakenEvent(
            frame.Id,
            frame.SkillId,
            frame.TriggerId!,
            ownerSeat,
            Array.AsReadOnly(takenSeats.ToArray()),
            takenSeats.Count));
        AddLog("SkillEffect", takenSeats.Count == 0
            ? $"{_players[ownerSeat].Name} 未从所选目标获得手牌。"
            : $"{_players[ownerSeat].Name} 从 {string.Join("、", takenSeats.Select(seat => _players[seat].Name))} 各获得一张手牌。",
            ownerSeat);
    }

    /// <summary>
    /// Takes one random card from every other living character in turn order, drawing the
    /// candidate pool from the declared areas. Hand cards stay opaque: only the participating
    /// seats and the total count reach the public event stream.
    /// </summary>
    private void TakeProgramRandomCardFromEveryOtherCharacter(
        long frameId,
        int ownerSeat,
        IReadOnlyList<CardZoneKind> zones,
        CardMoveReason reason)
    {
        var frame = GetActiveProgramFrame(frameId);
        if (frame.OwnerSeat != ownerSeat || zones.Count == 0 ||
            zones.Any(zone => zone is not (CardZoneKind.Hand or CardZoneKind.Equipment or CardZoneKind.Judgment)) ||
            !_players[ownerSeat].IsAlive)
            throw new InvalidOperationException(
                "A multi-character random transfer requires the active living owner and declared areas.");

        var takenSeats = new List<int>();
        foreach (var target in _players
                     .Where(player => player.IsAlive && player.Seat != ownerSeat)
                     .OrderBy(player => (player.Seat - ownerSeat + _playerCount) % _playerCount))
        {
            var candidates = zones
                .SelectMany(zone => zone switch
                {
                    CardZoneKind.Hand => GetHand(target).Select(card =>
                        (Card: card, Location: CardLocation.Hand(target.Seat))),
                    CardZoneKind.Equipment => GetEquipment(target).Select(card =>
                        (Card: card, Location: CardLocation.Equipment(target.Seat))),
                    CardZoneKind.Judgment => GetJudgment(target).Select(card =>
                        (Card: card, Location: CardLocation.Judgment(target.Seat))),
                    _ => throw new InvalidOperationException($"Unsupported random-transfer area '{zone}'.")
                })
                .OrderBy(entry => entry.Card.Id)
                .ToArray();
            if (candidates.Length == 0) continue;
            var pick = candidates[_random.Next(candidates.Length)];
            MoveCard(pick.Card, pick.Location, CardLocation.Processing, reason);
            if (MoveProcessingCardUnlessDestroyed(pick.Card, CardLocation.Hand(ownerSeat), reason))
                takenSeats.Add(target.Seat);
        }

        AdvanceEventRulesAndQueueFact(new ProgramRandomCardsTakenFromCharactersEvent(
            frame.Id,
            frame.SkillId,
            GetProgramBindingId(frame),
            ownerSeat,
            Array.AsReadOnly(takenSeats.ToArray()),
            Array.AsReadOnly(zones.ToArray()),
            takenSeats.Count));
        AddLog("SkillEffect", takenSeats.Count == 0
            ? $"{_players[ownerSeat].Name} 未从其他角色处获得牌。"
            : $"{_players[ownerSeat].Name} 从 {string.Join("、", takenSeats.Select(seat => _players[seat].Name))} 各随机获得一张牌。",
            ownerSeat);
    }

    private SkillProgramStepOutcome SelectProgramTarget(
        long frameId,
        int ownerSeat,
        SkillProgramTargetKind targetKind,
        IReadOnlyList<CardZoneKind> zones,
        PlayerMarkerKind? marker,
        ProgramParticipantReference? actorReference = null,
        bool skipIfNoTarget = false)
    {
        var frame = GetActiveProgramFrame(frameId);
        var targetSeats = GetProgramTargetSeats(ownerSeat, targetKind, frame.WindowContext, marker, actorReference)
            .Where(seat => IsProgramTargetEligible(ownerSeat, targetKind, zones, seat, marker,
                frame.WindowContext, actorReference) && CanSelectProgramPindianOpponent(frame, seat)).ToArray();
        if (targetSeats.Length == 0)
        {
            if (skipIfNoTarget)
            {
                ReplaceRuntimeTop(frame with { SelectedTargetSeats = [] });
                return SkillProgramStepOutcome.Continue;
            }
            CancelProgramBindingAndCleanup(frame, "没有仍然合法的技能目标，技能结算已取消。");
            return SkillProgramStepOutcome.AwaitChild;
        }

        var choices = targetSeats.Select(targetSeat =>
            new PromptChoice(
                new ChoiceId($"program-target.frame-{frameId}.seat-{targetSeat}"),
                $"选择 {_players[targetSeat].Name}（座位 {targetSeat + 1}）。",
                [],
                [targetSeat],
                new Dictionary<string, string>
                {
                    ["program-action"] = "select-target",
                    ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["target-kind"] = targetKind.ToString(),
                    ["marker"] = marker?.ToString() ?? ""
                })).ToArray();
        var presentation = _contentRegistry!.GetSkill(frame.SkillId);
        _pendingDecision = new PendingDecision(
            DecisionKind.ProgramTrigger,
            ownerSeat,
            $"【{presentation.Name}】请选择一名目标角色。",
            [],
            targetSeats,
            frame.WindowContext?.SourceSeat)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            TargetSeat = ownerSeat,
            SkillPrompt = new SkillPromptPresentation(
                frame.SkillId,
                presentation.Name,
                $"{presentation.Name} · 选择目标",
                presentation.Description),
            Choices = Array.AsReadOnly(choices)
        };
        _status = _players[ownerSeat].IsHuman
            ? EngineStatus.AwaitingHumanResponse
            : EngineStatus.Running;
        return SkillProgramStepOutcome.AwaitChoice;
    }

    private SkillProgramStepOutcome SelectProgramSourceCard(
        long frameId,
        int ownerSeat,
        SkillProgramCardSource cardSource,
        IReadOnlyList<CardZoneKind> zones,
        string resultBind,
        IReadOnlyList<EquipmentSlot> equipmentSlots,
        bool skipIfNoCards,
        bool allowSameSource)
    {
        var frame = GetActiveProgramFrame(frameId);
        var sourceSeat = cardSource switch
        {
            SkillProgramCardSource.Owner => ownerSeat,
            SkillProgramCardSource.DamageSource => frame.WindowContext?.SourceSeat,
            SkillProgramCardSource.EventTarget => frame.WindowContext?.TargetSeat,
            _ => null
        };
        if (sourceSeat is null || !IsValidPlayerSeat(sourceSeat.Value) ||
            (cardSource == SkillProgramCardSource.DamageSource && sourceSeat == ownerSeat && !allowSameSource))
        {
            if (skipIfNoCards)
            {
                SetProgramCardSet(frameId, resultBind, [], SkillProgramCardSetVisibility.Private, []);
                return SkillProgramStepOutcome.Continue;
            }
            CancelProgramBindingAndCleanup(frame, "伤害来源不再可供选择牌，技能结算已取消。");
            return SkillProgramStepOutcome.AwaitChild;
        }

        var choices = new List<PromptChoice>();
        if (zones.Contains(CardZoneKind.Hand))
        {
            var hand = GetHand(_players[sourceSeat.Value]);
            for (var slot = 0; slot < hand.Count; slot++)
            {
                choices.Add(new PromptChoice(
                    new ChoiceId($"program-source-card.frame-{frameId}.hand-slot-{slot}"),
                    $"选择 {_players[sourceSeat.Value].Name} 的第 {slot + 1} 张暗置手牌。",
                    [],
                    [sourceSeat.Value],
                    new Dictionary<string, string>
                    {
                        ["program-action"] = "select-source-card",
                        ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        ["result-bind"] = resultBind,
                        ["source-zone"] = CardZoneKind.Hand.ToString(),
                        ["slot-index"] = slot.ToString(System.Globalization.CultureInfo.InvariantCulture)
                    }));
            }
        }
        if (zones.Contains(CardZoneKind.Equipment))
        {
            foreach (var card in GetEquipment(_players[sourceSeat.Value]).Where(card =>
                         equipmentSlots.Count == 0 || equipmentSlots.Contains(EquipmentCatalog.Get(card.Kind).Slot)))
            {
                choices.Add(new PromptChoice(
                    new ChoiceId($"program-source-card.frame-{frameId}.equipment-{card.Id}"),
                    $"选择 {_players[sourceSeat.Value].Name} 的装备【{card.DisplayName}】。",
                    [card.Id],
                    [sourceSeat.Value],
                    new Dictionary<string, string>
                    {
                        ["program-action"] = "select-source-card",
                        ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        ["result-bind"] = resultBind,
                        ["source-zone"] = CardZoneKind.Equipment.ToString()
                    }));
            }
        }
        foreach (var zone in zones.Where(zone => zone is
            CardZoneKind.WoodenOxGrain or CardZoneKind.BuquWound or
            CardZoneKind.Authority or CardZoneKind.Chunlao))
        {
            if (cardSource != SkillProgramCardSource.Owner)
                throw new InvalidOperationException("A persistent source pile must belong to the program owner.");
            foreach (var card in _cardZones.CardsAt(new CardLocation(zone, ownerSeat)))
            {
                choices.Add(new PromptChoice(
                    new ChoiceId($"program-source-card.frame-{frameId}.{zone}-{card.Id}"),
                    $"选择 {_players[ownerSeat].Name} 的【{card.DisplayName}】。",
                    [card.Id],
                    [ownerSeat],
                    new Dictionary<string, string>
                    {
                        ["program-action"] = "select-source-card",
                        ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        ["result-bind"] = resultBind,
                        ["source-zone"] = zone.ToString()
                    }));
            }
        }
        if (choices.Count == 0)
        {
            if (skipIfNoCards)
            {
                SetProgramCardSet(frameId, resultBind, [], SkillProgramCardSetVisibility.Private, []);
                return SkillProgramStepOutcome.Continue;
            }
            CancelProgramBindingAndCleanup(frame, "伤害来源已没有可选择的牌，技能结算已取消。");
            return SkillProgramStepOutcome.AwaitChild;
        }

        var presentation = _contentRegistry!.GetSkill(frame.SkillId);
        _pendingDecision = new PendingDecision(
            DecisionKind.ProgramTrigger,
            ownerSeat,
            cardSource == SkillProgramCardSource.Owner
                ? $"【{presentation.Name}】请选择自己的一张牌。"
                : $"【{presentation.Name}】请选择伤害来源的一张牌。",
            choices.SelectMany(choice => choice.Cards).Distinct().ToArray(),
            [sourceSeat.Value],
            sourceSeat)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            TargetSeat = sourceSeat,
            SkillPrompt = new SkillPromptPresentation(
                frame.SkillId,
                presentation.Name,
                $"{presentation.Name} · 选择来源牌",
                presentation.Description),
            Choices = Array.AsReadOnly(choices.ToArray())
        };
        _status = _players[ownerSeat].IsHuman
            ? EngineStatus.AwaitingHumanResponse
            : EngineStatus.Running;
        return SkillProgramStepOutcome.AwaitChoice;
    }

    private SkillProgramStepOutcome GiveProgramBoundCard(
        long frameId,
        int ownerSeat,
        string sourceBind,
        SkillProgramTargetKind targetKind,
        CardMoveReason reason)
    {
        var frame = GetActiveProgramFrame(frameId);
        var source = GetProgramCardSet(frame, sourceBind);
        if (source.CardIds.Count != source.SourceLocations.Count)
            throw new InvalidOperationException("A program card-set binding lost its source locations.");
        var available = source.CardIds.Select((cardId, index) =>
                (CardId: cardId, Location: source.SourceLocations[index]))
            .Where(item => _cardZones.GetLocation(item.CardId) == item.Location)
            .ToArray();
        var targetSeats = GetProgramTargetSeats(ownerSeat, targetKind);
        if (available.Length == 0 || targetSeats.Count == 0)
            return SkillProgramStepOutcome.Continue;

        var choices =
            (from item in available
             let card = _cardZones.CardsAt(item.Location).Single(card => card.Id == item.CardId)
             from targetSeat in targetSeats
             select new PromptChoice(
                 new ChoiceId($"program-give.frame-{frameId}.card-{card.Id}.target-{targetSeat}"),
                 $"将【{card.DisplayName}】交给 {_players[targetSeat].Name}（座位 {targetSeat + 1}）。",
                 [card.Id],
                 [targetSeat],
                 new Dictionary<string, string>
                 {
                     ["program-action"] = "give-bound-card",
                     ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                     ["source-bind"] = sourceBind,
                     ["target-kind"] = targetKind.ToString(),
                     ["move-reason"] = reason.Value
                 }))
            .Append(new PromptChoice(
                new ChoiceId($"program-give.frame-{frameId}.keep"),
                "不分配，保留这些牌。",
                [],
                [],
                new Dictionary<string, string>
                {
                    ["program-action"] = "keep-bound-cards",
                    ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["source-bind"] = sourceBind,
                    ["target-kind"] = targetKind.ToString(),
                    ["move-reason"] = reason.Value
                }))
            .ToArray();
        var presentation = _contentRegistry!.GetSkill(frame.SkillId);
        _pendingDecision = new PendingDecision(
            DecisionKind.ProgramTrigger,
            ownerSeat,
            $"【{presentation.Name}】可将一张本次获得的牌交给一名角色。",
            available.Select(item => item.CardId).ToArray(),
            targetSeats,
            frame.WindowContext?.SourceSeat)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            TargetSeat = ownerSeat,
            SkillPrompt = new SkillPromptPresentation(
                frame.SkillId,
                presentation.Name,
                $"{presentation.Name} · 分配牌",
                presentation.Description),
            Choices = Array.AsReadOnly(choices)
        };
        _status = _players[ownerSeat].IsHuman
            ? EngineStatus.AwaitingHumanResponse
            : EngineStatus.Running;
        return SkillProgramStepOutcome.AwaitChoice;
    }

    private void ClaimProgramDamageCards(long frameId, int ownerSeat, CardMoveReason reason)
    {
        var frame = GetActiveProgramFrame(frameId);
        var cards = GetClaimableProgramDamageCards(frame);
        if (cards.Length == 0) return;
        var damage = ActiveDamageTrigger!;
        MoveCards(cards, CardLocation.Processing, CardLocation.Hand(ownerSeat), reason);
        if (ActiveGroupCard is { } group)
        {
            var claimed = group.DamageClaimedPhysicalCardIds.ToHashSet();
            foreach (var card in cards)
                RecordClaimedGroupPhysicalCard(claimed, group.ResolutionId, group.PhysicalCards,
                    GetDamageTriggerAttack(damage).ResolutionId, card.Id);
            group.SetClaimedPhysicalCards(claimed.ToArray());
        }
        AdvanceEventRulesAndQueueFact(new ProgramDamageCardsClaimedEvent(
            frame.Id,
            frame.SkillId,
            frame.TriggerId!,
            ownerSeat,
            Array.AsReadOnly(cards.Select(card => card.Id).ToArray())));
    }

    private Card[] GetClaimableProgramDamageCards(ProgramSkillFrame frame)
    {
        if (frame.WindowContext is not
            {
                Window: SkillProgramTriggerWindow.AfterDamageApplied,
                ParentFrameId: var parentFrameId,
                DamageFrameId: var damageFrameId
            } || ActiveDamageTrigger is not { } damage ||
            damage.Id != parentFrameId || damage.ParentFrameId != damageFrameId)
            throw new InvalidOperationException("The program damage-card claim lost its damage window.");
        return GetDamageTriggerAttack(damage).PhysicalCards
            .Where(card => _cardZones.GetLocation(card.Id) == CardLocation.Processing)
            .ToArray();
    }

    private SkillProgramStepOutcome SelectProgramCardSubset(
        long frameId,
        int ownerSeat,
        string sourceBind,
        string resultBind,
        int minimumCards,
        int maximumCards,
        int maximumRankSum,
        SkillProgramSubsetAiOrder aiOrder,
        bool allowFewerWhenInsufficient,
        bool onePerSuit, bool availableAtSourceOnly = false)
    {
        var frame = GetActiveProgramFrame(frameId);
        var source = frame.CardSetBindings.SingleOrDefault(binding => binding.Name == sourceBind);
        if (source is null)
        {
            CancelProgramBindingAndCleanup(
                frame,
                $"选牌来源绑定“{sourceBind}”未生成，技能结算已取消。");
            return SkillProgramStepOutcome.AwaitChild;
        }
        if (source.CardIds.Count != source.SourceLocations.Count)
            throw new InvalidOperationException("A program card-set binding lost its source locations.");
        var candidates = source.CardIds.Select((id, index) => (Id: id, Index: index));
        if (availableAtSourceOnly) candidates = candidates.Where(item => _cardZones.GetLocation(item.Id) == source.SourceLocations[item.Index]);
        var cards = candidates.Select(item =>
            _cardZones.CardsAt(source.SourceLocations[item.Index]).SingleOrDefault(card => card.Id == item.Id) ??
            throw new InvalidOperationException("A bound card left its frozen source before selection."))
            .ToArray();
        if (availableAtSourceOnly && cards.Length == 0)
        {
            CancelProgramBindingAndCleanup(frame, "此次获得的牌已全部离开原区域，剩余交牌结束。");
            return SkillProgramStepOutcome.AwaitChild;
        }
        // 涉猎-style one-per-suit subsets must take exactly one card of every
        // distinct suit; the constraint leaves no room for partial takes.
        var constraintMinimum = minimumCards;
        var constraintMaximum = maximumCards;
        var promptMinimum = minimumCards;
        var promptMaximum = maximumCards;
        if (onePerSuit)
        {
            var distinctSuits = cards.Select(card => card.Suit).Distinct().Count();
            constraintMinimum = constraintMaximum = distinctSuits;
            promptMinimum = promptMaximum = distinctSuits;
        }
        else
        {
            // A program may explicitly allow a depleted revealed set to satisfy an
            // otherwise exact count. All existing exact-count programs remain strict.
            constraintMinimum = allowFewerWhenInsufficient ? Math.Min(minimumCards, cards.Length) : minimumCards;
            constraintMaximum = allowFewerWhenInsufficient ? Math.Min(maximumCards, cards.Length) : maximumCards;
        }
        var options = CardSubsetSelector.Enumerate(
            cards.Select(card => new CardSubsetCandidate(card.Id, card.Rank, card.Suit)).ToArray(),
            new CardSubsetConstraint(constraintMinimum, constraintMaximum, maximumRankSum, onePerSuit));
        if (options.Count == 0)
        {
            CancelProgramBindingAndCleanup(frame, "选牌约束没有合法结果，技能结算已取消。");
            return SkillProgramStepOutcome.AwaitChild;
        }

        var choices = options.Select(option =>
            new PromptChoice(
                new ChoiceId($"program-subset.frame-{frameId}.mask-{option.SelectionMask}"),
                option.CardIds.Count == 0
                    ? "不选择牌。"
                    : $"选择 {string.Join("、", option.CardIds.Select(cardId =>
                        cards.Single(card => card.Id == cardId)).Select(card =>
                        $"【{card.DisplayName}】{card.RankText}"))}（点数和 {option.RankSum}）。",
                option.CardIds,
                [],
                new Dictionary<string, string>
                {
                    ["program-action"] = "select-subset",
                    ["frame-id"] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["source-bind"] = sourceBind,
                    ["result-bind"] = resultBind,
                    ["rank-sum"] = option.RankSum.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["ai-order"] = aiOrder.ToString()
                }))
            .ToArray();

        var presentation = _contentRegistry!.GetSkill(frame.SkillId);
        _pendingDecision = new PendingDecision(
            DecisionKind.ProgramTrigger,
            ownerSeat,
            $"【{presentation.Name}】请选择符合约束的牌。",
            availableAtSourceOnly ? cards.Select(card => card.Id).ToArray() : source.CardIds,
            [],
            frame.WindowContext?.SourceSeat)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            TargetSeat = ownerSeat,
            SkillPrompt = new SkillPromptPresentation(
                frame.SkillId,
                presentation.Name,
                $"{presentation.Name} · 选择牌",
                onePerSuit
                    ? $"获得其中不同花色的牌各一张（共 {promptMaximum} 张），点数和不超过 {maximumRankSum}。"
                    : $"选择 {promptMinimum} 至 {promptMaximum} 张牌，点数和不超过 {maximumRankSum}。"),
            Choices = Array.AsReadOnly(choices.ToArray())
        };
        _status = _players[ownerSeat].IsHuman ? EngineStatus.AwaitingHumanResponse : EngineStatus.Running;
        return SkillProgramStepOutcome.AwaitChoice;
    }

    private void CancelProgramBindingAndCleanup(ProgramSkillFrame frame, string reason)
    {
        AddLog("SkillCancelled", reason, frame.OwnerSeat);
        FinishProgramSkill(frame, completed: false);
    }

    private void CleanupProgramBoundCards(ProgramSkillFrame frame, bool completed)
    {
        CleanupExactRepeatedJudgment(frame);
        CleanupDeckSlashSequence(frame);
        var boundIds = frame.CardSetBindings.SelectMany(binding => binding.CardIds)
            .Distinct().ToHashSet();
        var cards = _cardZones.CardsAt(CardLocation.Processing)
            .Where(card => boundIds.Contains(card.Id)).ToArray();
        if (cards.Length > 0)
            MoveCards(
                cards,
                CardLocation.Processing,
                CardLocation.DiscardPile,
                new CardMoveReason($"skill-program.{frame.SkillId}.{GetProgramBindingId(frame)}." +
                    (completed ? "complete-cleanup" : "cancel-cleanup")));
    }

    private SkillProgramStepOutcome MoveProgramBoundCards(
        long frameId,
        int ownerSeat,
        string sourceBind,
        string? exceptBind,
        SkillProgramCardDestination destination,
        CardZoneKind? destinationZone,
        CardMoveReason reason,
        IReadOnlyList<int>? bottomOrder = null)
    {
        var frame = GetActiveProgramFrame(frameId);
        frame = FreezeSequentialDiscardTopPayment(frame, sourceBind, exceptBind, destination);
        frame = FreezeLostHpChainedPayment(frame, sourceBind, exceptBind, destination);
        var source = frame.CardSetBindings.SingleOrDefault(binding => binding.Name == sourceBind);
        if (source is null)
        {
            CancelProgramBindingAndCleanup(
                frame,
                $"移动来源绑定“{sourceBind}”未生成，技能结算已取消。");
            return SkillProgramStepOutcome.Continue;
        }
        var ids = source.CardIds.ToHashSet();
        if (exceptBind is { } excluded)
        {
            var except = frame.CardSetBindings.SingleOrDefault(binding => binding.Name == excluded);
            if (except is null)
            {
                CancelProgramBindingAndCleanup(
                    frame,
                    $"移动排除绑定“{excluded}”未生成，技能结算已取消。");
                return SkillProgramStepOutcome.Continue;
            }
            ids.ExceptWith(except.CardIds);
        }
        var selected = source.CardIds.Select((cardId, index) =>
                (CardId: cardId, Location: source.SourceLocations[index]))
            .Where(item => ids.Contains(item.CardId))
            .ToArray();
        if (selected.Any(item => _cardZones.GetLocation(item.CardId) != item.Location))
            throw new InvalidOperationException("A bound card left its frozen source before its configured move.");
        if (destination == SkillProgramCardDestination.DiscardPile)
            selected = selected.Where(item => !IsForeignEquipmentDiscardPrevented(source.SelectionActorSeat ?? ownerSeat,
                _cardZones.CardsAt(item.Location).Single(card => card.Id == item.CardId),
                item.Location, OwnedCardMoveIntent.Discard)).ToArray();
        if (selected.Length == 0) return SkillProgramStepOutcome.Continue;
        if (!PreparePhaseAlcoholPayment(frame, sourceBind, reason)) return SkillProgramStepOutcome.Continue;
        if (destination == SkillProgramCardDestination.DiscardPile)
            FreezeLiejieDiscardColors(frame, sourceBind, selected.Select(item => item.CardId).ToArray(),
                selected.Select(item => item.Location).ToArray());
        if (destination == SkillProgramCardDestination.DrawPileBottom && selected.Length > 1 && bottomOrder is null)
        {
            if (selected.Length > 4)
                throw new InvalidOperationException("At most four revealed cards may be privately ordered at the draw-pile bottom.");
            var orders = EnumerateProgramCardOrders(selected.Select(item => item.CardId).ToArray()).ToArray();
            var choices = orders.Select((order, index) => new PromptChoice(
                new ChoiceId($"program-bottom.frame-{frameId}.order-{index}"),
                $"将 {string.Join("、", order.Select(cardId =>
                    _cardZones.CardsAt(CardLocation.Processing).Single(card => card.Id == cardId).DisplayName))} 依次置于牌堆底（从底向上）。",
                order, [],
                new Dictionary<string, string>
                {
                    ["program-action"] = "order-bound-cards",
                    ["source-bind"] = sourceBind,
                    ["except-bind"] = exceptBind ?? string.Empty
                })).ToArray();
            var skill = _contentRegistry!.GetSkill(frame.SkillId);
            _pendingDecision = new PendingDecision(
                DecisionKind.ProgramTrigger, ownerSeat,
                $"【{skill.Name}】请安排牌堆底牌顺序。",
                selected.Select(item => item.CardId).ToArray(), [], ownerSeat)
            {
                PromptId = CreatePromptId(),
                IsPrivate = true,
                TargetSeat = ownerSeat,
                SkillPrompt = new SkillPromptPresentation(frame.SkillId, skill.Name,
                    $"{skill.Name} · 牌堆底顺序", "选择剩余牌从牌堆底向上的顺序。"),
                Choices = Array.AsReadOnly(choices)
            };
            _status = _players[ownerSeat].IsHuman ? EngineStatus.AwaitingHumanResponse : EngineStatus.Running;
            return SkillProgramStepOutcome.AwaitChoice;
        }
        if (bottomOrder is not null)
        {
            if (destination != SkillProgramCardDestination.DrawPileBottom ||
                !bottomOrder.OrderBy(id => id).SequenceEqual(selected.Select(item => item.CardId).OrderBy(id => id)))
                throw new InvalidOperationException("The bottom order must be an exact permutation of the bound cards.");
            selected = bottomOrder.Select(cardId => selected.Single(item => item.CardId == cardId)).ToArray();
        }
        if (destination == SkillProgramCardDestination.DrawPileBottom &&
            selected.Any(item => item.Location != CardLocation.Processing))
            throw new InvalidOperationException("Draw-pile bottom placement requires revealed processing cards.");
        var target = destination switch
        {
            SkillProgramCardDestination.OwnerHand => CardLocation.Hand(ownerSeat),
            SkillProgramCardDestination.DiscardPile => CardLocation.DiscardPile,
            SkillProgramCardDestination.DrawPileBottom => CardLocation.DrawPile,
            SkillProgramCardDestination.DrawPileTop => CardLocation.DrawPile,
            SkillProgramCardDestination.SelectedTargetHand when frame.SelectedTargetSeats.Count == 1 =>
                CardLocation.Hand(frame.SelectedTargetSeats.Single()),
            SkillProgramCardDestination.PhaseOwnerHand when
                frame.WindowContext is { Window: SkillProgramTriggerWindow.PlayPhaseStarting, SourceSeat: { } phaseSeat } &&
                IsValidPlayerSeat(phaseSeat) => CardLocation.Hand(phaseSeat),
            SkillProgramCardDestination.OwnerPersistentZone when destinationZone is
                CardZoneKind.WoodenOxGrain or CardZoneKind.BuquWound or CardZoneKind.Authority or
                CardZoneKind.Chunlao => new CardLocation(destinationZone.Value, ownerSeat),
            _ => throw new InvalidOperationException($"Unsupported program card destination '{destination}'.")
        };
        if (destination == SkillProgramCardDestination.SelectedTargetHand &&
            ProgramInstructionResolver.Default.Resolve(frame, _contentRegistry!.GetSkill(frame.SkillId).Program!)
                .GetPausedInstruction(frame.InstructionIndex).Effect.AwaitMovementTriggers)
            return BeginBoundParticipantGift(frame, sourceBind, selected.Select(item => item.CardId).ToArray(), target, reason);
        if (destination == SkillProgramCardDestination.DiscardPile && selected.Select(item => item.Location).Distinct().Count() > 1 &&
            (ProgramInstructionResolver.Default.Resolve(frame, _contentRegistry!.GetSkill(frame.SkillId).Program!)
                .GetPausedInstruction(frame.InstructionIndex).Effect.AwaitMovementTriggers ||
             IsAtomicLiejieCostMove(frame, sourceBind)))
        {
            MoveProgramCardsFromMultipleSources(selected.Select(item => item.CardId).ToArray(), target, reason);
            return SkillProgramStepOutcome.Continue;
        }
        foreach (var group in selected.GroupBy(item => item.Location))
        {
            if (group.Key == target) continue;
            var cards = group.Select(item => _cardZones.CardsAt(group.Key)
                .Single(card => card.Id == item.CardId)).ToArray();
            MoveCards(cards, group.Key, target, reason);
            switch (destination)
            {
                case SkillProgramCardDestination.DrawPileBottom:
                    if (group.Key != CardLocation.Processing)
                        throw new InvalidOperationException("Draw-pile bottom placement requires revealed processing cards.");
                    _cardZones.PlaceDrawPileCardsAtBottom(cards.Select(card => card.Id).ToArray());
                    break;
                case SkillProgramCardDestination.DrawPileTop:
                    // The moved segment sits at the pile's top; restore the
                    // binding order so its first id is drawn next.
                    _cardZones.PlaceDrawPileCardsAtTop(cards.Select(card => card.Id).ToArray());
                    break;
            }
        }
        CommitLostHpChainedPayment(frameId);
        CommitPhaseAlcoholPayment(frameId);
        return SkillProgramStepOutcome.Continue;
    }

    private static IEnumerable<int[]> EnumerateProgramCardOrders(IReadOnlyList<int> ids)
    {
        if (ids.Count == 0) { yield return []; yield break; }
        for (var index = 0; index < ids.Count; index++)
        {
            var rest = ids.Where((_, current) => current != index).ToArray();
            foreach (var suffix in EnumerateProgramCardOrders(rest))
                yield return [ids[index], .. suffix];
        }
    }

    private IReadOnlyList<CardSnapshot> GetProgramPublicCards()
    {
        HashSet<int>? publicIds = null;
        var handControl = false;
        var handDraft = false;
        var comparison = false;
        var completedReveal = false;
        var categoryGift = false;
        for (var index = 0; index < _resolutionStack.Count; index++)
        {
            if (_resolutionStack[index] is not ProgramSkillFrame frame) continue;
            for (var bindingIndex = 0; bindingIndex < frame.CardSetBindings.Count; bindingIndex++)
            {
                var binding = frame.CardSetBindings[bindingIndex];
                if (binding.Visibility != SkillProgramCardSetVisibility.Public) continue;
                for (var cardIndex = 0; cardIndex < binding.CardIds.Count; cardIndex++)
                    AddPublicId(binding.CardIds[cardIndex]);
            }
            handControl |= frame.HandControlDraft is
                { Operation: SkillProgramEffectOp.RevealHandColorDiscardAndTake, Stage: "color", RevealedCardIds: not null };
            handDraft |= frame.PublicHandDraft is { Stage: >= 2 };
            comparison |= frame.HandComparisonDraft is not null;
            completedReveal |= frame.CompletedUndamagedTargetReveal is { SelectionIssued: true, RevealedMaterials.Count: > 0 };
            categoryGift |= frame.RecipientCategoryMark is
                { Operation: SkillProgramEffectOp.GiveHandAndGrantCategoryMark,
                  Stage: RecipientCategoryMarkStage.GiftChildren or RecipientCategoryMarkStage.Complete, Token: not null };
            if (frame.PhaseNamePrediction is { Stage: PhaseNamePredictionStage.Guessing, RevealedCardId: { } predictionId })
                AddPublicId(predictionId);
        }
        if (handControl) foreach (var id in GetProgramHandControlPublicCardIds()) AddPublicId(id);
        if (handDraft) foreach (var id in GetPublicHandDraftCardIds()) AddPublicId(id);
        if (comparison) foreach (var id in HandComparisonPublicIds()) AddPublicId(id);

        // Receipt-backed faces precede current physical appearances. Query these
        // protocols only when a live frame can expose a card, preserving their
        // validation and duplicate checks even when the same ID is bound below.
        List<CardSnapshot>? cards = null;
        HashSet<int>? shownIds = null;
        if (completedReveal) foreach (var card in CompletedUndamagedTargetRevealPublicCards()) AddCard(card);
        if (categoryGift) foreach (var card in RecipientCategoryMarkPublicCards()) AddCard(card);
        if (publicIds is not null)
        {
            var orderedIds = publicIds.ToArray();
            Array.Sort(orderedIds);
            foreach (var cardId in orderedIds)
            {
                var location = _cardZones.GetLocation(cardId);
                AddCard(ToSnapshot(_cardZones.CardsAt(location).Single(card => card.Id == cardId)));
            }
        }
        return cards is null ? Array.Empty<CardSnapshot>() : cards.ToArray();

        void AddPublicId(int id) => (publicIds ??= []).Add(id);
        void AddCard(CardSnapshot card)
        {
            if ((shownIds ??= []).Add(card.Id)) (cards ??= []).Add(card);
        }
    }

    private IReadOnlyList<CardSnapshot> CompletedUndamagedTargetRevealPublicCards()
    {
        var frames = _resolutionStack.OfType<ProgramSkillFrame>()
            .Where(frame => frame.CompletedUndamagedTargetReveal is { SelectionIssued: true, RevealedMaterials.Count: > 0 })
            .Select(frame => frame.Id).ToHashSet();
        return frames.Count == 0 ? [] : Array.AsReadOnly(CompleteProgramEventHistory()
            .OfType<ProgramCardsRevealedEvent>()
            .Where(shown => frames.Contains(shown.FrameId) && shown.Bind == CompletedUndamagedRevealBind)
            .SelectMany(shown => shown.Cards).DistinctBy(card => card.Id).ToArray());
    }

    private void GrantProgramTurnSkills(ProgramSkillFrame frame, IReadOnlyList<string> skillIds)
    {
        var active = GetActiveProgramFrame(frame.Id);
        if (active.OwnerSeat != frame.OwnerSeat || active.SkillId != frame.SkillId ||
            active.TriggerId != frame.TriggerId)
            throw new InvalidOperationException("Turn-scoped skill grants require the active program binding.");

        var owner = _players[frame.OwnerSeat];
        var granted = skillIds.Distinct(StringComparer.Ordinal).ToArray();
        foreach (var skillId in granted) _ = _contentRegistry!.GetSkill(skillId);
        var sourceId = $"turn:{_turnNumber}:{frame.SkillId}:{GetProgramBindingId(frame)}";
        foreach (var skillId in granted)
        {
            var grantId = $"{sourceId}:{skillId}";
            if (!owner.SkillGrants.Grants.Any(grant => grant.GrantId == grantId))
                owner.SkillGrants.Grant(new SkillGrant(grantId, skillId, grantId, sourceId));
        }
        AdvanceEventRulesAndQueueFact(new ProgramTurnSkillsGrantedEvent(
            frame.Id,
            frame.SkillId,
            GetProgramBindingId(frame),
            owner.Seat,
            Array.AsReadOnly(granted)));
    }

    private bool HasPendingProgramBoundCards =>
        _resolutionStack.OfType<ProgramSkillFrame>()
            .SelectMany(frame => frame.CardSetBindings)
            .SelectMany(binding => binding.CardIds)
            .Distinct()
            .Any(cardId => _cardZones.GetLocation(cardId) == CardLocation.Processing);

    private bool IsProgramProcessingConsistent(
        CardAttackHandle attack,
        IReadOnlyList<Card> processing)
    {
        var boundIds = _resolutionStack.OfType<ProgramSkillFrame>()
            .SelectMany(frame => frame.CardSetBindings)
            .SelectMany(binding => binding.CardIds)
            .Distinct()
            .Where(cardId => _cardZones.GetLocation(cardId) == CardLocation.Processing)
            .ToHashSet();
        if (boundIds.Count == 0 || boundIds.Any(cardId => processing.All(card => card.Id != cardId)))
            return false;

        var allowedParentIds = attack.PhysicalCards.Select(card => card.Id).ToHashSet();
        if (ActiveJudgment is { } currentJudgment && GetJudgmentAttack(currentJudgment) is { } judgmentAttack)
            allowedParentIds.UnionWith(judgmentAttack.PhysicalCards.Select(card => card.Id));
        if (ActiveBorrowedSword is { } borrowedSword)
            allowedParentIds.Add(borrowedSword.Card.Id);
        if (_resolutionStack.OfType<ProgramCardTriggerWindowFrame>().LastOrDefault() is { } programFrame)
            allowedParentIds.UnionWith(programFrame.Action.PhysicalCards.Select(cost => cost.CardId));

        return processing.Where(card => !boundIds.Contains(card.Id))
            .All(card => allowedParentIds.Contains(card.Id));
    }

    private IReadOnlyList<ProgramTriggerCandidate> CollectProgramTriggerCandidates(
        CharacterState owner,
        SkillProgramTriggerWindow window,
        int occurrenceIndex = 0)
    {
        var shard = GetSkillBindingShard(owner);
        var candidates = shard.GetTriggerCandidates(window, occurrenceIndex);
        // Issued Play-ending debt belongs to its receipt, even after its source
        // grant disappears. Other empty windows have no candidates to prepare.
        if (window != SkillProgramTriggerWindow.PlayEnding ||
            owner.Seat != _currentSeat || _phase != TurnPhase.Play ||
            ProgramEventHistory<PhaseHandSeizureIssuedEvent>().Count == 0)
            return candidates;
        return PrepareProgramTriggerCandidates(owner, window, occurrenceIndex, shard, candidates);
    }

    private IReadOnlyList<ProgramTriggerCandidate> PrepareProgramTriggerCandidates(
        CharacterState owner, SkillProgramTriggerWindow window, int occurrenceIndex,
        SkillBindingShard shard, IReadOnlyList<ProgramTriggerCandidate> candidates)
    {
        using var issued = IssuedPhaseHandDebtCandidates(owner, window, occurrenceIndex).GetEnumerator();
        if (!issued.MoveNext()) return candidates;
        var result = candidates.ToList();
        var keys = candidates.Select(shard.TriggerCandidateKey).ToHashSet();
        do
        {
            var candidate = issued.Current;
            var trigger = GetProgramTrigger(candidate);
            var key = (candidate.SkillId, candidate.BindingId,
                trigger.NamedUsageGroup is not null || trigger.DynamicUsageLimit is not null ||
                ProgramInstructionResolver.Default.Features(trigger).HasOperation(SkillProgramEffectOp.DiscardHandToNamedTurnCount) ? "" : candidate.SkillInstanceId);
            if (keys.Add(key)) result.Add(candidate);
        } while (issued.MoveNext());
        return Array.AsReadOnly(result.ToArray());
    }

    private SkillProgramTrigger GetProgramTrigger(ProgramTriggerCandidate candidate) =>
        ProgramInstructionResolver.Default.Resolve(_contentRegistry!.GetSkill(candidate.SkillId).Program!,
            ProgramInstructionSourceKind.Trigger, candidate.BindingId).Trigger!;

    private IReadOnlyList<ProgramTriggerCandidate> CollectEligibleProgramTriggerCandidates(
        CharacterState owner,
        SkillProgramTriggerWindow window,
        SkillProgramTriggerFacts facts)
    {
        var candidates = CollectProgramTriggerCandidates(owner, window);
        if (candidates.Count == 0) return candidates;
        return candidates
            .Where(candidate =>
            {
                var trigger = GetProgramTrigger(candidate);
                return !IsPhaseNamePredictionResolver(candidate, _contentRegistry.GetSkill(candidate.SkillId).Program!) && !trigger.DeferredTurnEndOnly && (!IsPhaseHandDebtResolver(candidate) || CurrentPhaseHandSeizureDebt(candidate.OwnerSeat, candidate.SkillId, candidate.SkillInstanceId, candidate.GameplayHash, candidate.BindingId) is not null) && (trigger.EvaluateConditionAtResolution || trigger.Condition.Evaluate(facts, candidate.SkillId, candidate.SkillInstanceId)) &&
                    HasInitialOwnedCardSelectionCandidates(owner, trigger) && CanOfferGameActivationAwakening(owner.Seat, trigger);
            })
            .ToArray();
    }

    private bool HasInitialOwnedCardSelectionCandidates(CharacterState owner, SkillProgramTrigger trigger)
    {
        if (ProgramInstructionResolver.Default.Features(trigger).FirstNonTargetSelection is not
                {
                    Op: SkillProgramEffectOp.SelectOwnedCards,
                    Target: SkillProgramEffectTarget.Owner,
                    Condition.Kind: SkillProgramConditionKind.Always
                } selection)
            return true;
        var required = selection.MinimumCards > 0 ? selection.MinimumCards : selection.Amount;
        if (required <= 0) return true;
        var available = selection.Zones.Sum(zone =>
            _cardZones.CardsAt(new CardLocation(zone, owner.Seat)).Count(card =>
                (selection.CardKinds.Count == 0 || selection.CardKinds.Contains(card.Kind)) &&
                (selection.Suits.Count == 0 || selection.Suits.Contains(GetProgramEffectiveSuit(owner, card)))));
        return available >= required;
    }

    private bool CanRunProgramTrigger(
        ProgramTriggerCandidate candidate,
        ProgramSkillWindowContext context)
    {
        if (!IsValidPlayerSeat(candidate.OwnerSeat) || candidate.OwnerSeat != context.OwnerSeat) return false;
        if (IsPhaseHandDebtResolver(candidate)) return CanRunIssuedPhaseHandDebt(candidate, context);
        if (IsDeferredPrivateOfferResolver(candidate)) return CanRunDeferredPrivateOffer(candidate, context);
        if (context.Window == SkillProgramTriggerWindow.ActualSlashTargetPenalty) return CanRunSlashTargetPenalty(candidate, context);
        if (IsSlashTargetBenefitWindow(context.Window)) return CanRunSlashTargetBenefitCandidate(candidate, context);
        var owner = _players[candidate.OwnerSeat];
        if (context.Window != SkillProgramTriggerWindow.OwnerDied && !owner.IsAlive ||
            !HasRuntimeSkillInstance(owner, candidate.SkillId, candidate.SkillInstanceId) && !HasIssuedOriginalTargetCandidate(candidate, context) && !HasIssuedPhaseNamePrediction(candidate, context) && !HasIssuedFixedDistanceDebtCandidate(candidate, context) && !HasIssuedGiftedSlashRewardCandidate(candidate, context) && !HasIssuedJoinedTrickDamageRewardCandidate(candidate, context) && !HasIssuedRoundGainedUseCandidate(candidate, context) ||
            _contentRegistry.Skills.GetValueOrDefault(candidate.SkillId)?.Program is not { } program ||
            program.GameplayHash != candidate.GameplayHash)
            return false;
        var trigger = ProgramInstructionResolver.Default.FindTrigger(program, candidate.BindingId);
        if (trigger is null || trigger.Window != context.Window || !CanPayProgramMarkerCost(owner, trigger.MarkerCost))
            return false;
        if (!CanRunSoleTargetReplacementTargetCandidate(candidate, trigger, context)) return false;
        if (!CanOfferPhaseStartCardControl(candidate, trigger, context)) return false;
        if (!CanOfferIncomingDistanceCourtesy(candidate, trigger, context)) return false;
        if (!CanRunTurnDrawDebtPayment(candidate, trigger, context) || !CanRunSourceFactionPrevention(candidate, trigger, context)) return false;
        if (!CanRunDyingSuitsAndEndingHistory(candidate, trigger, context)) return false;
        if (!CanRunDyingOwnedCard(candidate, trigger, context)) return false;
        if (!CanRunSourceCurseTrigger(candidate, trigger, context)) return false;
        if (!CanRunGainGiftTrigger(candidate, trigger, context)) return false;
        if (!CanRunShortRangeSlash(candidate, trigger, context)) return false;
        if (!CanRunActualHandGainTrigger(candidate, trigger, context)) return false;
        if (!CanRunShiYuanTargetDraw(candidate, trigger, context)) return false;
        var features = ProgramInstructionResolver.Default.Features(trigger);
        if (features.HasOperation(SkillProgramEffectOp.LuochongResolve) &&
            !CanRunLuochongResolve(candidate.OwnerSeat)) return false;
        if (features.HasOperation(SkillProgramEffectOp.TongxieArm) &&
            !CanRunTongxieArm(candidate.OwnerSeat)) return false;
        if (features.HasOperation(SkillProgramEffectOp.TongxieFollowUp) &&
            !CanRunTongxieFollowUp(candidate.OwnerSeat, context)) return false;
        if (features.HasOperation(SkillProgramEffectOp.TongxieGuard) &&
            !CanRunTongxieGuard(candidate.OwnerSeat, context)) return false;
        if (IsOtherActualBasicDiscardTrigger(trigger) && !CanRunOtherActualBasicDiscard(candidate, context)) return false;
        if (!CanRunPublicPilePreparation(candidate, trigger, context)) return false;
        if (!CanRunPublicPileCashOut(candidate, trigger, context)) return false;
        if (!CanOfferGiftedSlashUseReward(candidate, trigger, context)) return false;
        if (!CanOfferDesignatedExtraTarget(candidate, trigger, context)) return false;
        if (!CanOfferSoleTargetProtection(candidate, trigger, context)) return false;
        if (!CanOfferNamedAmbush(candidate, trigger, context) || !CanOfferDamageSourceHandChoice(candidate, trigger, context)) return false;
        if (!CanOfferRicePile(candidate, trigger, context)) return false;
        if (!CanOfferExtraEffectsAndRankGuess(candidate, trigger, context)) return false;
        if (!CanOfferUniqueLeaderTrickTarget(candidate, trigger, context)) return false;
        if (!CanOfferRoundGainedTrickTarget(candidate, trigger, context)) return false;
        if (!CanOfferRoundGainedEquipmentDraw(candidate, trigger, context)) return false;
        if (!CanOfferFriendTrio(candidate, trigger, context) || !CanOfferFriendPangTong(candidate, trigger, context)) return false;
        if (!CanOfferJoinedTrickDamageReward(candidate, trigger, context)) return false;
        if (!CanRunFireTargetBenefit(candidate, trigger, context)) return false;
        if (!CanRunPaidColorDamageClaim(candidate, trigger, context)) return false;
        if (!CanRunSameTypeAid(candidate, trigger, context)) return false;
        if (!CanRunPrepDiscard(candidate, trigger, context)) return false;
        if (!CanRunUniqueHpPeer(candidate, trigger, context)) return false;
        if (!CanRunRecipientConsequences(candidate, trigger)) return false;
        if (!CanRunHalfHandPhaseDebt(candidate, trigger, context)) return false;
        if (!CanRunFixedRecipientBenefit(candidate, trigger, context)) return false;
        if (!CanRunEndingPair(candidate, trigger, context)) return false;
        if (!CanRunPlacedEquipmentBenefit(candidate, trigger, context)) return false;
        if (!CanRunActualUseTarget(candidate, context) || !CanOfferOwnTrickOrHandCategory(candidate, trigger, context)) return false;
        if (!CanOfferOriginalTargetAddition(candidate, trigger, context)) return false;
        if (!CanOfferActorHandLimitPenalty(candidate, trigger, context)) return false;
        if (!CanRunProgramDyingAlcoholPolicy(trigger, context, candidate.OwnerSeat)) return false;
        if (!CanOfferRoundPileAlcohol(candidate, trigger, context) || !CanOfferCurrentSlashFire(candidate, trigger, context) || !CanOfferSuitPreventionBenefit(candidate, trigger, context) || !CanOfferSignedDamagePayment(candidate, trigger, context)) return false;
        if (!CanOfferActualDiscardRecovery(candidate, context)) return false;
        if (!CanOfferFriendEvent(candidate, trigger, context)) return false;
        if (!CanOfferShownEntityTurnPolicy(candidate, trigger, context)) return false;
        if (!CanOfferFinalTargetSlash(candidate, trigger, context)) return false;
        if (!CanRunOtherDyingVictimRecovery(trigger, context, candidate.OwnerSeat)) return false;
        if (!CanRunAlcoholSlashSuppression(trigger, context, candidate.OwnerSeat)) return false;
        if (!CanOfferGameActivationAwakening(candidate.OwnerSeat, trigger)) return false;
        if (!CanOfferTurnDefaultStatProgram(candidate.OwnerSeat, candidate.SkillId, trigger, context)) return false;
        if (!CanOfferOffTurnUsedCards(candidate, context)) return false;
        if (!CanOfferOrderedPrintedSkillLoss(candidate.OwnerSeat, trigger, context)) return false;
        if (!CanOfferOverflowTargetCancellation(candidate, trigger, context)) return false;
        if (!CanOfferGuanVariant(candidate, trigger, context)) return false;
        if (!CanOfferDamageCounterpartAcquisition(candidate, trigger, context)) return false;
        if (!CanOfferPairedColorDisposition(candidate, trigger, context)) return false;
        if (!CanOfferRecipientCategoryMarkProgram(candidate, trigger, context)) return false;
        if (!CanRunOutsidePhaseDrawDiscardTrigger(candidate, trigger, context)) return false;
        if (!CanOfferSameNameHandDiscardOrDamage(candidate, trigger, context) ||
            !CanOfferCompletedUndamagedTargetReveal(candidate.OwnerSeat, trigger, context)) return false;
        if (!CanOfferOriginalHandEntityProgram(candidate.OwnerSeat, candidate.SkillId, trigger, context, candidate.SkillInstanceId)) return false;
        if (!CanOfferLastDamageSourceReciprocity(candidate.OwnerSeat, candidate.SkillId, trigger, context)) return false;
        if (trigger.Effects is [{ Op: SkillProgramEffectOp.SettlePhaseNamePrediction }] && !HasIssuedPhaseNamePrediction(candidate, context)) return false;
        if (!CanRunOwnedDamagePointJudgment(trigger, context, candidate.OwnerSeat)) return false;
        if (!CanRunDamageJudgmentSuitPayment(trigger, context, candidate.OwnerSeat)) return false;
        if (features.HasOperation(SkillProgramEffectOp.ObtainDamageTargetCardAndResolveCategory) &&
            !CanOfferDamageTargetObtain(candidate.OwnerSeat, context)) return false;
        if (features.HasOperation(SkillProgramEffectOp.DiscardDamageTargetAndClaimMount) &&
            !CanOfferDamageTargetMount(candidate.OwnerSeat, context)) return false;
        if (!IsGainPhaseQualified(trigger, candidate.OwnerSeat, context.MovementBatch?.MovementTiming)) return false;
        if (!CanOfferFinalTargetGift(candidate, context, features)) return false;
        if (!CanOfferConvertingGift(candidate, context, features)) return false;
        if (!CanOfferPublicPileColor(owner,candidate,trigger,context)) return false;
        if (!AdvancedTriggerPrerequisites(owner, candidate.SkillId, trigger)) return false;
        if (!CanRunFactionActionReward(candidate, trigger, context)) return false;
        if (!CanOfferCardActionContest(owner,trigger,context)) return false;
        if (features.HasOperation(SkillProgramEffectOp.UseDeckSlashesThenShuffle) &&
            (context.TargetSeat is not { } deckTarget || _players[deckTarget].Gender != GeneralGender.Male ||
             owner.Hp <= 0 || _cardZones.Count(CardLocation.DrawPile) > owner.Hp * 10)) return false;
        if (features.HasOperation(SkillProgramEffectOp.NullifyFirstTurnTargetByHand) && !IsFirstTurnTarget(candidate, context)) return false;
        if (features.HasOperation(SkillProgramEffectOp.QiaoliEndingEquipmentGain) &&
            !HasQiaoliEndingGainPending(candidate.OwnerSeat)) return false;
        if (!CanOfferProgramHandControl(owner, trigger)) return false;
        if (!CanOfferResponseExchange(candidate, trigger, context)) return false;
        if (!CanOfferAttributedEvent(trigger,context)) return false;
        if (!CanOfferPhaseAlcohol(trigger, context)) return false;
        if (!CanOfferUnequalHandHp(trigger, context, candidate.OwnerSeat)) return false;
        if (!CanOfferTargetedOrdinaryTrick(candidate, trigger, context)) return false;
        if (trigger.NoDyingAtActivation && (ActiveDying is not null || _players.Any(p => p.IsAlive && p.Hp <= 0))) return false;
        if (features.HasOperation(SkillProgramEffectOp.SuppressGeneralSkill) &&
            (_phase != TurnPhase.Play || owner.Seat != _currentSeat || context.TargetSeat is not { } target ||
             _programSuppressions.Any(item => item.SourceSeat == owner.Seat && item.TargetSeat == target))) return false;
        if (!trigger.Condition.Evaluate(trigger.EvaluateConditionAtResolution ? CaptureProgramTriggerFacts(owner) : context.Facts ?? CaptureProgramTriggerFacts(owner),
                candidate.SkillId, candidate.SkillInstanceId))
            return false;
        if (!HasInitialOwnedCardSelectionCandidates(owner, trigger)) return false;
        if (!CanOfferGrantedPhaseSlash(candidate, trigger)) return false;
        if (!CanOfferAlternativePhaseCost(owner, trigger, candidate)) return false;
        if (IsConfirmedActualStartingSubstitution(context)) return false;
        if (trigger.UsageScope is { } scope && ProgramTriggerUsageLimit(trigger) is { } limit &&
            _skillRuntimeState.GetUsage(
                owner.Seat, candidate.SkillId, ProgramTriggerUsageId(candidate), scope) >= limit)
            return false;
        // Only an initial, unconditional payment is a prerequisite. A later payment
        // may intentionally use cards or participants produced by earlier nodes.
        var initialPayments = features.InitialDiscardPayments;
        if (initialPayments.Count > 1)
        {
            var available = features.InitialDiscardPaymentZones
                .SelectMany(zone => _cardZones.CardsAt(new CardLocation(zone, owner.Seat))
                    .Where(card => !IsSelfHandCategoryDiscardForbidden(owner.Seat, card, new(zone, owner.Seat), OwnedCardMoveIntent.Discard))
                    .Where(card => zone != CardZoneKind.Equipment ||
                        !IsActiveProgramSourceEquipmentCard(owner.Seat, candidate.SkillId,
                            candidate.SkillInstanceId, card)))
                .Select(card => card.Id).Distinct().Count();
            if (available < features.InitialDiscardPaymentAmount) return false;
        }
        if (features.FirstNonTargetSelection is
            {
                Op: SkillProgramEffectOp.SelectAndMoveOwnedCard,
                Condition.Kind: SkillProgramConditionKind.Always
            } payment)
        {
            var payer = payment.CardOwnerRef?.Kind switch
            {
                ProgramParticipantRef.Owner => owner.Seat,
                ProgramParticipantRef.Actor => context.CardUse?.ActorSeat,
                ProgramParticipantRef.EventTarget => context.TargetSeat,
                _ => null
            };
            if (payer is { } payerSeat && (!IsValidPlayerSeat(payerSeat) ||
                !payment.Zones.Any(zone => _cardZones.CardsAt(new CardLocation(zone, payerSeat)).Any(card =>
                    (payment.CardCategories.Count == 0 ||
                     MatchesProgramCardCategory(card.Kind, payment.CardCategories)) &&
                    (zone != CardZoneKind.Equipment || payerSeat != owner.Seat ||
                     !IsActiveProgramSourceEquipmentCard(owner.Seat, candidate.SkillId,
                         candidate.SkillInstanceId, card))))))
                return false;
        }
        if ((features.HasOperation(SkillProgramEffectOp.GrantFactionPopulationMarker) ||
             program.Modifiers.Any(modifier => modifier.ValueExpression == SkillRuleValueExpression.OwnerMarkerCount) &&
             _contentRegistry.GetSkill(candidate.SkillId).Tags.HasFlag(SkillTag.Lord)) &&
            !HasSkillRoleQualification(owner, candidate.SkillId, candidate.SkillInstanceId, Role.Lord)) return false;
        if (features.HasOperation(SkillProgramEffectOp.RemoveSelectedCurrentArrowBarrageTarget) && GetCurrentArrowBarrageTargets(owner.Seat, context).Count == 0) return false;
        if (features.HasOperation(SkillProgramEffectOp.GrantFactionPopulationMarker) && HasInitialPopulationMarkerGrant(owner.Seat, candidate.SkillId, context)) return false;
        if (features.HasOperation(SkillProgramEffectOp.CollectFinalTargetCardInPublicPile) && !CanCollectFinalTargetPile(owner.Seat, context)) return false;
        if (features.HasOperation(SkillProgramEffectOp.DiscardNonFinalTargetCardThenDraw) && !CanOfferNonFinalTargetPayment(candidate, context)) return false;
        if (features.HasOperation(SkillProgramEffectOp.UseBoundCardsAsSlash) && !CanOfferTriggeredSlashConversion(candidate, trigger, context)) return false;
        if (features.ForOperation(SkillProgramEffectOp.SelectTarget).Any(effect =>
            effect.Condition.Kind != SkillProgramConditionKind.ChoiceIs &&
            effect.TargetKind is { } kind && !GetProgramTargetSeats(owner.Seat, kind, context, effect.Marker).Any(seat =>
                effect.Zones.Count == 0 || effect.Zones.Any(zone => zone switch
                {
                    CardZoneKind.Hand => GetHand(_players[seat]).Count > 0,
                    CardZoneKind.Equipment => GetEquipment(_players[seat]).Count > 0,
                    CardZoneKind.Judgment => GetJudgment(_players[seat]).Count > 0,
                    _ => false
                }))))
            return false;
        if (features.ForOperation(SkillProgramEffectOp.SelectTargets).Any(effect =>
            effect.TargetKind == SkillProgramTargetKind.CurrentCardUseTargets &&
            GetProgramTargetSeats(owner.Seat, SkillProgramTargetKind.CurrentCardUseTargets, context).Count <
                effect.MinimumTargets))
            return false;
        if (features.ForOperation(SkillProgramEffectOp.SelectTargets).Any(effect => effect.TargetKind == SkillProgramTargetKind.LivingWhoseAttackRangeIncludesLord && GetProgramTargetSeats(owner.Seat, effect.TargetKind.Value, context).Count < effect.MinimumTargets)) return false;
        return context.Window switch
        {
            SkillProgramTriggerWindow.OtherActualUseTargeted => CanRunActualUseTarget(candidate, context),
            SkillProgramTriggerWindow.SkillsChanged => true,
            SkillProgramTriggerWindow.ProgramTargetCommitted => IsProgramTargetContextValid(context) && EnabledSkillPrograms(owner).Any(item => item.Id == candidate.SkillId),
            SkillProgramTriggerWindow.CharacterTurnedOver or SkillProgramTriggerWindow.CharacterTurnedFaceUp or SkillProgramTriggerWindow.CharacterEnteredChain =>
                context.TargetSeat is { } changedSeat && _players[changedSeat].IsAlive &&
                _resolutionStack.OfType<ProgramLifecycleTriggerWindowFrame>().LastOrDefault() is { } stateWindow &&
                stateWindow.Id == context.ParentFrameId && stateWindow.OwnerSeat == changedSeat &&
                stateWindow.Window == context.Window && stateWindow.CharacterStateContinuation is not null,
            SkillProgramTriggerWindow.JudgmentPhaseStarting =>
                context.SourceSeat == _currentSeat && context.TargetSeat == _currentSeat &&
                (trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.Own ? owner.Seat == _currentSeat : owner.Seat != _currentSeat) &&
                _resolutionStack.OfType<ProgramLifecycleTriggerWindowFrame>().LastOrDefault() is { } judgmentStart &&
                judgmentStart.Id == context.ParentFrameId && judgmentStart.Window == context.Window,
            SkillProgramTriggerWindow.TurnStartBeforeNormalFlow =>
                context.SourceSeat == _currentSeat &&
                (owner.Seat == _currentSeat
                    ? context.SourceSeat == owner.Seat
                    : trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.OtherLiving &&
                      _players[_currentSeat].IsAlive),
            SkillProgramTriggerWindow.RoundStarting =>
                owner.IsAlive && context.SourceSeat == _currentSeat && _roundNumber > 0,
            SkillProgramTriggerWindow.DrawPhaseStarting =>
                (owner.Seat == _currentSeat && context.SourceSeat == owner.Seat && CanRunDrawPhaseProgramTrigger(owner, trigger) ||
                 features.HasOperation(SkillProgramEffectOp.AddMarkerSubjectNormalDraw) && context.SourceSeat==_currentSeat && context.TargetSeat==_currentSeat) && _phase == TurnPhase.Draw,
            SkillProgramTriggerWindow.CardEffectBeforeApply => CanRunCardEffectCandidate(candidate, context),
            SkillProgramTriggerWindow.AfterTurnEnded =>
                CanRunAfterTurnEndedCandidate(candidate, context, trigger),
            SkillProgramTriggerWindow.GameStarting =>
                _phase == TurnPhase.NotStarted && _resolutionStack.OfType<ProgramLifecycleTriggerWindowFrame>()
                    .Any(frame => frame.Id == context.ParentFrameId && frame.Window == SkillProgramTriggerWindow.GameStarting),
            SkillProgramTriggerWindow.DrawPhaseSkipped => IsActualSkippedDrawContext(context),
            SkillProgramTriggerWindow.AfterNormalDraw or SkillProgramTriggerWindow.DrawPhaseEnded =>
                owner.Seat == _currentSeat && context.SourceSeat == owner.Seat && _phase == TurnPhase.Draw ||
                context.Window == SkillProgramTriggerWindow.DrawPhaseEnded && IsRecipientCategoryGiftDrawContext(candidate, context),
            SkillProgramTriggerWindow.PlayEnding =>
                context.SourceSeat == _currentSeat && _phase == TurnPhase.Play &&
                (trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.Own
                    ? owner.Seat == _currentSeat
                    : trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.AnyLiving ||
                      owner.Seat != _currentSeat),
            SkillProgramTriggerWindow.PlayPhaseStarting =>
                context.SourceSeat == _currentSeat && _phase == TurnPhase.Play &&
                (trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.Own
                    ? owner.Seat == _currentSeat
                    : owner.Seat != _currentSeat && _players[_currentSeat].IsAlive) &&
                _resolutionStack.OfType<PlayPhaseStartingBoundaryFrame>().LastOrDefault() is { } starting &&
                starting.Id == context.ParentFrameId && starting.OwnerSeat == _currentSeat,
            SkillProgramTriggerWindow.TurnEnding =>
                context.SourceSeat == _currentSeat && context.TargetSeat == _currentSeat &&
                (trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.IssuedFixedDistanceEnding
                    ? MatchesFixedDistanceDebt(candidate, context, false)
                    : trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.PaidPrepDiscardEnding
                    ? MatchesPrepDiscardEnding(candidate, context, false)
                    : trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.EarnedActualEnding
                    ? MatchesEarnedActualEnding(candidate, context, false)
                    : trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.OwnOrPreviousLiving
                    ? MatchesFrozenOwnOrPreviousEnding(candidate, context)
                    : trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.Own
                        ? owner.Seat == _currentSeat
                        : owner.Seat != _currentSeat && _players[_currentSeat].IsAlive) &&
                _resolutionStack.OfType<TurnEndingBoundaryFrame>().LastOrDefault() is { } ending &&
                ending.Id == context.ParentFrameId && ending.OwnerSeat == _currentSeat,
            SkillProgramTriggerWindow.DyingEntering =>
                ActiveDying is { } entering && entering.VictimSeat == context.TargetSeat &&
                (trigger.Subject == SkillProgramTriggerSubject.Any || entering.VictimSeat == owner.Seat) &&
                _players[entering.VictimSeat].Hp <= 0 &&
                _resolutionStack.OfType<ProgramLifecycleTriggerWindowFrame>().LastOrDefault() is { } entry &&
                entry.Id == context.ParentFrameId && entry.ResumeDyingFrameId == entering.FrameId,
            SkillProgramTriggerWindow.SelfDyingResponse =>
                ActiveDying is { } dying && dying.FrameId == context.ParentFrameId &&
                dying.VictimSeat == owner.Seat && dying.ResponderSeat == owner.Seat && owner.Hp <= 0,
            SkillProgramTriggerWindow.DyingResponse =>
                ActiveDying is { } currentDying && currentDying.FrameId == context.ParentFrameId &&
                currentDying.VictimSeat == context.TargetSeat && currentDying.ResponderSeat == owner.Seat &&
                _players[currentDying.VictimSeat].Hp <= 0,
            SkillProgramTriggerWindow.BeforeDamageApplied =>
                _resolutionStack.OfType<BeforeDamageProgramWindowFrame>().LastOrDefault() is { } beforeDamage &&
                beforeDamage.Id == context.ParentFrameId &&
                beforeDamage.TargetSeat == context.TargetSeat &&
                context.SourceSeat == (BeforeDamageHasNoSource(beforeDamage) ? null : beforeDamage.SourceSeat) &&
                beforeDamage.Amount == context.Amount &&
                !beforeDamage.Prevented && beforeDamage.RedirectedTargetSeat is null &&
                (trigger.Subject == SkillProgramTriggerSubject.DamageTarget
                    ? owner.Seat == beforeDamage.TargetSeat &&
                      !(features.HasOperation(SkillProgramEffectOp.RedirectCurrentDamage) &&
                        CurrentDamageAttempt?.DamageRedirected == true)
                    : trigger.Subject == SkillProgramTriggerSubject.DamageSource
                        ? !BeforeDamageHasNoSource(beforeDamage) && owner.Seat == beforeDamage.SourceSeat && owner.Seat != beforeDamage.TargetSeat
                        : owner.Seat != beforeDamage.TargetSeat),
            SkillProgramTriggerWindow.DamageAppliedBeforeDying or
                SkillProgramTriggerWindow.AfterDamageApplied =>
                context.Amount > 0 && trigger.Subject switch
                {
                    SkillProgramTriggerSubject.Owner => context.TargetSeat == owner.Seat,
                    SkillProgramTriggerSubject.DamageTarget => context.Window == SkillProgramTriggerWindow.DamageAppliedBeforeDying &&
                        features.HasOperation(SkillProgramEffectOp.DrawByDamageCardColor) && context.TargetSeat == owner.Seat,
                    SkillProgramTriggerSubject.Source =>
                        context.SourceSeat == owner.Seat &&
                        ActiveDamageTrigger is { } sourceDamage &&
                        MatchesAfterDamageProgramSource(GetDamageTriggerAttack(sourceDamage), trigger),
                    SkillProgramTriggerSubject.DamageSource => context.SourceSeat == owner.Seat,
                    SkillProgramTriggerSubject.Any => true,
                    _ => false
                } &&
                CanRunAfterDamageProgramTrigger(owner, trigger, context),
            SkillProgramTriggerWindow.OtherActualTurnStarted => CanRunForeignActualTurnContest(candidate, context),
            SkillProgramTriggerWindow.AfterHpLost or SkillProgramTriggerWindow.AfterHpRecovered or SkillProgramTriggerWindow.AfterHealthChanged =>
                context.HpChange is { } change && change.TargetSeat == owner.Seat && change.Amount > 0 &&
                _resolutionStack.OfType<HpChangedTriggerWindowFrame>().LastOrDefault() is { } hpWindow &&
                hpWindow.Id == context.ParentFrameId && hpWindow.Change == change &&
                hpWindow.Candidates[hpWindow.CandidateIndex] == candidate,
            SkillProgramTriggerWindow.CardsMoved or SkillProgramTriggerWindow.CardsGained =>
                context.MovementBatch is { } batch &&
                batch.Id == context.ParentFrameId &&
                _resolutionStack.OfType<CardsMovedTriggerWindowFrame>().LastOrDefault()?.Id == batch.Id &&
                (IsNeighborDiscardTopTrigger(trigger)
                    ? NeighborDiscardIndexes(batch, owner.Seat).Length > 0 &&
                      context.TargetSeat == owner.Seat && context.SourceSeat == NeighborDiscardSourceSeat(batch, owner.Seat) &&
                      NeighborDiscardFact(batch, owner.Seat)?.PreviousLivingSeat == context.Facts?.FrozenPreviousLivingSeat
                    : IsOtherLastHandLossTrigger(trigger)
                        ? context.SourceSeat is { } loserSeat && IsValidPlayerSeat(loserSeat) && loserSeat != owner.Seat &&
                          _players[loserSeat].IsAlive && _phase == TurnPhase.Play && _currentSeat == loserSeat &&
                          LostLastHandCard(batch, loserSeat)
                        // 抗歌 observes its marked gainer even when the batch
                        // has no destination owned by the observing skill holder.
                        : trigger.Effects.Any(effect => effect.Op == SkillProgramEffectOp.KanggeGainDraw)
                            ? context.TargetSeat is { } gainerSeat && IsValidPlayerSeat(gainerSeat) &&
                              gainerSeat != owner.Seat && _players[gainerSeat].IsAlive &&
                              gainerSeat != _currentSeat && IsKanggeMarkedSeat(gainerSeat, owner.Seat)
                            : ProgramMovementSourceCounts(batch, context.Window)
                                .Any(item => item.Count.Location.OwnerSeat == owner.Seat &&
                                    (!item.DiscardOriginOnly || trigger.MovementDiscardOnly))),
            SkillProgramTriggerWindow.FirstGameDomainCrossing =>
                context.MovementBatch is { } domainBatch && domainBatch.Id == context.ParentFrameId &&
                _resolutionStack.OfType<CardsMovedTriggerWindowFrame>().LastOrDefault()?.Id == domainBatch.Id &&
                FirstDomainFact(context) is not null,
            SkillProgramTriggerWindow.DiscardPileReceived =>
                context.MovementBatch is { } batch &&
                batch.Id == context.ParentFrameId &&
                _resolutionStack.OfType<CardsMovedTriggerWindowFrame>().LastOrDefault()?.Id == batch.Id &&
                MatchingDiscardPileIndexes(batch, candidate, trigger).Length > 0,
            SkillProgramTriggerWindow.OwnerDied =>
                !owner.IsAlive &&
                _resolutionStack.OfType<DeathFrame>().LastOrDefault() is { } death &&
                death.VictimSeat == owner.Seat &&
                death.KillerSeat == context.SourceSeat &&
                _resolutionStack.OfType<ProgramDeathTriggerWindowFrame>().LastOrDefault() is { } deathWindow &&
                deathWindow.Id == context.ParentFrameId &&
                deathWindow.DeathFrameId == death.Id &&
                deathWindow.OwnerSeat == owner.Seat &&
                deathWindow.Candidates[deathWindow.CandidateIndex] == candidate,
            SkillProgramTriggerWindow.CharacterDied =>
                owner.IsAlive &&
                _resolutionStack.OfType<DeathFrame>().LastOrDefault() is { } death &&
                death.KillerSeat == context.SourceSeat &&
                death.VictimSeat == context.TargetSeat &&
                _resolutionStack.OfType<ProgramKillTriggerWindowFrame>().LastOrDefault() is { } killWindow &&
                killWindow.Id == context.ParentFrameId &&
                killWindow.DeathFrameId == death.Id &&
                killWindow.CandidateIndex < killWindow.Candidates.Count &&
                killWindow.Candidates[killWindow.CandidateIndex] == candidate &&
                killWindow.Contexts[killWindow.CandidateIndex] == context,
            SkillProgramTriggerWindow.JudgmentFinalized =>
                context.Judgment is { } finalized &&
                ActiveJudgment is { } pendingJudgment &&
                finalized.JudgmentFrameId == pendingJudgment.Id &&
                _resolutionStack.LastOrDefault() is ProgramJudgmentTriggerWindowFrame judgmentWindow &&
                judgmentWindow.Id == context.ParentFrameId &&
                judgmentWindow.CandidateIndex < judgmentWindow.Candidates.Count &&
                judgmentWindow.Candidates[judgmentWindow.CandidateIndex] ==
                    new ProgramJudgmentTriggerCandidate(candidate.OwnerSeat, candidate.SkillId,
                        candidate.BindingId, candidate.SkillInstanceId, candidate.GameplayHash) &&
                CanRunProgramJudgmentTrigger(judgmentWindow.Candidates[judgmentWindow.CandidateIndex],
                    trigger, finalized),
            SkillProgramTriggerWindow.JudgmentReplacing =>
                context.JudgmentReplacement is { } replacement &&
                ActiveJudgment is { } currentJudgment &&
                currentJudgment.Id == context.ParentFrameId &&
                replacement.JudgmentFrameId == currentJudgment.Id &&
                CurrentJudgmentCandidate(currentJudgment) is { } replacementCandidate &&
                replacementCandidate.OwnerSeat == candidate.OwnerSeat &&
                replacementCandidate.ProgramId == candidate.SkillId &&
                replacementCandidate.ProgramTriggerId == candidate.BindingId &&
                replacementCandidate.SkillInstanceId == candidate.SkillInstanceId &&
                GetJudgmentCard(currentJudgment)?.Id == replacement.OldCardId &&
                _resolutionStack.LastOrDefault() is JudgmentFrame replacementFrame &&
                replacementFrame.Id == currentJudgment.Id,
            SkillProgramTriggerWindow.CardUseCommitted or
                SkillProgramTriggerWindow.CardUseBeforeTargetEffects or
                SkillProgramTriggerWindow.CardUseTargetsFinalized or
                SkillProgramTriggerWindow.CardResponseAccepted or
                SkillProgramTriggerWindow.CardResponseCompleted or SkillProgramTriggerWindow.CardSupplyCompleted or
                SkillProgramTriggerWindow.CardUseCompleted =>
                context.CardUse is { } cardUse &&
                _resolutionStack.OfType<ProgramCardTriggerWindowFrame>().LastOrDefault() is { } cardFrame &&
                cardFrame.Id == context.ParentFrameId && cardFrame.Action.ActionId == cardUse.CardActionId &&
                cardFrame.Candidates.Any(item => item.OwnerSeat == candidate.OwnerSeat &&
                    item.SkillId == candidate.SkillId && item.SkillInstanceId == candidate.SkillInstanceId &&
                    item.TriggerId == candidate.BindingId && item.GameplayHash == candidate.GameplayHash),
            SkillProgramTriggerWindow.SlashTargetRedirecting or
                SkillProgramTriggerWindow.SlashBeforeResponse or
                SkillProgramTriggerWindow.SlashFullyDodged =>
                context.CardUse is { } slashUse &&
                _resolutionStack.OfType<ProgramCardTriggerWindowFrame>().LastOrDefault() is { } slashFrame &&
                slashFrame.Id == context.ParentFrameId && slashFrame.Action.ActionId == slashUse.CardActionId &&
                ActiveCardAttack is { } pendingSlash && pendingSlash.TargetSeat == context.TargetSeat &&
                slashFrame.Candidates.Any(item => item.OwnerSeat == candidate.OwnerSeat &&
                    item.SkillId == candidate.SkillId && item.SkillInstanceId == candidate.SkillInstanceId &&
                    item.TriggerId == candidate.BindingId && item.GameplayHash == candidate.GameplayHash),
            SkillProgramTriggerWindow.DiscardPhaseStarting =>
                context.SourceSeat == _currentSeat && _phase == TurnPhase.Discard &&
                (trigger.TurnOwnerScope == SkillProgramTurnOwnerScope.Own
                    ? owner.Seat == _currentSeat
                    : owner.Seat != _currentSeat && _players[_currentSeat].IsAlive),
            SkillProgramTriggerWindow.DiscardPhaseEnded =>
                (trigger.AllowOwnDiscardPhaseEnded ? owner.Seat == _currentSeat : owner.Seat != _currentSeat) && owner.IsAlive &&
                context.SourceSeat == _currentSeat && _phase == TurnPhase.Discard,
            _ => false
        };
    }

    private bool CanRunDrawPhaseProgramTrigger(CharacterState owner, SkillProgramTrigger trigger)
    {
        foreach (var effect in trigger.Effects.Where(effect =>
                     effect.Op is (SkillProgramEffectOp.SelectTargets or SkillProgramEffectOp.SelectTarget) &&
                     effect.Condition.Evaluate(CreateSkillContext(owner))))
        {
            if (effect.Op == SkillProgramEffectOp.SelectTargets &&
                (effect.TargetKind is not { } targetKind ||
                 GetProgramTargetSeats(owner.Seat, targetKind, marker: effect.Marker).Count < effect.MinimumTargets ||
                 effect.NumberExpression == SkillProgramNumberExpression.PlannedNormalDrawCount &&
                 (_resolutionStack.LastOrDefault() is not ProgramLifecycleTriggerWindowFrame drawPlan ||
                  drawPlan.NormalDrawReplaced ||
                  Math.Max(0, checked((drawPlan.FrozenBaseDrawCount ?? GetTurnDrawCount(owner)) +
                      drawPlan.NormalDrawAdjustment)) <
                  effect.MinimumTargets)))
                return false;
            if (effect.Op == SkillProgramEffectOp.SelectTarget && effect.TargetKind is { } singleKind &&
                !GetProgramTargetSeats(owner.Seat, singleKind, marker: effect.Marker).Any(seat =>
                    effect.Zones.Count == 0 || effect.Zones.Any(zone => zone switch
                    {
                        CardZoneKind.Hand => GetHand(_players[seat]).Count > 0,
                        CardZoneKind.Equipment => GetEquipment(_players[seat]).Count > 0,
                        CardZoneKind.Judgment => GetJudgment(_players[seat]).Count > 0,
                        _ => false
                    })))
                return false;
        }
        return true;
    }

    private bool CanRunAfterDamageProgramTrigger(
        CharacterState owner,
        SkillProgramTrigger trigger,
        ProgramSkillWindowContext context)
    {
        if (ActiveDamageTrigger is not { } damage ||
            damage.Id != context.ParentFrameId ||
            damage.ParentFrameId != context.DamageFrameId ||
            damage.TriggerWindow != context.Window)
            return false;
        if (trigger.RequireDamageSource == true &&
            (context.SourceSeat is not { } presentSourceSeat || !IsValidPlayerSeat(presentSourceSeat) ||
             GetDamageTriggerAttack(damage).IsSourceLess || GetDamageTriggerAttack(damage).IsDelayedJudgmentDamage))
            return false;
        if (trigger.DamageCardKinds.Count > 0 &&
            (GetDamageTriggerAttack(damage).EffectiveCardKind is not { } kind || !trigger.DamageCardKinds.Contains(kind)))
            return false;
        var features = ProgramInstructionResolver.Default.Features(trigger);
        if (features.HasOperation(SkillProgramEffectOp.StartPindian) &&
            (context.TargetSeat is not { } opponentSeat ||
             !IsValidPlayerSeat(opponentSeat) || !owner.IsAlive || !_players[opponentSeat].IsAlive ||
             !features.Legality.CanStart(new(owner.Seat, GetHand(owner).Count)) ||
             !features.Legality.CanSelectTarget(new(owner.Seat, GetHand(owner).Count),
                 CreateProgramLegalityParticipant(opponentSeat))))
            return false;
        foreach (var effect in features.AfterDamagePrerequisites.Where(effect =>
                     effect.Condition.Evaluate(CreateSkillContext(owner))))
        {
            switch (effect.Op)
            {
                case SkillProgramEffectOp.SelectTarget:
                    if (effect.TargetKind is not { } targetKind ||
                        GetProgramTargetSeats(owner.Seat, targetKind, context, effect.Marker).Count == 0)
                        return false;
                    break;
                case SkillProgramEffectOp.SelectSourceCard:
                    if (effect.SkipIfNoCards) break;
                    var sourceSeat = effect.CardSource switch
                    {
                        SkillProgramCardSource.Owner => owner.Seat,
                        SkillProgramCardSource.DamageSource => context.SourceSeat,
                        SkillProgramCardSource.EventTarget => context.TargetSeat,
                        _ => null
                    };
                    if (sourceSeat is not { } resolvedSourceSeat ||
                        (effect.CardSource == SkillProgramCardSource.DamageSource && resolvedSourceSeat == owner.Seat &&
                         !effect.AllowSameSource) ||
                        !IsValidPlayerSeat(resolvedSourceSeat) ||
                        !effect.Zones.Any(zone => zone switch
                        {
                            CardZoneKind.Hand => GetHand(_players[resolvedSourceSeat]).Count > 0,
                            CardZoneKind.Equipment => GetEquipment(_players[resolvedSourceSeat]).Any(card =>
                                effect.EquipmentSlots.Count == 0 ||
                                effect.EquipmentSlots.Contains(EquipmentCatalog.Get(card.Kind).Slot)),
                            _ => false
                        }))
                        return false;
                    break;
                case SkillProgramEffectOp.ClaimDamageCards:
                    if (!GetDamageTriggerAttack(damage).PhysicalCards.Any(card =>
                            _cardZones.GetLocation(card.Id) == CardLocation.Processing))
                        return false;
                    break;
            }
        }
        return true;
    }

    private void ConsumeProgramTriggerUsage(ProgramTriggerCandidate candidate)
    {
        var trigger = _contentRegistry!.GetSkill(candidate.SkillId).Program!.Triggers
            .Single(item => item.Id == candidate.BindingId);
        if (trigger.UsageScope is not { } scope || ProgramTriggerUsageLimit(trigger) is not { } limit) return;
        if (!_skillRuntimeState.TryConsumeUsage(
                candidate.OwnerSeat, candidate.SkillId, ProgramTriggerUsageId(candidate), scope, limit))
            throw new InvalidOperationException("The configured trigger usage was already consumed.");
        AdvanceEventRulesAndQueueFact(new SkillUsageConsumedEvent(
            candidate.OwnerSeat, candidate.SkillId, candidate.BindingId, scope, 1));
    }

    private string ProgramTriggerUsageId(ProgramTriggerCandidate candidate)
    {
        var trigger = GetProgramTrigger(candidate);
        if (trigger.NamedUsageGroup is { } named) return $"named-group:{named}";
        if (trigger.DynamicUsageLimit is not null) return $"named-binding:{candidate.BindingId}";
        var usageBinding = trigger.ChoiceGroup is { } choiceGroup
            ? $"choice-group:{choiceGroup}"
            : candidate.BindingId;
        return $"{usageBinding}@{candidate.SkillInstanceId}";
    }

    private SkillProgramTriggerFacts CaptureProgramTriggerFacts(CharacterState owner)
    {
        var turnDeaths = _contentRegistry.ProgramDependencies.UsesActualTurnDeathBenefits
            ? ActualTurnDeathCounts(owner.Seat) : ((int Deaths, int Kills)?)null;
        var states = new Dictionary<string, bool>(StringComparer.Ordinal);
        foreach (var instance in GetSkillBindingShard(owner).ProgramInstances)
            foreach (var definition in instance.Program.BooleanStates)
            {
                states[SkillProgramTriggerFacts.BooleanStateKey(
                    instance.SkillId, instance.SkillInstanceId, definition.Id)] =
                    GetProgramBooleanState(owner.Seat, instance.SkillId, instance.SkillInstanceId, definition.Id);
            }
        return new(
            CountCardsUsedByCurrentPlayerThisTurn(owner.Seat),
            owner.Hp,
            IsClassicIdentityMode,
            CardsUsedOrRespondedThisTurn: CountCardsUsedOrRespondedByPlayerThisTurn(owner.Seat),
            OwnerIsTurnPlayer: owner.Seat == _currentSeat,
            TurnOwnerFactionId: _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.TurnOwnerFactionIs)
                ? GetEffectiveFactionId(_players[_currentSeat]) : null,
            TurnOwnerDamageDealtThisTurn: _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.TurnOwnerDamageDealtThisTurn)
                ? EventsSinceLastBoundary(item => item is TurnStartedEvent).OfType<DamageAppliedEvent>()
                    .Where(item => !item.SourceLess && item.SourceSeat == _currentSeat && item.Amount > 0).Sum(item => item.Amount) : null,
            TurnOwnerSlashUseCount: _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.TurnOwnerSlashUseCount)
                ? EventsSinceLastBoundary(item => item is TurnStartedEvent).OfType<CardUsedEvent>()
                    .Count(item => item.SourceSeat == _currentSeat &&
                        item.CardKind is CardKind.Slash or CardKind.FireSlash or CardKind.ThunderSlash) : null,
            CurrentAttackRange: GetAttackRange(owner.Seat),
            CurrentMaxHp: owner.MaxHp,
            CurrentAvailableEquipmentSlotCount: UsesStrategicTriggerValue(SkillProgramTriggerValueKind.CurrentAvailableEquipmentSlotCount) ? Enum.GetValues<EquipmentSlot>().Count(slot => owner.EquipmentSlotCapacity(slot) > 0) : null,
            CurrentHandCount: GetHand(owner).Count,
            TurnDiscardSuitMask: TracksTurnDiscardSuits ? CurrentTurnDiscardSuitMask : null,
            LivingPlayersMinHp: GetLivingPlayersMinHp(),
            TurnOwnerDiscardPhaseHandDiscardCount: TurnOwnerDiscardPhaseHandDiscardCount,
            DiscardPhaseSuitsAllDistinct: owner.Seat == _currentSeat && FullDiscardPhaseSuitsAllDistinct,
            LordGeneralId: _players.SingleOrDefault(player => player.Role == Role.Lord)?.General.Id,
            OwnedZoneCounts: new SkillProgramOwnedZoneCounts(
                _cardZones.Count(CardLocation.WoodenOxGrain(owner.Seat)),
                _cardZones.Count(CardLocation.BuquWound(owner.Seat)),
                _cardZones.Count(CardLocation.Authority(owner.Seat)),
                _cardZones.Count(CardLocation.Chunlao(owner.Seat)),
                _cardZones.Count(new CardLocation(CardZoneKind.PublicPersistentPile, owner.Seat))),
            BooleanStates: states,
            PublicPersistentPileCounts: CapturePublicPileProgramCounts(owner),
            PlayPhaseKillCountByTurnOwner: _playPhaseKillCountByCurrentPlayer,
            PlayPhaseDamageDealtByTurnOwner: _playPhaseDamageDealtByCurrentPlayer,
            MarkerCounts: owner.Markers.Count > 0
                ? new Dictionary<PlayerMarkerKind, int>(owner.Markers)
                : null,
            OwnerIsFaceDown: owner.IsFaceDown,
            UnfulfilledPhaseColorRestrictionInstances: UnfulfilledPlayPhaseColorRestrictions(owner.Seat),
            OwnerKilledThisTurn: _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.OwnerKilledThisTurn)
                ? EventsSinceLastBoundary(item => item is TurnStartedEvent).OfType<PlayerDiedEvent>()
                    .Any(item => item.KillerSeat == owner.Seat) : null,
            LivingWoundedCount: UsesStrategicTriggerValue(SkillProgramTriggerValueKind.LivingWoundedCount)
                ? _players.Count(player => player.IsAlive && player.Hp < player.MaxHp) : 0,
            PlayPhaseDamageTakenByAny: UsesStrategicTriggerValue(SkillProgramTriggerValueKind.PlayPhaseDamageTakenByAny)
                ? CountPlayPhaseDamageTakenByAny() : 0,
            LowHandPopulationSeats: _contentRegistry.ProgramDependencies.HasTriggerOperation(SkillProgramEffectOp.DrawAndDraftLowHandPopulation)
                ? _players.Where(player => player.IsAlive && GetHand(player).Count < player.Hp).Select(player => player.Seat).ToArray() : null,
            GlobalMarkerCounts: UsesStrategicTriggerValue(SkillProgramTriggerValueKind.GlobalMarkerCount)
                ? Enum.GetValues<PlayerMarkerKind>().Where(marker => marker is PlayerMarkerKind.Camp or PlayerMarkerKind.Junlue).ToDictionary(marker => marker,
                    marker => _players.Where(player => player.IsAlive).Sum(player => player.Markers.GetValueOrDefault(marker))) : null)
        { TurnOwnerHp = _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.TurnOwnerHp)
              ? _players[_currentSeat].Hp : null,
          RoundTurnSeatCount = _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.RoundTurnSeatCount)
              ? _roundTurnSeats.Count : null,
          ActualTurnDeathCount = turnDeaths?.Deaths,
          OwnerActualTurnKillCount = turnDeaths?.Kills,
          LivingPlayerCount = _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.LivingPlayerCount)
              ? _players.Count(player => player.IsAlive) : null,
          OwnerTrickUsesThisActualTurn = TracksActualTurnTrickUses ? ActualTurnTrickUseCount(owner.Seat) : null,
          PhaseIsPlay = _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.PhaseIsPlay)
              ? _phase == TurnPhase.Play : null,
          FengjiRoundChoicePending = _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.FengjiRoundChoicePending)
              ? IsFengjiRoundChoicePending(owner.Seat) : null,
          FengjiSwapAvailable = _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.FengjiSwapAvailable)
              ? IsFengjiSwapAvailable(owner.Seat) : null,
          CurrentTurnUsedCardCategoryCount = TracksCurrentTurnUseKinds ? CurrentTurnUseKinds(owner.Seat).Categories : null,
          CurrentActualPlayPhysicalSlashLossCount = TracksActualPlaySlashLoss ? CurrentActualPlaySlashLossCount(owner.Seat) : null,
          TurnOwnerUsedSameSuitCards = _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.TurnOwnerUsedSameSuitCards)
              ? CurrentTurnOwnerUsedSameSuitCards() : null,
          CurrentTurnNonConvertedUseCount = _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.CurrentTurnNonConvertedUseCount)
              ? CountNonConvertedActualUsesThisTurn(owner.Seat) : null };
    }

    private SkillProgramTriggerFacts CaptureProgramTriggerFacts(CharacterState owner, CardActionContext action) =>
        CaptureProgramTriggerFacts(owner) with
        {
            ActualTurnActorUseOrdinal = TracksActualTurnUseOrdinal ? CapturedActualTurnActorUseOrdinal(action) : null,
            CardActionActorIsCurrentTurn = action.ActorSeat == _currentSeat,
            CardActionActorIsOwner = action.ActorSeat == owner.Seat,
            CardActionOpponentIsOwner = _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.CardActionOpponentIsOwner)
                ? action.OpponentSeat == owner.Seat : null,
            CardActionPhaseIsPlay = _phase == TurnPhase.Play,
            CardActionSuit = _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.CardActionSuitIs)
                ? action.EffectiveSuit : null,
            CardActionHandCardCount = _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.CardActionHandCardCount)
                ? action.PhysicalCards.Count(cost => cost.From == CardLocation.Hand(owner.Seat)) : null,
            CardActionPhysicalCardCount = _contentRegistry.ProgramDependencies.UsesTriggerValue(SkillProgramTriggerValueKind.CardActionPhysicalCardCount)
                ? action.PhysicalCards.Count : null,
            CardActionCategory = GetProgramCardCategory(action.EffectiveKind),
            CardActionMatchesPreviousPlayCard = TracksPlayCardHistory ? MatchesPreviousPlayCard(action) : null,
            PreviousPlayCardIsBasic = TracksPlayCardHistory ? PreviousPlayCardIsBasic(action) : null,
            CardActionFromOwnerHand = action.PhysicalCards.Count > 0 &&
                action.PhysicalCards.All(cost =>
                    cost.From is { Zone: CardZoneKind.Hand, OwnerSeat: { } holder } &&
                    holder == action.ActorSeat),
            CardActionCardIsBlack = _contentRegistry.ProgramDependencies.UsesTriggerCondition(SkillProgramTriggerConditionKind.CardActionCardIsBlack)
                ? action.EffectiveSuit is { } blackSuit
                    ? blackSuit is Suit.Spade or Suit.Club
                    : action.PhysicalCards.Count > 0 && action.PhysicalCards.All(cost =>
                        _cardZones.CardsAt(_cardZones.GetLocation(cost.CardId)).Single(card => card.Id == cost.CardId).Suit is Suit.Spade or Suit.Club)
                : null,
            CardActionCardIsRed = action.EffectiveSuit is { } frozenSuit
                ? IsRedSuit(frozenSuit)
                : action.PhysicalCards.Count > 0 &&
                action.PhysicalCards.All(cost =>
                    _cardZones.CardsAt(_cardZones.GetLocation(cost.CardId))
                        .Single(card => card.Id == cost.CardId).Suit is Suit.Heart or Suit.Diamond),
            CardUseDesignatedTargetCount = action.Type == CardActionType.Use
                ? action.EffectiveDesignatedTargetSeats.Distinct().Count()
                : 0,
            CardUseConversionSkillIds = Array.AsReadOnly(action.ConversionChain
                .Select(source => source.SkillId).Distinct(StringComparer.Ordinal).ToArray())
        };

    private void BeginProgramBinding(
        ProgramTriggerCandidate candidate,
        ProgramSkillWindowContext context)
    {
        if (!CanRunProgramTrigger(candidate, context))
            throw new InvalidOperationException("The configured program binding is no longer eligible.");
        ConsumeEarnedActualEndingAtBegin(candidate, context);
        ConsumePrepDiscardEndingAtBegin(candidate, context);
        ConsumeFixedDistanceDebtAtBegin(candidate, context);
        if (!GetProgramTrigger(candidate).Effects.Any(e => e.Op == SkillProgramEffectOp.DiscardSameCategoryForExtraEffect))
            ConsumeProgramTriggerUsage(candidate);
        PayProgramMarkerCost(_players[candidate.OwnerSeat], GetProgramTrigger(candidate).MarkerCost,
            candidate.SkillId, candidate.BindingId);
        ClearPendingDecision();
        if (_resolutionStack.LastOrDefault() is ProgramCardTriggerWindowFrame cardAction &&
            cardAction.Id == context.ParentFrameId)
            ReplaceRuntimeTop(cardAction with { Activated = true });
        var frame = new ProgramSkillFrame(
            ++_resolutionSequence,
            candidate.OwnerSeat,
            candidate.SkillId,
            candidate.BindingId,
            candidate.GameplayHash,
            0,
            [],
            [])
        {
            SkillInstanceId = candidate.SkillInstanceId,
            TriggerId = candidate.BindingId,
            WindowContext = context,
            DyingAlcoholPermission = CaptureProgramDyingAlcoholPermission(candidate, context)
        };
        frame = CaptureHpConditionalProgramSource(frame);
        AttachAfterTurnEndedChild(frame, candidate, context);
        PushRuntimeFrame(frame);
        AdvanceEventRulesAndQueueFact(new ProgramBindingStartedEvent(
            frame.Id, frame.SkillId, candidate.BindingId, frame.SkillInstanceId,
            frame.OwnerSeat, context.Window));
        AddLog("SkillTriggered",
            $"{_players[frame.OwnerSeat].Name} 发动【{_contentRegistry!.GetSkill(frame.SkillId).Name}】。",
            frame.OwnerSeat);
        AdvanceRuntimeProgram(frame.Id);
    }

    private void ExposeProgramTriggerDecision(
        ProgramTriggerCandidate candidate,
        ProgramSkillWindowContext context)
    {
        RecordPublicPileColorOffer(candidate,context);
        var skill = _contentRegistry!.GetSkill(candidate.SkillId);
        var facts = context.Facts;
        var prompt = context.Window == SkillProgramTriggerWindow.PlayEnding &&
            context.SourceSeat == candidate.OwnerSeat && facts is not null
            ? $"出牌阶段结束：本回合已使用 {facts.CardsUsedThisTurn} 张牌，当前体力为 {facts.CurrentHp}。是否发动【{skill.Name}】？"
            : GetProgramTrigger(candidate).Effects is [{ Op: SkillProgramEffectOp.OfferRiceAfterDamagePoint }]
                ? $"是否获得 {_players[candidate.OwnerSeat].Name} 的一张米？"
            : context.OptionalChooserSeat is not null ? $"是否令 {_players[candidate.OwnerSeat].Name} 发动【{skill.Name}】摸一张牌？" : $"是否发动【{skill.Name}】？";
        Dictionary<string, string> Parameters(string action)
        {
            var parameters = new Dictionary<string, string>
            {
                ["program-action"] = action,
                ["skill-id"] = candidate.SkillId,
                ["binding-id"] = candidate.BindingId,
                ["skill-instance-id"] = candidate.SkillInstanceId
            };
            if (facts is not null)
            {
                parameters["cards-used-this-turn"] = facts.CardsUsedThisTurn.ToString(
                    System.Globalization.CultureInfo.InvariantCulture);
                parameters["current-hp"] = facts.CurrentHp.ToString(
                    System.Globalization.CultureInfo.InvariantCulture);
                parameters["classic-identity-mode"] = facts.IsClassicIdentityMode ? "true" : "false";
            }
            return parameters;
        }
        _pendingDecision = new PendingDecision(
            DecisionKind.ProgramTrigger,
            context.OptionalChooserSeat ?? candidate.OwnerSeat,
            prompt,
            [],
            [],
            context.OptionalChooserSeat is not null ? candidate.OwnerSeat : context.SourceSeat)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            TargetSeat = context.OptionalChooserSeat ?? context.TargetSeat ?? candidate.OwnerSeat,
            SkillPrompt = new SkillPromptPresentation(
                candidate.SkillId,
                skill.Name,
                $"{skill.Name} · 是否发动",
                skill.Description),
            Choices =
            [
                new PromptChoice(
                    new ChoiceId($"program-trigger.activate.{candidate.SkillId}.{candidate.BindingId}.{candidate.SkillInstanceId}"),
                    _contentRegistry!.Skills[candidate.SkillId].ProgramPresentation?.TriggerLabels
                        .GetValueOrDefault(GetProgramTrigger(candidate).Id) is { } activateLabel
                        ? activateLabel : $"发动【{skill.Name}】。",
                    [], [],
                    Parameters("activate")),
                new PromptChoice(
                    new ChoiceId($"program-trigger.skip.{candidate.SkillId}.{candidate.BindingId}.{candidate.SkillInstanceId}"),
                    $"不发动【{skill.Name}】。",
                    [], [],
                    Parameters("skip"))
            ]
        };
        _status = _players[context.OptionalChooserSeat ?? candidate.OwnerSeat].IsHuman
            ? EngineStatus.AwaitingHumanResponse
            : EngineStatus.Running;
    }

    // Empty match-local slots need no frozen facts. Issued continuations retain
    // their authority even if the original skill instance has since disappeared.
    private bool HasLivingProgramTriggerBindings(SkillProgramTriggerWindow window) =>
        _players.Any(player => player.IsAlive &&
            (GetSkillBindingShard(player).GetInstanceTriggers(window).Count != 0 ||
             window == SkillProgramTriggerWindow.PlayEnding && IssuedPhaseHandDebtCandidates(player, window, 0).Any()));

    private bool TryBeginTurnStartProgramWindow(CharacterState owner)
    {
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.TurnStartBeforeNormalFlow)) return false;
        var facts = CaptureProgramTriggerFacts(owner);
        var candidates = TracksForeignTurnStartPrograms
            ? CollectForeignTurnStartCandidates(owner, facts)
            : CollectEligibleProgramTriggerCandidates(owner, SkillProgramTriggerWindow.TurnStartBeforeNormalFlow, facts);
        if (candidates.Count == 0) return false;
        if (_resolutionStack.Count != 0)
            throw new InvalidOperationException("Turn-start program bindings require a clean boundary.");
        var frame = new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence,
            owner.Seat,
            SkillProgramTriggerWindow.TurnStartBeforeNormalFlow,
            candidates,
            ProgramLifecycleContinuation.NormalTurnStart,
            facts);
        PushRuntimeFrame(frame);
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    // 每轮开始时 boundary: opens once per actual turn, right after the round
    // ledger advanced and before every other turn-start contest or phase work.
    private bool TryBeginRoundStartingProgramWindow(CharacterState turnOwner)
    {
        if (_winner != Winner.None || !turnOwner.IsAlive || turnOwner.Seat != _currentSeat ||
            _roundNumber == 0 || _turnProgression.Kind == ActualTurnKind.Extra ||
            !_contentRegistry!.ProgramDependencies.HasTriggerWindow(SkillProgramTriggerWindow.RoundStarting))
            return false;
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.RoundStarting)) return false;
        if (_resolutionStack.Count != 0 || _pendingDecision is not null)
            throw new InvalidOperationException("A round-starting program window requires a clean turn boundary.");
        var participants = _players.Where(player => player.IsAlive).ToArray();
        var participantFacts = participants.ToDictionary(player => player.Seat, CaptureProgramTriggerFacts);
        var candidates = participants.SelectMany(player =>
                CollectEligibleProgramTriggerCandidates(player, SkillProgramTriggerWindow.RoundStarting,
                    participantFacts[player.Seat]))
            .OrderBy(candidate => (candidate.OwnerSeat - turnOwner.Seat + _players.Count) % _players.Count)
            .ThenByDescending(candidate => candidate.Priority)
            .ThenBy(candidate => candidate.SkillId, StringComparer.Ordinal)
            .ThenBy(candidate => candidate.BindingId, StringComparer.Ordinal).ToArray();
        if (candidates.Length == 0) return false;
        var frame = new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence, turnOwner.Seat, SkillProgramTriggerWindow.RoundStarting,
            candidates, ProgramLifecycleContinuation.RoundProgramsTurnStart, participantFacts[turnOwner.Seat])
        { ParticipantFacts = participantFacts };
        PushRuntimeFrame(frame);
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    // Other-living turn-start programs (追还-style preparation resolutions) join
    // the own-turn boundary only when some registered skill needs them; every
    // existing own-turn content keeps the original single-owner enumeration.
    private bool TracksForeignTurnStartPrograms =>
        _contentRegistry?.ProgramDependencies.HasTriggerOperation(SkillProgramEffectOp.ZhuihuanRetaliate) == true;

    private IReadOnlyList<ProgramTriggerCandidate> CollectForeignTurnStartCandidates(
        CharacterState turnOwner, SkillProgramTriggerFacts turnOwnerFacts)
    {
        var participants = _players.Where(player => player.IsAlive).ToArray();
        var participantFacts = participants.ToDictionary(player => player.Seat, player =>
            player.Seat == turnOwner.Seat ? turnOwnerFacts : CaptureProgramTriggerFacts(player));
        return participants.SelectMany(player =>
                CollectEligibleProgramTriggerCandidates(player, SkillProgramTriggerWindow.TurnStartBeforeNormalFlow,
                    participantFacts[player.Seat])
                    .Where(candidate => GetProgramTrigger(candidate).TurnOwnerScope ==
                        (player.Seat == turnOwner.Seat
                            ? SkillProgramTurnOwnerScope.Own
                            : SkillProgramTurnOwnerScope.OtherLiving)))
            .OrderBy(candidate => (candidate.OwnerSeat - turnOwner.Seat + _players.Count) % _players.Count)
            .ThenByDescending(candidate => candidate.Priority)
            .ThenBy(candidate => candidate.SkillId, StringComparer.Ordinal)
            .ThenBy(candidate => candidate.BindingId, StringComparer.Ordinal)
            .ToArray();
    }

    private bool TryBeginPlayEndingProgramWindow(CharacterState owner)
    {
        if (!owner.IsAlive || owner.Seat != _currentSeat || _phase != TurnPhase.Play ||
            _pendingDecision is not null || _resolutionStack.Count != 0)
            return false;
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.PlayEnding) && _phaseNamePredictions.Count == 0)
            return false;
        var participants = _players.Where(player => player.IsAlive).ToArray();
        var participantFacts = participants.ToDictionary(player => player.Seat, CaptureProgramTriggerFacts);
        var facts = participantFacts[owner.Seat];
        var candidates = participants.SelectMany(player =>
                CollectEligibleProgramTriggerCandidates(player, SkillProgramTriggerWindow.PlayEnding,
                    participantFacts[player.Seat])
                    .Where(candidate => MatchesPlayEndingTurnOwnerScope(
                        GetProgramTrigger(candidate).TurnOwnerScope, player.Seat == owner.Seat))).ToList();
        AppendPhaseNamePredictionCandidates(candidates);
        var orderedCandidates = candidates.OrderBy(candidate => (candidate.OwnerSeat - owner.Seat + _players.Count) % _players.Count)
            .ThenByDescending(candidate => candidate.Priority)
            .ThenBy(candidate => candidate.SkillId, StringComparer.Ordinal)
            .ThenBy(candidate => candidate.BindingId, StringComparer.Ordinal).ToArray();
        if (orderedCandidates.Length == 0) return false;
        var frame = new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence, owner.Seat, SkillProgramTriggerWindow.PlayEnding,
            orderedCandidates, ProgramLifecycleContinuation.CompletePlayPhase, facts)
        { ParticipantFacts = participantFacts, PhaseNamePredictionPhase = TracksPhaseNamePredictions
            ? new(_turnNumber, _currentSeat, _cardUseDebitPhaseInstanceId) : null };
        PushRuntimeFrame(frame);
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    private static bool MatchesPlayEndingTurnOwnerScope(SkillProgramTurnOwnerScope scope, bool ownSeat) => scope switch
    {
        SkillProgramTurnOwnerScope.Own => ownSeat,
        // AnyLiving collects the trigger once for its owner and lets the shared
        // PlayEnding eligibility accept both the own and the foreign phase end.
        SkillProgramTurnOwnerScope.AnyLiving => true,
        _ => !ownSeat,
    };

    private bool TryBeginDrawPhaseProgramWindow(CharacterState owner, bool skipPlayPhaseAfterDraw)
    {
        if (!owner.IsAlive || owner.Seat != _currentSeat || _phase != TurnPhase.Draw ||
            _pendingDecision is not null || _resolutionStack.Count != 0)
            return false;
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.DrawPhaseStarting)) return false;
        var facts = CaptureProgramTriggerFacts(owner);
        if(HasAttributedEventOperations())facts=facts with {EventTargetMarkerCounts=new Dictionary<PlayerMarkerKind,int>(owner.Markers)};
        var candidates = CollectEligibleProgramTriggerCandidates(
            owner, SkillProgramTriggerWindow.DrawPhaseStarting, facts);
        candidates = IncludeAttributedDrawObservers(owner,candidates);
        if (candidates.Count == 0) return false;
        var frame = new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence,
            owner.Seat,
            SkillProgramTriggerWindow.DrawPhaseStarting,
            candidates,
            ProgramLifecycleContinuation.CompleteDrawPhase,
            facts,
            SkipPlayPhaseAfterDraw: skipPlayPhaseAfterDraw);
        PushRuntimeFrame(frame);
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    private bool TryBeginAfterNormalDrawProgramWindow(CharacterState owner)
    {
        if (!owner.IsAlive || owner.Seat != _currentSeat || _phase != TurnPhase.Draw ||
            _pendingDecision is not null || _resolutionStack.Count != 0)
            return false;
        if (GetSkillBindingShard(owner).GetInstanceTriggers(SkillProgramTriggerWindow.AfterNormalDraw).Count == 0)
            return false;
        var facts = CaptureProgramTriggerFacts(owner);
        var candidates = CollectEligibleProgramTriggerCandidates(
            owner, SkillProgramTriggerWindow.AfterNormalDraw, facts);
        if (candidates.Count == 0) return false;
        PushRuntimeFrame(new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence, owner.Seat, SkillProgramTriggerWindow.AfterNormalDraw,
            candidates, ProgramLifecycleContinuation.CompleteAfterNormalDraw, facts));
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    private bool TryBeginDrawPhaseEndedProgramWindow(CharacterState owner, DelayedTurnEffects delayedEffects)
    {
        if (!owner.IsAlive || owner.Seat != _currentSeat || _phase != TurnPhase.Draw ||
            _pendingDecision is not null || _resolutionStack.Count != 0)
            return false;
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.DrawPhaseEnded)) return false;
        var facts = CaptureProgramTriggerFacts(owner);
        var candidates = CollectEligibleProgramTriggerCandidates(
            owner, SkillProgramTriggerWindow.DrawPhaseEnded, facts);
        candidates = IncludeRecipientCategoryGiftObservers(owner, candidates);
        if (candidates.Count == 0) return false;
        PushRuntimeFrame(new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence, owner.Seat, SkillProgramTriggerWindow.DrawPhaseEnded,
            candidates, ProgramLifecycleContinuation.CompleteDrawPhaseEnded, facts) { DrawPhaseEndedDelayedEffects = (int)delayedEffects });
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    private bool TryBeginDiscardPhaseProgramWindow(CharacterState owner)
    {
        if (!owner.IsAlive || owner.Seat != _currentSeat || _phase != TurnPhase.Discard ||
            _pendingDecision is not null || _resolutionStack.Count != 0)
            return false;
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.DiscardPhaseStarting)) return false;
        var participants = _players.Where(player => player.IsAlive).ToArray();
        var participantFacts = participants.ToDictionary(player => player.Seat, CaptureProgramTriggerFacts);
        var facts = participantFacts[owner.Seat];
        var candidates = participants.SelectMany(player =>
                CollectEligibleProgramTriggerCandidates(player, SkillProgramTriggerWindow.DiscardPhaseStarting,
                    participantFacts[player.Seat])
                    .Where(candidate => GetProgramTrigger(candidate).TurnOwnerScope ==
                        (player.Seat == owner.Seat ? SkillProgramTurnOwnerScope.Own : SkillProgramTurnOwnerScope.OtherLiving)))
            .OrderBy(candidate => (candidate.OwnerSeat - owner.Seat + _players.Count) % _players.Count)
            .ThenByDescending(candidate => candidate.Priority)
            .ThenBy(candidate => candidate.SkillId, StringComparer.Ordinal)
            .ThenBy(candidate => candidate.BindingId, StringComparer.Ordinal).ToArray();
        if (candidates.Length == 0) return false;
        PushRuntimeFrame(new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence, owner.Seat, SkillProgramTriggerWindow.DiscardPhaseStarting,
            candidates, ProgramLifecycleContinuation.CompleteDiscardPhase, facts)
        { ParticipantFacts = participantFacts });
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    private bool TryBeginDiscardPhaseEndedProgramWindow(CharacterState phaseOwner)
    {
        if (!phaseOwner.IsAlive || phaseOwner.Seat != _currentSeat || _phase != TurnPhase.Discard ||
            _pendingDecision is not null || _resolutionStack.Count != 0)
            return false;
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.DiscardPhaseEnded)) return false;
        var participants = _players.Where(player => player.IsAlive).ToArray();
        var participantFacts = participants.ToDictionary(player => player.Seat, CaptureProgramTriggerFacts);
        if (HasAttributedEventOperations())
            foreach (var seat in participantFacts.Keys.ToArray())
                participantFacts[seat] = participantFacts[seat] with
                {
                    // A foreign discard-phase end reports the discarder's markers as the event target.
                    EventTargetMarkerCounts = new Dictionary<PlayerMarkerKind, int>(phaseOwner.Markers)
                };
        var candidates = participants.SelectMany(player =>
                CollectEligibleProgramTriggerCandidates(player, SkillProgramTriggerWindow.DiscardPhaseEnded,
                    participantFacts[player.Seat])
                    .Where(candidate => GetProgramTrigger(candidate).TurnOwnerScope ==
                        (player.Seat == phaseOwner.Seat ? SkillProgramTurnOwnerScope.Own :
                            SkillProgramTurnOwnerScope.OtherLiving)))
            .OrderBy(candidate => (candidate.OwnerSeat - phaseOwner.Seat + _players.Count) % _players.Count)
            .ThenByDescending(candidate => candidate.Priority)
            .ThenBy(candidate => candidate.SkillId, StringComparer.Ordinal)
            .ThenBy(candidate => candidate.BindingId, StringComparer.Ordinal).ToArray();
        if (candidates.Length == 0) return false;
        var frame = new ProgramLifecycleTriggerWindowFrame(
            ++_resolutionSequence, phaseOwner.Seat, SkillProgramTriggerWindow.DiscardPhaseEnded,
            candidates, ProgramLifecycleContinuation.EndTurnAfterDiscardPhase,
            participantFacts[phaseOwner.Seat])
        { ParticipantFacts = participantFacts };
        PushRuntimeFrame(frame);
        AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
        return true;
    }

    private bool TryBeginTurnEndingBoundary(CharacterState owner)
    {
        if (!owner.IsAlive || owner.Seat != _currentSeat || _pendingDecision is not null ||
            _resolutionStack.Count != 0)
            return false;

        var facts = CaptureProgramTriggerFacts(owner);
        var items = _players.Where(player => player.IsAlive &&
                GetSkillBindingShard(player).GetInstanceTriggers(SkillProgramTriggerWindow.TurnEnding).Count != 0)
            .SelectMany(player =>
            {
                var playerFacts = player.Seat == owner.Seat ? facts : CaptureProgramTriggerFacts(player);
                if (EnabledUniqueProgramTriggers(player, SkillProgramTriggerWindow.TurnEnding).Any(binding =>
                    ProgramInstructionResolver.Default.Features(binding.Trigger).UsesValue(SkillProgramTriggerValueKind.EventTargetHandCount)))
                    playerFacts = playerFacts with { EventTargetHandCount = GetHand(owner).Count };
                return CollectEligibleProgramTriggerCandidates(
                        player, SkillProgramTriggerWindow.TurnEnding, playerFacts)
                    .Where(candidate => MatchesTurnEndingScope(candidate, owner.Seat))
                    .Select(candidate => new TurnEndingBoundaryItem(
                        TurnEndingBoundaryItemKind.Program,
                        candidate.Priority,
                        $"program:{candidate.SkillId}:{candidate.BindingId}:{candidate.SkillInstanceId}",
                        candidate, GetProgramTrigger(candidate).TurnOwnerScope == SkillProgramTurnOwnerScope.OwnOrPreviousLiving
                            ? playerFacts with { FrozenPreviousLivingSeat = PreviousLivingSeatFor(player.Seat) }
                            : player.Seat == owner.Seat && !ProgramInstructionResolver.Default.Features(GetProgramTrigger(candidate))
                                .HasOperation(SkillProgramEffectOp.OfferCurrentTurnHandExchange) ? null : playerFacts));
            }).ToList();
        AppendEarnedActualEndingItems(items);
        AppendPrepDiscardEndingItems(items);
        AppendGiftRetentionEndingItems(items);
        AppendFixedDistanceOneEndingItems(items);
        var ordered = items
            .OrderBy(item => (((item.Candidate?.OwnerSeat ?? item.RetentionOwnerSeat!.Value) - owner.Seat + _players.Count) % _players.Count))
            .ThenByDescending(item => item.Priority)
            .ThenBy(item => item.StableIdentity, StringComparer.Ordinal)
            .ToArray();
        if (ordered.Length == 0) return false;

        PushRuntimeFrame(new TurnEndingBoundaryFrame(
            ++_resolutionSequence,
            owner.Seat,
            _turnNumber,
            Array.AsReadOnly(ordered),
            facts));
        AdvanceRuntimeTop<TurnEndingBoundaryFrame>();
        return true;
    }

    private ProgramSkillWindowContext CreateTurnEndingProgramContext(
        TurnEndingBoundaryFrame frame,
        ProgramTriggerCandidate candidate,
        SkillProgramTriggerFacts? candidateFacts = null) =>
        new(
            SkillProgramTriggerWindow.TurnEnding,
            frame.Id,
            candidate.OwnerSeat,
            SourceSeat: frame.OwnerSeat,
            TargetSeat: frame.OwnerSeat,
            OccurrenceIndex: candidate.OccurrenceIndex,
            Facts: candidateFacts ?? frame.Facts)
        { EarnedBenefit = frame.Items[frame.ItemIndex].EarnedBenefit, PrepDiscardPromise = frame.Items[frame.ItemIndex].PrepDiscardPromise, FixedDistanceDebt = frame.Items[frame.ItemIndex].FixedDistanceDebt };

    private void ContinueTurnEndingBoundaryCore()
    {
        while (_resolutionStack.LastOrDefault() is TurnEndingBoundaryFrame frame)
        {
            // A child may decide the winner without killing the turn owner (for
            // example, redirected damage). No later observer may start then.
            if (_winner != Winner.None)
            {
                PopResolutionFrame(frame.Id, ResolutionFrameKind.TurnEndingBoundary);
                if (_status != EngineStatus.Completed) CompleteGame();
                else AdvanceRulesAndPublishState();
                return;
            }
            if (frame.ItemIndex >= frame.Items.Count)
            {
                PopResolutionFrame(frame.Id, ResolutionFrameKind.TurnEndingBoundary);
                FinalizeEndTurn(_players[frame.OwnerSeat]);
                return;
            }

            var item = frame.Items[frame.ItemIndex];
            switch (item.Kind)
            {
                case TurnEndingBoundaryItemKind.GiftRetention:
                    if (ConsumeGiftRetentionEndingItem(frame, item)) return;
                    continue;
                case TurnEndingBoundaryItemKind.Program:
                    {
                        var candidate = item.Candidate ??
                            throw new InvalidOperationException("A program turn-ending item lost its candidate.");
                        var context = CreateTurnEndingProgramContext(frame, candidate, item.Facts);
                        if (!CanRunProgramTrigger(candidate, context))
                        {
                            ConsumeSkippedEarnedActualEnding(frame);
                            ConsumeSkippedPrepDiscardEnding(frame);
                            ConsumeSkippedFixedDistanceDebt(frame);
                            AdvanceTurnEndingBoundaryCandidate(frame, candidate, activated: false, completed: false);
                            continue;
                        }
                        var trigger = _contentRegistry!.GetSkill(candidate.SkillId).Program!.Triggers
                            .Single(current => current.Id == candidate.BindingId);
                        if (trigger.Optional)
                        {
                            ReplaceRuntimeTop(frame with { Step = ResolutionFrameStep.AwaitingResponse });
                            ExposeProgramTriggerDecision(candidate, context);
                            return;
                        }
                        BeginProgramBinding(candidate, context);
                        return;
                    }
                default:
                    throw new InvalidOperationException("Unsupported turn-ending boundary item.");
            }
        }
    }

    private void AdvanceTurnEndingBoundaryCandidate(
        TurnEndingBoundaryFrame frame,
        ProgramTriggerCandidate candidate,
        bool activated,
        bool completed)
    {
        AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
            frame.Id, candidate.SkillId, candidate.BindingId, candidate.SkillInstanceId,
            candidate.OwnerSeat, SkillProgramTriggerWindow.TurnEnding, activated, completed));
        AdvanceTurnEndingBoundaryCursor(frame);
    }

    private void AdvanceTurnEndingBoundaryCursor(TurnEndingBoundaryFrame frame)
    {
        if (_resolutionStack.LastOrDefault() is not TurnEndingBoundaryFrame current ||
            current.Id != frame.Id || current.ItemIndex != frame.ItemIndex)
            throw new InvalidOperationException("The turn-ending item cursor is no longer current.");
        ReplaceRuntimeTop(current with
        {
            ItemIndex = current.ItemIndex + 1,
            Step = ResolutionFrameStep.ResolvingEffect
        });
    }

    private bool TryBeginPlayPhaseStartingBoundary(CharacterState owner)
    {
        if (!owner.IsAlive || owner.Seat != _currentSeat || _pendingDecision is not null ||
            _resolutionStack.Count != 0)
            return false;
        if (!HasLivingProgramTriggerBindings(SkillProgramTriggerWindow.PlayPhaseStarting)) return false;

        var facts = CaptureProgramTriggerFacts(owner);
        var items = _players.Where(player => player.IsAlive)
            .SelectMany(player =>
            {
                var playerFacts = player.Seat == owner.Seat ? facts : CaptureProgramTriggerFacts(player);
                return CollectEligibleProgramTriggerCandidates(
                        player, SkillProgramTriggerWindow.PlayPhaseStarting, playerFacts)
                    .Where(candidate => GetProgramTrigger(candidate).TurnOwnerScope ==
                        (player.Seat == owner.Seat ? SkillProgramTurnOwnerScope.Own :
                            SkillProgramTurnOwnerScope.OtherLiving))
                    .Select(candidate => new TurnEndingBoundaryItem(
                        TurnEndingBoundaryItemKind.Program,
                        candidate.Priority,
                        $"program:{candidate.SkillId}:{candidate.BindingId}:{candidate.SkillInstanceId}",
                        candidate, player.Seat == owner.Seat ? null : playerFacts));
            }).ToList();
        var ordered = items
            .OrderBy(item => ((item.Candidate!.OwnerSeat - owner.Seat + _players.Count) % _players.Count))
            .ThenByDescending(item => item.Priority)
            .ThenBy(item => item.StableIdentity, StringComparer.Ordinal)
            .ToArray();
        if (ordered.Length == 0) return false;

        PushRuntimeFrame(new PlayPhaseStartingBoundaryFrame(
            ++_resolutionSequence, owner.Seat, Array.AsReadOnly(ordered), facts));
        AdvanceRuntimeTop<PlayPhaseStartingBoundaryFrame>();
        return true;
    }

    private ProgramSkillWindowContext CreatePlayPhaseStartingProgramContext(
        PlayPhaseStartingBoundaryFrame frame,
        ProgramTriggerCandidate candidate,
        SkillProgramTriggerFacts? candidateFacts = null) =>
        new(
            SkillProgramTriggerWindow.PlayPhaseStarting,
            frame.Id,
            candidate.OwnerSeat,
            SourceSeat: frame.OwnerSeat,
            TargetSeat: frame.OwnerSeat,
            OccurrenceIndex: candidate.OccurrenceIndex,
            Facts: candidateFacts ?? frame.Facts);

    private void ContinuePlayPhaseStartingBoundaryCore()
    {
        while (_resolutionStack.LastOrDefault() is PlayPhaseStartingBoundaryFrame frame)
        {
            if (frame.ItemIndex >= frame.Items.Count)
            {
                PopResolutionFrame(frame.Id, ResolutionFrameKind.PlayPhaseStartingBoundary);
                AdvanceRulesAndPublishState();
                return;
            }

            var item = frame.Items[frame.ItemIndex];
            if (item.Kind != TurnEndingBoundaryItemKind.Program)
                throw new InvalidOperationException("Unsupported play-phase-starting boundary item.");
            var candidate = item.Candidate ??
                throw new InvalidOperationException("A program play-phase-starting item lost its candidate.");
            var context = CreatePlayPhaseStartingProgramContext(frame, candidate, item.Facts);
            if (!CanRunProgramTrigger(candidate, context))
            {
                AdvancePlayPhaseStartingCandidate(frame, candidate, activated: false, completed: false);
                continue;
            }
            var trigger = _contentRegistry!.GetSkill(candidate.SkillId).Program!.Triggers
                .Single(current => current.Id == candidate.BindingId);
            if (trigger.ChoiceGroup is { } choiceGroup)
            {
                var members = GetPlayPhaseStartingChoiceGroup(frame, candidate, choiceGroup);
                if (members.Count > 1 || trigger.Optional)
                {
                    ReplaceRuntimeTop(frame with { Step = ResolutionFrameStep.AwaitingResponse });
                    ExposeProgramTriggerGroupDecision(members, candidate, context, choiceGroup);
                    return;
                }
                BeginProgramBinding(candidate, context);
                return;
            }
            if (trigger.Optional)
            {
                ReplaceRuntimeTop(frame with { Step = ResolutionFrameStep.AwaitingResponse });
                ExposeProgramTriggerDecision(candidate, context);
                return;
            }
            BeginProgramBinding(candidate, context);
            return;
        }
    }

    private void AdvancePlayPhaseStartingCandidate(
        PlayPhaseStartingBoundaryFrame frame,
        ProgramTriggerCandidate candidate,
        bool activated,
        bool completed)
    {
        AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
            frame.Id, candidate.SkillId, candidate.BindingId, candidate.SkillInstanceId,
            candidate.OwnerSeat, SkillProgramTriggerWindow.PlayPhaseStarting, activated, completed));
        AdvancePlayPhaseStartingCursor(frame);
    }

    private void AdvancePlayPhaseStartingCursor(PlayPhaseStartingBoundaryFrame frame)
    {
        if (_resolutionStack.LastOrDefault() is not PlayPhaseStartingBoundaryFrame current ||
            current.Id != frame.Id || current.ItemIndex != frame.ItemIndex)
            throw new InvalidOperationException("The play-phase-starting item cursor is no longer current.");
        ReplaceRuntimeTop(current with
        {
            ItemIndex = current.ItemIndex + 1,
            Step = ResolutionFrameStep.ResolvingEffect
        });
    }

    private void ContinueProgramLifecycleWindowCore()
    {
        while (_resolutionStack.LastOrDefault() is ProgramLifecycleTriggerWindowFrame frame)
        {
            if (frame.CandidateIndex >= frame.Candidates.Count)
            {
                PopResolutionFrame(frame.Id, ResolutionFrameKind.ProgramLifecycleTriggerWindow);
                if (frame.ResumeDrawPhaseObligationFrameId is not null)
                { ReturnDrawPhaseObligationWindow(frame); return; }
                switch (frame.Continuation)
                {
                    case ProgramLifecycleContinuation.ResumeAfterDeferredPrivateOffers:
                        ContinueTurnAfterForeignActualContests(_players[frame.OwnerSeat]);
                        break;
                    case ProgramLifecycleContinuation.ResumeDyingEntry:
                        CompleteDyingEntryProgramWindow(frame);
                        break;
                    case ProgramLifecycleContinuation.ResumeCardDeclaration:
                        if (_resolutionStack.LastOrDefault() is not CardDeclarationFrame declaration || declaration.Id != frame.ResumeProgramFrameId || declaration.Stage != CardDeclarationStage.Granting)
                            throw new InvalidOperationException("A declaration grant lost its exact parent.");
                        AdvanceRuntimeFrame(declaration.Id); break;
                    case ProgramLifecycleContinuation.ResumeParentProgram:
                        AdvanceRuntimeProgram(frame.ResumeProgramFrameId!.Value);
                        break;
                    case ProgramLifecycleContinuation.CompleteGameStarting:
                        break;
                    case ProgramLifecycleContinuation.NormalTurnStart:
                        BeginNormalTurnStartAfterProgramBindings(_players[frame.OwnerSeat]);
                        break;
                    case ProgramLifecycleContinuation.RoundProgramsTurnStart:
                        ContinueTurnAfterRoundPrograms(_players[frame.OwnerSeat]);
                        break;
                    case ProgramLifecycleContinuation.CompleteDrawPhase:
                        CompleteDrawPhaseAfterProgramWindow(
                            _players[frame.OwnerSeat], frame.SkipPlayPhaseAfterDraw,
                            frame.NormalDrawReplaced, frame.NormalDrawAdjustment,
                            frame.FrozenBaseDrawCount,
                            frame.ActualPhaseSubstitution is { SkippedPhase: SkillProgramTurnPhase.Draw } substitution && substitution.ParentFrameId == frame.Id);
                        break;
                    case ProgramLifecycleContinuation.CompletePlayPhase:
                        CompletePlayPhaseAfterProgramWindow();
                        break;
                    case ProgramLifecycleContinuation.CompletePhaseHandDebtForcedEnd:
                        EndTurn();
                        break;
                    case ProgramLifecycleContinuation.CompleteJudgmentPhaseStarting:
                        CompleteActualJudgmentStarting(frame);
                        break;
                    case ProgramLifecycleContinuation.ResumeCharacterStateChange:
                        ResumeCharacterStateChange(frame);
                        break;
                    case ProgramLifecycleContinuation.CompleteDrawPhaseEnded:
                        CompleteTurnStartAfterDraw(_players[frame.OwnerSeat], (DelayedTurnEffects)(frame.DrawPhaseEndedDelayedEffects ?? throw new InvalidOperationException("Draw end lost its frozen phase continuation.")), drawPhaseEndedProgramsCompleted: true);
                        break;
                    case ProgramLifecycleContinuation.CompleteAfterNormalDraw:
                        CompleteTurnStartAfterDraw(_players[frame.OwnerSeat], _pendingTurnDelayedEffects,
                            afterNormalDrawProgramsCompleted: true, drawPhaseEndedProgramsCompleted: true);
                        break;
                    case ProgramLifecycleContinuation.CompleteDiscardPhase:
                        CompleteDiscardPhaseAfterProgramWindow(_players[frame.OwnerSeat]);
                        break;
                    case ProgramLifecycleContinuation.EndTurnAfterDiscardPhase:
                        EndTurn();
                        break;
                    default:
                        throw new InvalidOperationException("Unsupported lifecycle continuation.");
                }
                return;
            }
            var candidate = frame.Candidates[frame.CandidateIndex];
            var context = new ProgramSkillWindowContext(
                frame.Window, frame.Id, candidate.OwnerSeat,
                SourceSeat: frame.ResumeDyingFrameId is not null ? ActiveDying?.KillerSeat : frame.OwnerSeat,
                TargetSeat: frame.OwnerSeat,
                OccurrenceIndex: candidate.OccurrenceIndex,
                Facts: frame.Window==SkillProgramTriggerWindow.DrawPhaseStarting && HasAttributedEventOperations() ? (frame.ParticipantFacts?.GetValueOrDefault(candidate.OwnerSeat) ?? frame.Facts) with { EventTargetMarkerCounts = new Dictionary<PlayerMarkerKind,int>(_players[frame.OwnerSeat].Markers) } :
                    frame.Window==SkillProgramTriggerWindow.DiscardPhaseEnded && HasAttributedEventOperations() ? (frame.ParticipantFacts?.GetValueOrDefault(candidate.OwnerSeat) ?? frame.Facts) with { EventTargetMarkerCounts = new Dictionary<PlayerMarkerKind,int>(_players[frame.OwnerSeat].Markers) } :
                    frame.ParticipantFacts?.GetValueOrDefault(candidate.OwnerSeat) ?? frame.Facts);
            context = AttachPhaseNamePredictionContext(candidate, context);
            if (frame.ProgramTarget is { } commit) context = context with { SourceSeat = commit.OwnerSeat, TargetSeat = commit.TargetSeat, ProgramTarget = commit };
            if (!CanRunProgramTrigger(candidate, context))
            {
                AdvanceProgramLifecycleCandidate(frame, activated: false, completed: false);
                continue;
            }
            var trigger = _contentRegistry!.GetSkill(candidate.SkillId).Program!.Triggers
                .Single(item => item.Id == candidate.BindingId);
            if (trigger.ChoiceGroup is { } choiceGroup)
            {
                var members = GetProgramTriggerChoiceGroup(frame, candidate, choiceGroup);
                if (members.Count > 1 || trigger.Optional)
                    ExposeProgramTriggerGroupDecision(members, candidate, context, choiceGroup);
                else
                    BeginProgramBinding(candidate, context);
                return;
            }
            if (trigger.Optional)
            {
                ExposeProgramTriggerDecision(candidate, context);
                return;
            }
            BeginProgramBinding(candidate, context);
            return;
        }
    }

    private void AdvanceProgramLifecycleCandidate(
        ProgramLifecycleTriggerWindowFrame frame,
        bool activated,
        bool completed)
    {
        var candidate = frame.Candidates[frame.CandidateIndex];
        AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
            frame.Id, candidate.SkillId, candidate.BindingId, candidate.SkillInstanceId,
            candidate.OwnerSeat, frame.Window, activated, completed));
        AdvanceProgramLifecycleCursor(frame);
    }

    private void AdvanceProgramLifecycleCursor(ProgramLifecycleTriggerWindowFrame frame)
    {
        if (_resolutionStack.LastOrDefault() is not ProgramLifecycleTriggerWindowFrame current ||
            current.Id != frame.Id || current.CandidateIndex != frame.CandidateIndex)
            throw new InvalidOperationException("The lifecycle trigger cursor is no longer current.");
        ReplaceRuntimeTop(current with { CandidateIndex = current.CandidateIndex + 1 });
    }

    private IReadOnlyList<ProgramTriggerCandidate> GetProgramTriggerChoiceGroup(
        ProgramLifecycleTriggerWindowFrame frame,
        ProgramTriggerCandidate first,
        string choiceGroup) =>
        GetTriggerChoiceGroupMembers(
            frame.Candidates.Skip(frame.CandidateIndex), first, choiceGroup);

    private IReadOnlyList<ProgramTriggerCandidate> GetPlayPhaseStartingChoiceGroup(
        PlayPhaseStartingBoundaryFrame frame,
        ProgramTriggerCandidate first,
        string choiceGroup) =>
        GetTriggerChoiceGroupMembers(
            frame.Items.Skip(frame.ItemIndex)
                .Select(item => item.Candidate)
                .Where(candidate => candidate is not null)
                .Select(candidate => candidate!), first, choiceGroup);

    private IReadOnlyList<ProgramTriggerCandidate> GetTriggerChoiceGroupMembers(
        IEnumerable<ProgramTriggerCandidate> candidatesFromCursor,
        ProgramTriggerCandidate first,
        string choiceGroup)
    {
        var members = candidatesFromCursor
            .TakeWhile(candidate =>
                candidate.OwnerSeat == first.OwnerSeat &&
                candidate.SkillId == first.SkillId &&
                candidate.SkillInstanceId == first.SkillInstanceId &&
                candidate.Priority == first.Priority &&
                GetProgramTrigger(candidate).ChoiceGroup == choiceGroup)
            .ToArray();
        if (members.Length == 0)
            throw new InvalidOperationException("A configured program choice group lost every eligible branch.");
        return members;
    }

    private void ExposeProgramTriggerGroupDecision(
        IReadOnlyList<ProgramTriggerCandidate> members,
        ProgramTriggerCandidate first,
        ProgramSkillWindowContext context,
        string choiceGroup)
    {
        var skill = _contentRegistry!.GetSkill(first.SkillId);
        Dictionary<string, string> Parameters(ProgramTriggerCandidate candidate, string action) => new()
        {
            ["program-action"] = action,
            ["skill-id"] = candidate.SkillId,
            ["binding-id"] = candidate.BindingId,
            ["skill-instance-id"] = candidate.SkillInstanceId,
            ["choice-group"] = choiceGroup
        };
        var choices = members.Select(candidate =>
        {
            var trigger = GetProgramTrigger(candidate);
            return new PromptChoice(
                new ChoiceId($"program-trigger.activate.{candidate.SkillId}.{candidate.BindingId}.{candidate.SkillInstanceId}"),
                trigger.ChoiceLabel ?? throw new InvalidOperationException(
                    "A configured program choice branch lost its presentation label."),
                [], [], Parameters(candidate, "activate"));
        }).ToList();
        if (GetProgramTrigger(first).Optional)
            choices.Add(new PromptChoice(
                new ChoiceId($"program-trigger.skip-group.{first.SkillId}.{choiceGroup}.{first.SkillInstanceId}"),
                $"不发动【{skill.Name}】。",
                [], [], Parameters(first, "skip")));
        _pendingDecision = new PendingDecision(
            DecisionKind.ProgramTrigger,
            first.OwnerSeat,
            $"请选择【{skill.Name}】的发动方式。",
            [], [], context.SourceSeat)
        {
            PromptId = CreatePromptId(),
            IsPrivate = true,
            TargetSeat = context.TargetSeat ?? first.OwnerSeat,
            SkillPrompt = new SkillPromptPresentation(
                first.SkillId, skill.Name, $"{skill.Name} · 选择方式", skill.Description),
            Choices = Array.AsReadOnly(choices.ToArray())
        };
        _status = _players[first.OwnerSeat].IsHuman
            ? EngineStatus.AwaitingHumanResponse
            : EngineStatus.Running;
    }

    private void AdjustProgramNormalDraw(ProgramSkillFrame frame, int amount)
    {
        if (_resolutionStack.LastOrDefault() is not ProgramSkillFrame current || current.Id != frame.Id ||
            frame.WindowContext is not
            {
                Window: SkillProgramTriggerWindow.DrawPhaseStarting,
                ParentFrameId: var parentFrameId
            } ||
            frame.TriggerId is null || amount == 0 || _resolutionStack.Count < 2 ||
            _resolutionStack[^2] is not ProgramLifecycleTriggerWindowFrame parent ||
            parent.Id != parentFrameId ||
            parent.Continuation != ProgramLifecycleContinuation.CompleteDrawPhase)
        {
            throw new InvalidOperationException(
                "A normal-draw adjustment requires the active draw-phase program and its parent window.");
        }

        var total = checked(parent.NormalDrawAdjustment + amount);
        ReplaceRuntimeFrame(_resolutionStack[^2].Id, parent with { NormalDrawAdjustment = total });
        AdvanceEventRulesAndQueueFact(new ProgramNormalDrawAdjustedEvent(
            frame.Id,
            frame.SkillId,
            frame.TriggerId,
            frame.OwnerSeat,
            amount,
            total));
    }

    private CommandResult SubmitProgramTriggerAnswer(int actorSeat, PromptId promptId, ChoiceId choiceId)
    {
        var error = ValidateHumanPrompt(actorSeat, DecisionKind.ProgramTrigger, promptId,
            CommandErrorCode.IllegalAction);
        if (error is not null) return Reject(error.Code, error.Message);
        var selected = _pendingDecision!.Choices.SingleOrDefault(choice => choice.Id == choiceId);
        if (selected?.Parameters.GetValueOrDefault("program-action") == "diamond-delayed" && !IsDiamondDelayedChoiceLegal(selected))
            return Reject(CommandErrorCode.InvalidChoice, "The diamond delayed payment or target is no longer legal.");
        if (selected is null) return Reject(CommandErrorCode.InvalidChoice, "The program choice is unavailable.");
        if (selected.Parameters.GetValueOrDefault("program-action") == "phase-hand-debt-return" && !IsPhaseHandDebtChoiceLegal(selected))
            return Reject(CommandErrorCode.InvalidChoice, "The issued phase-hand return is no longer legal.");
        if (selected.Parameters.GetValueOrDefault("program-action") is "alternative-phase-cost-card" or "alternative-phase-cost-marker" && !IsAlternativePhaseCostChoiceLegal(selected))
            return Reject(CommandErrorCode.InvalidChoice, "The alternative phase cost is no longer payable.");
        if (selected.Parameters.GetValueOrDefault("program-action") == "slash-suit-discard" && !IsProgramSlashSuitDiscardChoiceLegal(selected))
            return Reject(CommandErrorCode.InvalidChoice, "The actual HE suit discard is no longer legal.");
        if (selected.Parameters.GetValueOrDefault("program-action") == "choose-option" &&
            !IsClaimableProgramOptionStillAvailable(selected))
            return Reject(CommandErrorCode.InvalidChoice, "The damage cards are no longer available for this choice.");
        return Accept(() =>
        {
            ResolveProgramTriggerChoice(selected);
            AdvanceRulesAndPublishState();
            if (_options.AdvanceAfterHumanCommands) AdvanceToHumanBoundary();
        });
    }

    private void ResolveProgramTriggerChoice(PromptChoice selected)
    {
        if (selected.Parameters.GetValueOrDefault("program-action") == "draw-discard-category")
        { ResolveDrawDiscardCategoryChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "draw-advice-discard")
        { ResolveDrawAdviceChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "designated-extra-target")
        { ResolveDesignatedExtraTargetChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "current-turn-hand-exchange")
        {
            var frame = _resolutionStack.LastOrDefault() as ProgramSkillFrame ??
                throw new InvalidOperationException("The current-turn hand exchange choice lost its owning program.");
            ResolveCurrentTurnHandExchangeChoice(frame, selected);
            return;
        }
        if (selected.Parameters.GetValueOrDefault("program-action") == "gain-after-batch") { ResolveGainGiftChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "actual-hand-gain-category") { ResolveActualHandGainChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "public-pile-preparation") { ResolvePublicPilePreparationChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "phase-hand-debt-return") { ResolvePhaseHandDebtChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "dynamic-discard-damage") { ResolveDynamicDiscardDamageChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") is "alternative-phase-cost-card" or "alternative-phase-cost-marker")
        { ResolveAlternativePhaseCost(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "decline-owned-field-move")
        { ResolveDeclinedOwnedFieldMove(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "hp-damage-shield") { ResolveHpDamageShieldPayment(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") is "damage-target-obtain" or "damage-target-duel") { ResolveDamageTargetObtainChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "damage-target-mount") { ResolveDamageTargetMount(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "hp-loss-quantity") { ResolveHpLossQuantity(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "slash-suit-discard") { ResolveProgramSlashSuitDiscardChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "diamond-delayed") { ResolveDiamondDelayedChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "public-suit-discard") { ResolvePublicSuitDiscard(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") is { } namedAction && (namedAction.StartsWith("named-defense-", StringComparison.Ordinal) || namedAction.StartsWith("public-draft-", StringComparison.Ordinal)))
        { ResolveNamedDefenseAndDraftChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "final-target-gift") { ResolveFinalTargetGiftChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "converting-gift") { ResolveConvertingGiftChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action")?.StartsWith("quota-top-", StringComparison.Ordinal) == true) { ResolveQuotaTopChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "named-turn-flow") { ResolveNamedTurnFlowChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "alternating-suit-top") { ResolveAlternatingSuitTopChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "equipment-pair-payment") { ResolveEquipmentPairPaymentChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "dying-suits") { ResolveDyingSuitsChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "historical-ending") { ResolveHistoricalEndingChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "dying-owned-card") { ResolveDyingOwnedCardChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "sequential-discard") { ResolveSequentialDiscardChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "half-hand-support") { ResolveHalfHandSupportChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "unique-hp-peer") { ResolveUniqueHpPeerChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "recipient-contest") { ResolveRecipientContestChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "black-gift-contest") { ResolveBlackGiftChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "printed-lord-benefit") { ResolvePrintedLordChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "foreign-selected-slash") { ResolveSelectedForeignCardSlashChoice(selected); return; }
        if (selected.Parameters.GetValueOrDefault("program-action") == "kuangfu") { ResolveKuangfuChoice(selected); return; }
        var action = selected.Parameters.GetValueOrDefault("program-action");
        if (action == "relative-zone-target") { ResolveRelativeZoneTarget(selected); return; }
        if (action == "deck-end-exchange") { ResolveDeckEndChoice(selected); return; }
        if (action == "private-general-library") {ResolvePrivateGeneralLibraryChoice(selected);return;}
        if (action == "game-domain") {ResolveGameDomainChoice(selected);return;}
        if (action == "public-pile-color") {ResolvePublicPileColorChoice(selected);return;}
        if (action == "public-pile-flow") { ResolveFinalTargetPileChoice(selected); return; }
        if (action == "public-pile") { ResolvePublicPileChoice(selected); return; }
        if (action == "hand-comparison") { ResolveHandComparison(selected); return; }
        if (action == "participant-discard") { ResolveSelectedParticipantDiscard(selected); return; }
        if (action == "damage-card-offer") { ResolveDamageCardOffer(selected); return; }
        if (action == "faction-recovery") { ResolveFactionRecoveryChoice(selected); return; }
        if (action == "weapon-damage") { ResolveWeaponDamageChoice(selected); return; }
        if (action == "paired-hand-reveal") { ResolvePairedHandRevealChoice(selected); return; }
        if (action == "hand-control") { ResolveProgramHandControlChoice(selected); return; }
        if (action == "equipment-color-discard")
        {
            ResolveProgramEquipmentColorDiscardChoice(selected);
            return;
        }
        if (action == "add-compound-card-target")
        {
            ResolveProgramCompoundCardTarget(selected);
            return;
        }
        if (action == "discard-budget") { ResolveDiscardBudgetChoice(selected); return; }
        if (action == "actual-discard-recovery") { ResolveActualDiscardRecovery(selected); return; }
        if (action == "signed-damage-payment") { ResolveSignedDamagePayment(selected); return; }
        if (action == "suit-prevention-benefit") { ResolveSuitPreventionBenefit(selected); return; }
        if (action == "matched-judgment-placement") { ResolveMatchedJudgmentPlacement(selected); return; }
        if (action == "completed-use-payment") { ResolveCompletedUsePayment(selected); return; }
        if (action == "round-pile-alcohol") { ResolveRoundPileAlcohol(selected); return; }
        if (action == "current-slash-fire") { ResolveCurrentSlashFireChoice(selected); return; }
        if (action == "red-discard-recovery") { ResolveRedDiscardRecoveryChoice(selected); return; }
        if (action == "outside-range-discard") { ResolveOutsideRangeDiscard(selected); return; }
        if (action == "faction-cost-gift") { ResolveCompletedFactionGift(selected); return; }
        if (action == "completed-card-gift")
        {
            ResolveCompletedCardGiftChoice(selected);
            return;
        }
        if (action == "named-card-acquisition") { ResolveNamedCardAcquisitionChoice(selected); return; }
        if (action == "slash-target-penalty") { ResolveTargetPenaltyChoice(selected); return; }
        if (action == "slash-target-benefit") { ResolveSlashTargetBenefitChoice(selected); return; }
        if (action == "prep-discard-ending")
        {
            ResolvePrepDiscardChoice(_resolutionStack.LastOrDefault() as ProgramSkillFrame ??
                throw new InvalidOperationException("The preparation choice lost its owning program."), selected); return;
        }
        if (action == "same-type-actual-use-aid") { ResolveSameTypeAidChoice(selected); return; }
        if (action == "original-target-addition") { ResolveOriginalTargetAdditionChoice(selected); return; }
        if (action == "short-range-slash-target") { ResolveShortRangeSlashTarget(selected); return; }
        if (action is "phase-name-cost" or "phase-name-reveal" or "phase-name-guess") { ResolvePhaseNamePredictionChoice(selected); return; }
        if (action == "friend-trio") { ResolveFriendTrioChoice(selected); return; }
        if (action == "friend-pang-tong") { ResolveFriendPangTongChoice(selected); return; }
        if (action == "last-damage-source-discard") { ResolveLastDamageSourceReciprocityChoice(selected); return; }
        if (action == "matching-recast") { ResolveMatchingRecastChoice(selected); return; }
        if (action == "paired-hand-recast") { ResolvePairedHandRecastChoice(selected); return; }
        if (action == "outside-phase-draw-discard") { ResolveOutsidePhaseDrawDiscardChoice(selected); return; }
        if (action == "original-hand-entity") { ResolveOriginalHandEntityChoice(selected); return; }
        if (action == "turn-default-stat") { ResolveTurnDefaultStatChoice(selected); return; }
        if (action == "paired-color-disposition") { ResolvePairedColorDisposition(selected); return; }
        if (action == "round-gained-trick-target") { ResolveRoundGainedTrickTargetChoice(selected); return; }
        if (action == "unique-leader-trick-target") { ResolveUniqueLeaderTrickTargetChoice(selected); return; }
        if (action == "same-name-hand") { ResolveSameNameHandDiscardOrDamageChoice(selected); return; }
        if (action == "completed-undamaged-target-reveal") { ResolveCompletedUndamagedTargetRevealChoice(selected); return; }
        if (action == "recipient-category-mark") { ResolveRecipientCategoryMarkChoice(selected); return; }
        if (action == "off-turn-used-card-gift") { ResolveOffTurnUsedCardGift(selected); return; }
        if (action == "fixed-distance-ending-debt") { ResolveFixedDistanceDebtChoice(selected); return; }
        if (action == "current-card-enhancement")
        {
            ResolveCardEnhancementChoice(selected);
            return;
        }
        if (action == "discard-challenge")
        {
            ResolveProgramDiscardChallengeChoice(selected);
            return;
        }
        if (action is "discard-top-select" or "discard-top-finish")
        {
            ResolveProgramDiscardTopPlacementChoice(selected);
            return;
        }
        if (action == "participant-top-view")
        {
            ResolveParticipantTopView(selected);
            return;
        }
        if (action == "public-pile-collection")
        {
            ResolvePublicPileCollectionChoice(selected);
            return;
        }
        if (action == "marker-payment")
        {
            ResolveMarkerOrHpPayment(selected);
            return;
        }
        if (action == "private-reserve-choice")
        {
            ResolvePrivateReserveChoice(selected);
            return;
        }
        if (action == "different-action-category-gift" || action == "different-action-category-decline")
        {
            ResolveDifferentActionCategoryGift(selected);
            return;
        }
        if (action == "configured-card-declaration")
        {
            ResolveConfiguredCardDeclaration(selected);
            return;
        }
        if (action == "strategic-choice")
        {
            ResolveStrategicProgramChoice(selected);
            return;
        }
        if (action == "advanced-lifecycle")
        {
            ResolveAdvancedLifecycleChoice(selected);
            return;
        }
        if (action == "choose-option")
        {
            ResolveProgramOptionChoice(selected);
            return;
        }
        if (action is "distinct-faction-select" or "distinct-faction-finish" or "distinct-faction-discard")
        { ResolveDistinctFactionDiscardChoice(selected); return; }
        if (action is "sole-target-protection" or "pair-obtain" or "shown-pair-gift" or "equipment-donation" or
            "actual-ended-equipment" or "limited-owned-gift" or "finish-limited-owned-gift" or
            "select-target" or "select-targets" or "select-source-card" or "select-and-move-owned-card" or
            "choose-other-owned-card-discard" or "choose-other-owned-card-decline" or
            "restore-phase-hand-discard" or "restore-phase-hand-decline" or
            "choose-own-card-discard" or
            "select-owned-cards" or "finish-owned-cards" or
            "give-bound-card" or "keep-bound-cards" or
            "distribute-owned-card" or "decline-owned-card-distribution" or
            "reveal-target-hand-card" or "reveal-target-hand-card-decline" or
            "request-slash" or "request-slash-decline" or
            "request-slash-nearest" or "request-slash-nearest-decline" or
            "nearest-legal-slash" or "unlimited-virtual-slash" or "damage-judgment-suit-payment" or
            "attack-range-aid-discard-weapon" or "attack-range-aid-draw")
        {
            ResolveProgramInstructionChoice(selected, action);
            return;
        }
        if (action is "different-category-discard" or "different-category-decline")
        {
            ResolveProgramDifferentCategoryDiscardChoice(selected);
            return;
        }
        if (action == "granted-phase-slash") { ResolveGrantedPhaseSlashChoice(selected); return; }
        if (action is "mou-zhijue" or "mou-zhitian-confirm") { ResolveMouZhugeChoice(selected); return; }
        if (action == "provenance-face-up")
        {
            ResolveProvenanceFaceUp(selected); return;
        }
        if (action == "virtual-basic")
        {
            ResolveVirtualBasicChoice(selected);
            return;
        }
        if (action == "shared-slash-offer")
        {
            ResolveSharedSlashOfferChoice(selected); return;
        }
        if (action == "virtual-slash-offer")
        {
            ResolveProgramVirtualSlashOfferChoice(selected);
            return;
        }
        if (action == "assisted-physical-slash")
        {
            ResolveAssistedPhysicalSlashChoice(selected);
            return;
        }
        if (action is "fixed-target-slash" or "declared-deck-criterion" or "declared-deck-recipient")
        {
            ResolveFixedSlashAndDeclaredDeckChoice(selected);
            return;
        }
        if (action == "placed-equipment-benefit")
        {
            ResolvePlacedEquipmentChoice(selected);
            return;
        }
        if (action == "inspected-hand-slash")
        {
            ResolveInspectedHandChoice(selected);
            return;
        }
        if (action == "friend-configuration") { ResolveFriendConfiguration(selected); return; }
        if (action == "conditional-discard-duel")
        {
            ResolveConditionalDuelPayment(selected);
            return;
        }
        if (action == "dual-color-choice")
        {
            ResolveDualColorChoice(selected);
            return;
        }
        if (action == "capped-hand-discard")
        {
            ResolveCappedHandRefreshChoice(selected);
            return;
        }
        if (action == "take-other-card")
        {
            ResolveOtherCardSelectionChoice(selected);
            return;
        }
        if (action is "private-hand-take" or "hand-repayment")
        {
            ResolveParticipantHandChoice(selected);
            return;
        }
        if (action == "use-all-hand-as-ordinary-trick")
        {
            ResolveProgramOrdinaryTrickUseChoice(selected);
            return;
        }
        if (action == "use-virtual-ordinary-trick")
        {
            ResolveProgramVirtualOrdinaryTrickChoice(selected);
            return;
        }
        if (action == "deferred-private-offer") { ResolveDeferredPrivateOfferChoice(selected); return; }
        if (action == "game-hand-hp-discard") { ResolveGameHandHpDiscard(selected); return; }
        if (action == "unequal-hand-hp-ending") { ResolveUnequalHandHpChoice(selected); return; }
        if (action == "phase-start-card-control") { ResolvePhaseStartCardControlChoice(selected); return; }
        if (action == "end-refill-next-turn") { ResolveEndRefillNextTurnChoice(selected); return; }
        if (action == "incoming-distance-courtesy") { ResolveIncomingDistanceCourtesyChoice(selected); return; }
        if (action == "named-ambush") { ResolveNamedAmbushChoice(selected); return; }
        if (action == "extra-effects-rank-guess") { ResolveExtraEffectsAndRankGuessChoice(selected); return; }
        if (action == "rice-pile") { ResolveRiceChoice(selected); return; }
        if (action == "damage-source-hand") { ResolveDamageSourceHandChoice(selected); return; }
        if (action == "targeted-ordinary-trick") { ResolveTargetedOrdinaryTrickChoice(selected); return; }
        if (action == "order-bound-cards")
        {
            var frame = _resolutionStack.LastOrDefault() as ProgramSkillFrame ??
                throw new InvalidOperationException("The bottom-order choice lost its program frame.");
            var paused = ProgramInstructionResolver.Default
                .Resolve(frame, _contentRegistry!.GetSkill(frame.SkillId).Program!)
                .GetPausedInstruction(frame.InstructionIndex);
            if (paused.Effect is not
                {
                    Op: SkillProgramEffectOp.MoveBoundCards,
                    Destination: SkillProgramCardDestination.DrawPileBottom
                } effect ||
                selected.Parameters.GetValueOrDefault("source-bind") != effect.SourceBind ||
                selected.Parameters.GetValueOrDefault("except-bind") != (effect.ExceptBind ?? string.Empty))
                throw new InvalidOperationException("The bottom-order choice does not match its suspended instruction.");
            ClearPendingDecision();
            _ = MoveProgramBoundCards(frame.Id, frame.OwnerSeat, effect.SourceBind!, effect.ExceptBind,
                SkillProgramCardDestination.DrawPileBottom, null,
                new CardMoveReason($"skill-program.{frame.SkillId}.{effect.Op}"), selected.Cards);
            AdvanceRuntimeProgram(frame.Id);
            return;
        }
        if (action == "owned-hand-rank-sum")
        {
            ResolveOwnedHandRankSumChoice(selected);
            return;
        }
        if (action == "select-subset")
        {
            var frame = _resolutionStack.LastOrDefault() as ProgramSkillFrame ??
                throw new InvalidOperationException("The subset choice lost its program frame.");
            var paused = ProgramInstructionResolver.Default
                .Resolve(frame, _contentRegistry!.GetSkill(frame.SkillId).Program!)
                .GetPausedInstruction(frame.InstructionIndex);
            if (paused.Effect is not
                { Op: SkillProgramEffectOp.SelectCardSubset } effect ||
                selected.Parameters.GetValueOrDefault("source-bind") != effect.SourceBind ||
                selected.Parameters.GetValueOrDefault("result-bind") != effect.ResultBind)
                throw new InvalidOperationException("The subset choice does not match the suspended instruction.");
            var source = GetProgramCardSet(frame, effect.SourceBind!);
            var sourceIndexes = source.CardIds
                .Select((cardId, index) => (cardId, index))
                .ToDictionary(item => item.cardId, item => item.index);
            var cards = selected.Cards.Select(cardId =>
            {
                if (!sourceIndexes.TryGetValue(cardId, out var sourceIndex) ||
                    sourceIndex >= source.SourceLocations.Count)
                {
                    throw new InvalidOperationException("The selected program card lost its frozen source.");
                }
                return _cardZones.CardsAt(source.SourceLocations[sourceIndex])
                    .Single(card => card.Id == cardId);
            }).ToArray();
            var rankSum = cards.Sum(card => card.Rank);
            if (rankSum > effect.MaximumRankSum)
                throw new InvalidOperationException("The selected subset exceeds its rank-sum limit.");
            if (effect.OnePerSuit
                    ? cards.Length != (effect.AvailableAtSourceOnly == true
                        ? CountAvailableBoundSuits(source)
                        : source.CardIds.Select((cardId, index) =>
                              _cardZones.CardsAt(source.SourceLocations[index])
                                  .Single(card => card.Id == cardId).Suit)
                          .Distinct().Count()) ||
                      cards.Select(card => card.Suit).Distinct().Count() != cards.Length
                    : selected.Cards.Distinct().Count() != selected.Cards.Count ||
                    selected.Cards.Any(cardId => !source.CardIds.Contains(cardId)) ||
                    selected.Cards.Count < (effect.AllowFewerWhenInsufficient
                        ? Math.Min(effect.MinimumCards, effect.AvailableAtSourceOnly == true ? CountAvailableBoundCards(source) : source.CardIds.Count) : effect.MinimumCards) ||
                    selected.Cards.Count > (effect.AllowFewerWhenInsufficient
                        ? Math.Min(effect.MaximumCards, effect.AvailableAtSourceOnly == true ? CountAvailableBoundCards(source) : source.CardIds.Count) : effect.MaximumCards))
                throw new InvalidOperationException("The selected subset is no longer legal.");
            ClearPendingDecision();
            SetProgramCardSet(frame.Id, effect.ResultBind!, selected.Cards,
                SkillProgramCardSetVisibility.Private, selectionActorSeat: source.SelectionActorSeat);
            AdvanceEventRulesAndQueueFact(new ProgramCardSubsetSelectedEvent(
                frame.Id, frame.SkillId, GetProgramBindingId(frame), effect.SourceBind!, effect.ResultBind!,
                Array.AsReadOnly(selected.Cards.ToArray()), rankSum));
            AdvanceRuntimeProgram(frame.Id);
            return;
        }
        if (action == "yanjiao-split") { ResolveYanjiaoSplitChoice(selected); return; }
        if (action == "tunan-branch") { ResolveTunanBranchChoice(selected); return; }
        if (action == "tunan-target") { ResolveTunanTargetChoice(selected); return; }
        if (action == "bijing-punish-discard") { ResolveBijingPunishChoice(selected); return; }
        if (action == "zhiren-field-discard") { ResolveZhirenFieldChoice(selected); return; }
        if (action == "youdi-bait-discard") { ResolveYoudiBaitChoice(selected); return; }
        if (action == "guanchao-pattern") { ResolveGuanchaoPatternChoice(selected); return; }
        if (action == "xunxian-gift") { ResolveXunxianGiftChoice(selected); return; }
        if (action == "daoshu-suit") { ResolveDaoshuSuitChoice(selected); return; }
        if (action == "daoshu-give-back") { ResolveDaoshuGiveBackChoice(selected); return; }
        if (action == "zecai-target" || action == "zecai-decline") { ResolveZecaiChoice(selected); return; }
        if (action == "juanxia-trick") { ResolveJuanxiaTrickChoice(selected); return; }
        if (action == "juanxia-target-card") { ResolveJuanxiaTargetCardChoice(selected); return; }
        if (action == "juanxia-fire-payment") { ResolveJuanxiaFirePaymentChoice(selected); return; }
        if (action == "juanxia-retaliate") { ResolveJuanxiaRetaliateChoice(selected); return; }
        if (action == "zhanyi-launch") { ResolveZhanyiCategoryChoice(selected); return; }
        if (action == "zhanyi-punish-target") { ResolveZhanyiPunishTargetChoice(selected); return; }
        if (action == "zhanyi-punish-card") { ResolveZhanyiPunishCardChoice(selected); return; }
        if (action == "fengji-option") { ResolveFengjiOptionChoice(selected); return; }
        if (action == "fengji-recipient") { ResolveFengjiRecipientChoice(selected); return; }
        if (action == "changji-ending-choice") { ResolveChangjiEndingChoice(selected); return; }
        if (action == "changji-discard") { ResolveChangjiDiscardChoice(selected); return; }
        if (action == "zengou-cost") { ResolveZengouCostChoice(selected); return; }
        if (action == "zhuihuan-arm") { ResolveZhuihuanArmChoice(selected); return; }
        if (action == "tongxie-arm") { ResolveTongxieArmChoice(selected); return; }
        if (action is "tongxie-follow-up" or "tongxie-follow-up-decline")
        { ResolveTongxieFollowUpChoice(selected); return; }
        if (action is "tongxie-guard" or "tongxie-guard-decline")
        { ResolveTongxieGuardChoice(selected); return; }
        if (action == "kangge-choose") { ResolveKanggeChooseChoice(selected); return; }
        if (action == "kangge-heal") { ResolveKanggeHealChoice(selected); return; }
        if (action == "jielie-gift") { ResolveJielieSuitChoice(selected); return; }
        if (action == "ruiji-distribution") { ResolveQiaoliDistributionChoice(selected); return; }
        if (action == "qingliang-option") { ResolveQingliangOptionChoice(selected); return; }
        if (action == "qingliang-suit") { ResolveQingliangSuitChoice(selected); return; }
        if (action == "luochong-pick" || action == "luochong-decline") { ResolveLuochongPickChoice(selected); return; }
        if (action == "luochong-discard") { ResolveLuochongDiscardChoice(selected); return; }
        if (action == "aichen-remove") { ResolveAichenRemoveChoice(selected); return; }
        if (action == "yujue-slot" || action == "yujue-decline" || action == "yujue-target" ||
            action == "yujue-give") { ResolveYujueProgramChoice(selected); return; }
        if (action == "yuanzi-draw" || action == "yuanzi-decline" ||
            action == "liejie-pick" || action == "liejie-finish" || action == "liejie-decline")
        { ResolveWeiZiProgramChoice(selected); return; }
        if (action == "zhuitao-mark") { ResolveZhuitaoMarkChoice(selected); return; }

        var (candidate, context) = GetPendingProgramTriggerCandidate();
        if (_resolutionStack.LastOrDefault() is ProgramLifecycleTriggerWindowFrame lifecycle &&
            GetProgramTrigger(candidate).ChoiceGroup is { } choiceGroup)
        {
            ResolveProgramTriggerGroupChoice(lifecycle, candidate, context, choiceGroup, selected, action);
            return;
        }
        if (_resolutionStack.LastOrDefault() is PlayPhaseStartingBoundaryFrame starting &&
            GetProgramTrigger(candidate).ChoiceGroup is { } startingGroup)
        {
            ResolvePlayPhaseStartingGroupChoice(starting, candidate, context, startingGroup, selected, action);
            return;
        }
        if (selected.Parameters.GetValueOrDefault("skill-id") != candidate.SkillId ||
            selected.Parameters.GetValueOrDefault("binding-id") != candidate.BindingId ||
            selected.Parameters.GetValueOrDefault("skill-instance-id") != candidate.SkillInstanceId)
            throw new InvalidOperationException("The program activation identity changed.");
        ClearPendingDecision();
        if (action == "activate")
        {
            if (!CanRunProgramTrigger(candidate, context))
            {
                CompleteSkippedProgramCandidate(candidate);
                return;
            }
            BeginProgramBinding(candidate, context);
            return;
        }
        if (action != "skip") throw new InvalidOperationException("Unsupported program trigger choice.");
        CompleteSkippedProgramCandidate(candidate);
    }

    private void ResolveProgramTriggerGroupChoice(
        ProgramLifecycleTriggerWindowFrame frame,
        ProgramTriggerCandidate first,
        ProgramSkillWindowContext context,
        string choiceGroup,
        PromptChoice selected,
        string? action)
    {
        var members = GetProgramTriggerChoiceGroup(frame, first, choiceGroup);
        if (selected.Parameters.GetValueOrDefault("choice-group") != choiceGroup ||
            selected.Cards.Count != 0 || selected.Targets.Count != 0)
            throw new InvalidOperationException("The program choice group identity changed.");
        ClearPendingDecision();
        if (action == "skip")
        {
            if (!GetProgramTrigger(first).Optional)
                throw new InvalidOperationException("A mandatory program choice group cannot be skipped.");
            foreach (var member in members)
                AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
                    frame.Id, member.SkillId, member.BindingId, member.SkillInstanceId,
                    member.OwnerSeat, frame.Window, Activated: false, Completed: false));
            ReplaceRuntimeTop(frame with { CandidateIndex = frame.CandidateIndex + members.Count });
            AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
            return;
        }
        if (action != "activate")
            throw new InvalidOperationException("Unsupported program choice-group action.");
        var selectedCandidate = members.SingleOrDefault(member =>
            selected.Parameters.GetValueOrDefault("skill-id") == member.SkillId &&
            selected.Parameters.GetValueOrDefault("binding-id") == member.BindingId &&
            selected.Parameters.GetValueOrDefault("skill-instance-id") == member.SkillInstanceId) ??
            throw new InvalidOperationException("The selected program branch is not in the pending choice group.");
        foreach (var member in members.Where(member => member != selectedCandidate))
            AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
                frame.Id, member.SkillId, member.BindingId, member.SkillInstanceId,
                member.OwnerSeat, frame.Window, Activated: false, Completed: false));
        var selectedContext = context with
        {
            OccurrenceIndex = selectedCandidate.OccurrenceIndex,
            ResumeCandidateIndex = frame.CandidateIndex + members.Count
        };
        if (!CanRunProgramTrigger(selectedCandidate, selectedContext))
        {
            AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
                frame.Id, selectedCandidate.SkillId, selectedCandidate.BindingId,
                selectedCandidate.SkillInstanceId, selectedCandidate.OwnerSeat, frame.Window,
                Activated: false, Completed: false));
            ReplaceRuntimeTop(frame with { CandidateIndex = frame.CandidateIndex + members.Count });
            AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
            return;
        }
        BeginProgramBinding(selectedCandidate, selectedContext);
    }

    private void ResolvePlayPhaseStartingGroupChoice(
        PlayPhaseStartingBoundaryFrame frame,
        ProgramTriggerCandidate first,
        ProgramSkillWindowContext context,
        string choiceGroup,
        PromptChoice selected,
        string? action)
    {
        var members = GetPlayPhaseStartingChoiceGroup(frame, first, choiceGroup);
        if (selected.Parameters.GetValueOrDefault("choice-group") != choiceGroup ||
            selected.Cards.Count != 0 || selected.Targets.Count != 0)
            throw new InvalidOperationException("The program choice group identity changed.");
        ClearPendingDecision();
        if (action == "skip")
        {
            if (!GetProgramTrigger(first).Optional)
                throw new InvalidOperationException("A mandatory program choice group cannot be skipped.");
            foreach (var member in members)
                AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
                    frame.Id, member.SkillId, member.BindingId, member.SkillInstanceId,
                    member.OwnerSeat, SkillProgramTriggerWindow.PlayPhaseStarting, Activated: false, Completed: false));
            ReplaceRuntimeTop(frame with { ItemIndex = frame.ItemIndex + members.Count });
            AdvanceRuntimeTop<PlayPhaseStartingBoundaryFrame>();
            return;
        }
        if (action != "activate")
            throw new InvalidOperationException("Unsupported program choice-group action.");
        var selectedCandidate = members.SingleOrDefault(member =>
            selected.Parameters.GetValueOrDefault("skill-id") == member.SkillId &&
            selected.Parameters.GetValueOrDefault("binding-id") == member.BindingId &&
            selected.Parameters.GetValueOrDefault("skill-instance-id") == member.SkillInstanceId) ??
            throw new InvalidOperationException("The selected program branch is not in the pending choice group.");
        foreach (var member in members.Where(member => member != selectedCandidate))
            AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
                frame.Id, member.SkillId, member.BindingId, member.SkillInstanceId,
                member.OwnerSeat, SkillProgramTriggerWindow.PlayPhaseStarting, Activated: false, Completed: false));
        var selectedContext = context with
        {
            OccurrenceIndex = selectedCandidate.OccurrenceIndex,
            ResumeCandidateIndex = frame.ItemIndex + members.Count
        };
        if (!CanRunProgramTrigger(selectedCandidate, selectedContext))
        {
            AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
                frame.Id, selectedCandidate.SkillId, selectedCandidate.BindingId,
                selectedCandidate.SkillInstanceId, selectedCandidate.OwnerSeat,
                SkillProgramTriggerWindow.PlayPhaseStarting, Activated: false, Completed: false));
            ReplaceRuntimeTop(frame with { ItemIndex = frame.ItemIndex + members.Count });
            AdvanceRuntimeTop<PlayPhaseStartingBoundaryFrame>();
            return;
        }
        BeginProgramBinding(selectedCandidate, selectedContext);
    }

    private void ResolveProgramInstructionChoice(PromptChoice selected, string action)
    {
        var frame = _resolutionStack.LastOrDefault() as ProgramSkillFrame ??
            throw new InvalidOperationException("The program instruction choice lost its frame.");
        if (selected.Parameters.GetValueOrDefault("frame-id") !=
            frame.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) ||
            frame.InstructionIndex == 0)
            throw new InvalidOperationException("The program instruction choice has a stale frame identity.");
        var effect = ProgramInstructionResolver.Default
            .Resolve(frame, _contentRegistry!.GetSkill(frame.SkillId).Program!)
            .GetPausedInstruction(frame.InstructionIndex).Effect;

        switch (action)
        {
            case "sole-target-protection": ResolveSoleProtectionChoice(selected); return;
            case "pair-obtain": ResolvePairObtainChoice(selected); return;
            case "shown-pair-gift": ResolveShownPairGiftChoice(selected); return;
            case "equipment-donation":
                ResolveEquipmentDonationChoice(frame, selected);
                return;
            case "actual-ended-equipment":
                ResolveActualEndedEquipmentChoice(frame, selected);
                return;
            case "limited-owned-gift":
            case "finish-limited-owned-gift":
                ResolveLostHpOwnedGift(frame, effect, selected);
                return;
            case "select-target":
                {
                    if (effect is not
                        {
                            Op: SkillProgramEffectOp.SelectTarget,
                            TargetKind: { } targetKind
                        } || selected.Parameters.GetValueOrDefault("target-kind") != targetKind.ToString() ||
                        selected.Parameters.GetValueOrDefault("marker") != (effect.Marker?.ToString() ?? "") ||
                        selected.Targets.Count != 1 || selected.Cards.Count != 0)
                        throw new InvalidOperationException("The selected target does not match the suspended instruction.");
                    var targetSeat = selected.Targets.Single();
                    if (!IsProgramTargetEligible(frame.OwnerSeat, targetKind, effect.Zones, targetSeat,
                        effect.Marker, frame.WindowContext, effect.ActorReference) ||
                        !CanSelectProgramPindianOpponent(frame, targetSeat))
                        throw new InvalidOperationException("The selected program target is no longer legal.");
                    ClearPendingDecision();
                    ReplaceRuntimeTop(frame with
                    {
                        SelectedTargetSeats = Array.AsReadOnly(new[] { targetSeat })
                    });
                    if (frame.WindowContext?.Judgment is { } judgment)
                        AdvanceEventRulesAndQueueFact(new ProgramJudgmentTargetSelectedEvent(
                            frame.WindowContext.ParentFrameId, judgment.JudgmentFrameId,
                            frame.SkillId, frame.TriggerId!, frame.OwnerSeat, targetSeat));
                    AdvanceRuntimeProgram(frame.Id);
                    return;
                }
            case "select-targets":
                {
                    if (effect.SourceBind is not null)
                    {
                        ResolveProgramNamedBoundTargets(frame, effect, selected);
                        return;
                    }
                    if (effect is not
                        {
                            Op: SkillProgramEffectOp.SelectTargets,
                            TargetKind: { } targetKind,
                            TargetAiOrder: { } targetAiOrder
                        } || selected.Parameters.GetValueOrDefault("target-kind") != targetKind.ToString() ||
                        selected.Parameters.GetValueOrDefault("target-ai-order") != targetAiOrder.ToString() ||
                        selected.Cards.Count != 0 ||
                        selected.Targets.Count < effect.MinimumTargets ||
                        selected.Targets.Count > effect.MaximumTargets ||
                        (effect.NumberExpression == SkillProgramNumberExpression.CurrentHandCount &&
                         selected.Targets.Count > GetHand(_players[frame.OwnerSeat]).Count) ||
                        selected.Targets.Distinct().Count() != selected.Targets.Count)
                        throw new InvalidOperationException("The selected targets do not match the suspended instruction.");
                    var legalTargets = GetProgramTargetSeats(frame.OwnerSeat, targetKind, frame.WindowContext);
                    if (selected.Targets.Any(targetSeat => !legalTargets.Contains(targetSeat)))
                        throw new InvalidOperationException("A selected program target is no longer legal.");
                    if (targetKind == SkillProgramTargetKind.EquipmentExchangePair &&
                        (selected.Targets.Count != 2 || !IsProgramEquipmentExchangePair(frame.OwnerSeat,
                            selected.Targets[0], selected.Targets[1])))
                        throw new InvalidOperationException("The selected equipment-exchange pair is no longer legal.");
                    if (targetKind == SkillProgramTargetKind.OtherLivingUnequalHandPair &&
                        (selected.Targets.Count != 2 ||
                         GetHand(_players[selected.Targets[0]]).Count >= GetHand(_players[selected.Targets[1]]).Count))
                        throw new InvalidOperationException("The selected unequal-hand pair is no longer legal.");
                    if (targetKind == SkillProgramTargetKind.OtherLivingPair &&
                        (selected.Targets.Count != 2 ||
                         GetHand(_players[selected.Targets[0]]).Count > GetHand(_players[selected.Targets[1]]).Count))
                        throw new InvalidOperationException("The selected pair must be two players in ascending hand order.");
                    if (targetKind == SkillProgramTargetKind.LivingPairDistinct &&
                        (selected.Targets.Count != 2 ||
                         selected.Targets[0] == selected.Targets[1]))
                        throw new InvalidOperationException("The selected ordered pair must name two distinct players.");
                    ClearPendingDecision();
                    ReplaceRuntimeTop(frame with
                    {
                        SelectedTargetSeats = Array.AsReadOnly(selected.Targets.ToArray())
                    });
                    AdvanceRuntimeProgram(frame.Id);
                    return;
                }
            case "reveal-target-hand-card":
                {
                    ResolveProgramRevealCardSelection(selected);
                    return;
                }
            case "reveal-target-hand-card-decline":
                {
                    ResolveProgramRevealCardSelection(selected);
                    return;
                }
            case "select-source-card":
                {
                    if (HasForeignDiscardCapability && _pendingDecision?.PlayerSeat != frame.OwnerSeat)
                        throw new InvalidOperationException("Source selection lost its actual choosing actor.");
                    if (effect.Op != SkillProgramEffectOp.SelectSourceCard ||
                        selected.Parameters.GetValueOrDefault("result-bind") != effect.ResultBind ||
                        !Enum.TryParse<CardZoneKind>(
                            selected.Parameters.GetValueOrDefault("source-zone"), out var zone) ||
                        !effect.Zones.Contains(zone) ||
                        (effect.CardSource switch
                        {
                            SkillProgramCardSource.Owner => frame.OwnerSeat,
                            SkillProgramCardSource.DamageSource => frame.WindowContext?.SourceSeat,
                            SkillProgramCardSource.EventTarget => frame.WindowContext?.TargetSeat,
                            _ => null
                        }) is not { } sourceSeat ||
                        effect.CardSource == SkillProgramCardSource.DamageSource && sourceSeat == frame.OwnerSeat &&
                        !effect.AllowSameSource)
                        throw new InvalidOperationException("The source-card choice does not match the suspended instruction.");

                    Card card;
                    CardLocation location;
                    if (zone == CardZoneKind.Hand)
                    {
                        if (selected.Cards.Count != 0 ||
                            !int.TryParse(
                                selected.Parameters.GetValueOrDefault("slot-index"),
                                System.Globalization.NumberStyles.None,
                                System.Globalization.CultureInfo.InvariantCulture,
                                out var slot) ||
                            slot < 0 || slot >= GetHand(_players[sourceSeat]).Count)
                            throw new InvalidOperationException("The selected opaque hand slot is no longer legal.");
                        card = GetHand(_players[sourceSeat])[slot];
                        location = CardLocation.Hand(sourceSeat);
                    }
                    else if (zone == CardZoneKind.Equipment)
                    {
                        if (selected.Cards.Count != 1)
                            throw new InvalidOperationException("The equipment selection is malformed.");
                        location = CardLocation.Equipment(sourceSeat);
                        card = GetEquipment(_players[sourceSeat])
                            .SingleOrDefault(item => item.Id == selected.Cards.Single()) ??
                            throw new InvalidOperationException("The selected equipment is no longer available.");
                        if (effect.EquipmentSlots.Count > 0 &&
                            !effect.EquipmentSlots.Contains(EquipmentCatalog.Get(card.Kind).Slot))
                            throw new InvalidOperationException("The selected equipment slot is no longer legal.");
                    }
                    else if (effect.CardSource == SkillProgramCardSource.Owner && zone is
                        CardZoneKind.WoodenOxGrain or CardZoneKind.BuquWound or
                        CardZoneKind.Authority or CardZoneKind.Chunlao)
                    {
                        if (selected.Cards.Count != 1)
                            throw new InvalidOperationException("The owner-pile selection is malformed.");
                        location = new CardLocation(zone, sourceSeat);
                        card = _cardZones.CardsAt(location)
                            .SingleOrDefault(item => item.Id == selected.Cards.Single()) ??
                            throw new InvalidOperationException("The selected owner-pile card is no longer available.");
                    }
                    else
                    {
                        throw new InvalidOperationException("The configured source-card zone is unsupported.");
                    }

                    ClearPendingDecision();
                    SetProgramCardSet(
                        frame.Id,
                        effect.ResultBind!,
                        [card.Id],
                        SkillProgramCardSetVisibility.Private,
                        [location], selectionActorSeat: frame.OwnerSeat);
                    AdvanceRuntimeProgram(frame.Id);
                    return;
                }
            case "select-owned-cards":
            case "finish-owned-cards":
                if (effect.Op == SkillProgramEffectOp.HoldTargetCards)
                {
                    if (selected.Parameters.GetValueOrDefault("frame-id") !=
                        frame.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) ||
                        frame.InstructionIndex == 0)
                        throw new InvalidOperationException("The card-hold choice has a stale frame identity.");
                    ResolveProgramHoldCardSelection(frame, selected);
                    return;
                }
                ResolveProgramOwnedCardSelection(frame, effect, selected);
                return;
            case "distribute-owned-card":
            case "decline-owned-card-distribution":
                ResolveProgramOwnedCardDistribution(frame, effect, selected);
                return;
            case "attack-range-aid-discard-weapon":
            case "attack-range-aid-draw":
                ResolveProgramAttackRangeAid(frame, effect, selected);
                return;
            case "select-and-move-owned-card":
                {
                    if (effect.Op != SkillProgramEffectOp.SelectAndMoveOwnedCard)
                        throw new InvalidOperationException("The payment choice does not match the suspended instruction.");
                    ResolveSelectAndMoveOwnedCardChoice(frame, effect, selected);
                    return;
                }
            case "choose-other-owned-card-discard":
            case "choose-other-owned-card-decline":
                ResolveProgramOtherOwnedCardDiscardChoice(selected);
                return;
            case "restore-phase-hand-discard":
            case "restore-phase-hand-decline":
                ResolveProgramPhaseHandDiscardChoice(selected);
                return;
            case "request-slash":
            case "request-slash-decline":
                ResolveProgramRequestSlashChoice(selected);
                return;
            case "damage-judgment-suit-payment":
                ResolveDamageJudgmentSuitPaymentChoice(selected);
                return;
            case "nearest-legal-slash":
                ResolveNearestLegalSlashChoice(selected);
                return;
            case "unlimited-virtual-slash":
                ResolveUnlimitedVirtualSlashChoice(selected);
                return;
            case "request-slash-nearest":
            case "request-slash-nearest-decline":
                ResolveProgramRequestSlashByNearestChoice(selected);
                return;
            case "choose-own-card-discard":
                ResolveProgramOwnCardDiscardChoice(selected);
                return;
            case "give-bound-card":
            case "keep-bound-cards":
                {
                    if (effect is not
                        {
                            Op: SkillProgramEffectOp.GiveBoundCard,
                            SourceBind: { } sourceBind,
                            TargetKind: { } targetKind
                        } || selected.Parameters.GetValueOrDefault("source-bind") != sourceBind ||
                        selected.Parameters.GetValueOrDefault("target-kind") != targetKind.ToString())
                        throw new InvalidOperationException("The bound-card choice does not match the suspended instruction.");
                    var binding = GetProgramCardSet(frame, sourceBind);
                    if (action == "keep-bound-cards")
                    {
                        if (selected.Cards.Count != 0 || selected.Targets.Count != 0)
                            throw new InvalidOperationException("The retain-cards choice is malformed.");
                        ClearPendingDecision();
                        AdvanceRuntimeProgram(frame.Id);
                        return;
                    }

                    if (selected.Cards.Count != 1 || selected.Targets.Count != 1)
                        throw new InvalidOperationException("The bound-card gift choice is malformed.");
                    var cardId = selected.Cards.Single();
                    var targetSeat = selected.Targets.Single();
                    var indexes = binding.CardIds
                        .Select((id, position) => (id, position))
                        .ToDictionary(item => item.id, item => item.position);
                    if (!indexes.TryGetValue(cardId, out var index) ||
                        index >= binding.SourceLocations.Count ||
                        !GetProgramTargetSeats(frame.OwnerSeat, targetKind).Contains(targetSeat))
                        throw new InvalidOperationException("The bound-card gift is no longer legal.");
                    var from = binding.SourceLocations[index];
                    if (_cardZones.GetLocation(cardId) != from)
                        throw new InvalidOperationException("The bound card left its frozen source before the gift.");
                    var card = _cardZones.CardsAt(from).Single(item => item.Id == cardId);
                    ClearPendingDecision();
                    MoveCard(
                        card,
                        from,
                        CardLocation.Hand(targetSeat),
                        new CardMoveReason($"skill-program.{frame.SkillId}.{effect.Op}"));
                    AdvanceEventRulesAndQueueFact(new ProgramBoundCardGivenEvent(
                        frame.Id,
                        frame.SkillId,
                        GetProgramBindingId(frame),
                        frame.OwnerSeat,
                        targetSeat,
                        cardId));
                    AdvanceRuntimeProgram(frame.Id);
                    return;
                }
            default:
                throw new InvalidOperationException("Unsupported program instruction choice.");
        }
    }

    private (ProgramTriggerCandidate Candidate, ProgramSkillWindowContext Context)
        GetPendingProgramTriggerCandidate()
    {
        if (_resolutionStack.LastOrDefault() is ForeignActualTurnStartWindowFrame foreign)
            return (foreign.Candidates[foreign.CandidateIndex], foreign.Contexts[foreign.CandidateIndex]);
        if (_resolutionStack.LastOrDefault() is ActualUseTargetWindowFrame actualTargets)
            return (actualTargets.Candidates[actualTargets.CandidateIndex], actualTargets.Contexts[actualTargets.CandidateIndex]);
        if (_resolutionStack.LastOrDefault() is CardEffectBeforeApplyFrame effect)
        {
            var candidate = effect.Candidates[effect.CandidateIndex];
            return (ToSharedCandidate(candidate),candidate.FrozenContext!);
        }
        if (_resolutionStack.LastOrDefault() is DeferredTurnEndFrame { AfterTurnEnded: not null } afterTurnEnded)
        {
            var candidate = AfterTurnEndedCandidate(afterTurnEnded);
            if (afterTurnEnded.AfterTurnEnded.CurrentChild is not null)
                throw new InvalidOperationException("A pending after-turn-ended prompt cannot belong to a live child.");
            return (candidate, CreateAfterTurnEndedContext(afterTurnEnded, candidate));
        }
        if (_resolutionStack.LastOrDefault() is TurnEndingBoundaryFrame turnEnding)
        {
            var candidate = turnEnding.Items[turnEnding.ItemIndex].Candidate ??
                throw new InvalidOperationException("The turn-ending program item lost its candidate.");
            return (candidate, CreateTurnEndingProgramContext(turnEnding, candidate,
                turnEnding.Items[turnEnding.ItemIndex].Facts));
        }
        if (_resolutionStack.LastOrDefault() is PlayPhaseStartingBoundaryFrame playStarting)
        {
            var candidate = playStarting.Items[playStarting.ItemIndex].Candidate ??
                throw new InvalidOperationException("The play-phase-starting item lost its candidate.");
            return (candidate, CreatePlayPhaseStartingProgramContext(playStarting, candidate,
                playStarting.Items[playStarting.ItemIndex].Facts));
        }
        if (_resolutionStack.LastOrDefault() is ProgramLifecycleTriggerWindowFrame lifecycle)
        {
            var candidate = lifecycle.Candidates[lifecycle.CandidateIndex];
            return (candidate, new ProgramSkillWindowContext(
                lifecycle.Window, lifecycle.Id, candidate.OwnerSeat,
                SourceSeat: lifecycle.OwnerSeat, TargetSeat: lifecycle.OwnerSeat,
                OccurrenceIndex: candidate.OccurrenceIndex,
                Facts: lifecycle.ParticipantFacts?.GetValueOrDefault(candidate.OwnerSeat) ?? lifecycle.Facts)
            { ProgramTarget = lifecycle.ProgramTarget, SourceSeat = lifecycle.ProgramTarget?.OwnerSeat ?? lifecycle.OwnerSeat, TargetSeat = lifecycle.ProgramTarget?.TargetSeat ?? lifecycle.OwnerSeat });
        }
        if (_resolutionStack.LastOrDefault() is HpChangedTriggerWindowFrame hpChanged)
            return (hpChanged.Candidates[hpChanged.CandidateIndex], hpChanged.Contexts[hpChanged.CandidateIndex]);
        if (_resolutionStack.LastOrDefault() is CardsMovedTriggerWindowFrame cardsMoved)
        {
            var candidate = cardsMoved.Candidates[cardsMoved.CandidateIndex];
            return (candidate, CreateCardsMovedProgramContext(cardsMoved, candidate));
        }
        if (_resolutionStack.LastOrDefault() is ProgramDeathTriggerWindowFrame deathWindow)
        {
            var candidate = deathWindow.Candidates[deathWindow.CandidateIndex];
            return (candidate, CreateOwnerDiedProgramContext(deathWindow, candidate));
        }
        if (_resolutionStack.LastOrDefault() is ProgramKillTriggerWindowFrame killWindow)
            return (killWindow.Candidates[killWindow.CandidateIndex],
                killWindow.Contexts[killWindow.CandidateIndex]);
        if (_resolutionStack.LastOrDefault() is BeforeDamageProgramWindowFrame beforeDamage)
        {
            var item = beforeDamage.Candidates[beforeDamage.CandidateIndex];
            return (item.Candidate, CreateBeforeDamageProgramContext(beforeDamage, item));
        }
        if (_resolutionStack.LastOrDefault() is ProgramCardTriggerWindowFrame cardAction &&
            cardAction.Candidates[cardAction.CandidateIndex] is { } cardCandidate)
        {
            return (ToSharedCandidate(cardCandidate), CreateCardActionProgramContext(cardAction, cardCandidate));
        }
        if (ActiveDamageTrigger is { } damage &&
            damage.Candidates[damage.CandidateIndex].ToProgramCandidate() is { } damageCandidate)
            return (damageCandidate, CreateAfterDamageProgramContext(damage, damageCandidate));
        throw new InvalidOperationException("The program prompt has no parent trigger candidate.");
    }

    private void CompleteSkippedProgramCandidate(ProgramTriggerCandidate candidate)
    {
        if (_resolutionStack.LastOrDefault() is ForeignActualTurnStartWindowFrame foreign &&
            foreign.Candidates[foreign.CandidateIndex] == candidate)
        {
            AdvanceForeignActualTurnStartCandidate(foreign, false, false);
            AdvanceRuntimeTop<ForeignActualTurnStartWindowFrame>(); return;
        }
        if (_resolutionStack.LastOrDefault() is ActualUseTargetWindowFrame actualTargets &&
            actualTargets.Candidates[actualTargets.CandidateIndex] == candidate)
        {
            AdvanceActualUseTargetCandidate(actualTargets, false, false);
            AdvanceRuntimeTop<ActualUseTargetWindowFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is CardEffectBeforeApplyFrame effect)
        {
            if (ToSharedCandidate(effect.Candidates[effect.CandidateIndex]) != candidate) throw new InvalidOperationException("Skipped effect candidate changed.");
            CompleteCardEffectCandidate(effect.Candidates[effect.CandidateIndex].FrozenContext!); return;
        }
        if (_resolutionStack.LastOrDefault() is DeferredTurnEndFrame { AfterTurnEnded: not null } afterTurnEnded)
        {
            AdvanceAfterTurnEndedCandidate(afterTurnEnded, candidate, activated: false, completed: false);
            ContinueDeferredTurnEnd();
            return;
        }
        if (_resolutionStack.LastOrDefault() is ProgramKillTriggerWindowFrame killWindow &&
            killWindow.Candidates[killWindow.CandidateIndex] == candidate)
        {
            AdvanceKillDiedProgramCandidate(killWindow, candidate, activated: false, completed: false);
            AdvanceRuntimeTop<ProgramKillTriggerWindowFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is TurnEndingBoundaryFrame turnEnding &&
            turnEnding.Items[turnEnding.ItemIndex].Candidate == candidate)
        {
            AdvanceTurnEndingBoundaryCandidate(
                turnEnding, candidate, activated: false, completed: false);
            AdvanceRuntimeTop<TurnEndingBoundaryFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is PlayPhaseStartingBoundaryFrame playStarting &&
            playStarting.Items[playStarting.ItemIndex].Candidate == candidate)
        {
            AdvancePlayPhaseStartingCandidate(
                playStarting, candidate, activated: false, completed: false);
            AdvanceRuntimeTop<PlayPhaseStartingBoundaryFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is ProgramLifecycleTriggerWindowFrame lifecycle)
        {
            AdvanceProgramLifecycleCandidate(lifecycle, activated: false, completed: false);
            AdvanceRuntimeTop<ProgramLifecycleTriggerWindowFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is HpChangedTriggerWindowFrame hpChanged &&
            hpChanged.Candidates[hpChanged.CandidateIndex] == candidate)
        {
            AdvanceHpChangedProgramCandidate(hpChanged, activated: false, completed: false);
            AdvanceRuntimeTop<HpChangedTriggerWindowFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is CardsMovedTriggerWindowFrame cardsMoved &&
            cardsMoved.Candidates[cardsMoved.CandidateIndex] == candidate)
        {
            AdvanceCardsMovedProgramCandidate(
                cardsMoved, candidate, activated: false, completed: false);
            AdvanceRuntimeTop<CardsMovedTriggerWindowFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is ProgramDeathTriggerWindowFrame deathWindow &&
            deathWindow.Candidates[deathWindow.CandidateIndex] == candidate)
        {
            AdvanceOwnerDiedProgramCandidate(deathWindow, candidate, activated: false, completed: false);
            AdvanceRuntimeTop<ProgramDeathTriggerWindowFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is BeforeDamageProgramWindowFrame beforeDamage &&
            beforeDamage.Candidates[beforeDamage.CandidateIndex].Candidate == candidate)
        {
            AdvanceBeforeDamageProgramCandidate(beforeDamage, activated: false, completed: false);
            AdvanceRuntimeTop<BeforeDamageProgramWindowFrame>();
            return;
        }
        if (_resolutionStack.LastOrDefault() is ProgramCardTriggerWindowFrame cardAction &&
            cardAction.Candidates[cardAction.CandidateIndex] is { } cardCandidate &&
            ToSharedCandidate(cardCandidate) == candidate)
        {
            AdvanceProgramCardCandidate(cardAction);
            AdvanceRuntimeTop<ProgramCardTriggerWindowFrame>();
            return;
        }
        if (ActiveDamageTrigger is { } damage &&
            damage.Candidates[damage.CandidateIndex].ToProgramCandidate() == candidate)
        {
            AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
                damage.Id, candidate.SkillId, candidate.BindingId, candidate.SkillInstanceId,
                candidate.OwnerSeat, damage.TriggerWindow,
                Activated: false, Completed: false));
            AdvanceDamageTriggerCandidate(damage);
            return;
        }
        throw new InvalidOperationException("The skipped program candidate lost its parent.");
    }

    private bool IsAiProgramTriggerPending() =>
        _pendingDecision is { Kind: DecisionKind.ProgramTrigger, PlayerSeat: var seat } &&
        !_players[seat].IsHuman;

    private void ResolvePendingAiProgramTrigger()
    {
        var decision = _pendingDecision is { Kind: DecisionKind.ProgramTrigger } current
            ? current
            : throw new InvalidOperationException("The AI program prompt is unavailable.");
        PromptChoice selected;
        if (_resolutionStack.LastOrDefault() is ProgramSkillFrame frame)
        {
            var paused = ProgramInstructionResolver.Default
                .Resolve(frame, _contentRegistry!.GetSkill(frame.SkillId).Program!)
                .GetPausedInstruction(frame.InstructionIndex).Effect;
            selected = paused.Op switch
            {
                SkillProgramEffectOp.DrawThenDiscardDistinctCategories => SelectAiDrawDiscardCategory(decision, frame),
                SkillProgramEffectOp.OfferCurrentTurnHandExchange => SelectAiCurrentTurnHandExchange(decision, frame),
                SkillProgramEffectOp.DrawTwoThenDiscardTwoIfOverMaxHp => SelectAiProgramOwnCardDiscard(decision, frame),
                SkillProgramEffectOp.AddOneDistanceFreeCurrentUseTarget => SelectAiDesignatedExtraTargetChoice(decision, frame),
                SkillProgramEffectOp.ResolveUnequalHandHpEnding => SelectAiUnequalHandHp(decision, frame),
                SkillProgramEffectOp.RefillAndScheduleNextTurnSelfOnly => SelectAiEndRefillNextTurn(decision, frame),
                SkillProgramEffectOp.AdjustIncomingDistanceByLivingFactions or SkillProgramEffectOp.ChooseEndingCourtesyBenefits => SelectAiIncomingDistanceCourtesy(decision, frame),
                SkillProgramEffectOp.RecordNamedPrivateAmbush or SkillProgramEffectOp.NullifyMatchingHandUse => SelectAiNamedAmbush(decision, frame),
                SkillProgramEffectOp.ResolveDamageSourceHandChoice => SelectAiDamageSourceHandChoice(decision, frame),
                SkillProgramEffectOp.DiscardSameCategoryForExtraEffect or SkillProgramEffectOp.GuessRanksForDrawReplacement or SkillProgramEffectOp.DeathRecipientChooseSkill => SelectAiExtraEffectsAndRankGuess(decision, frame),
                SkillProgramEffectOp.DrawAndStoreTwoPublicRice or SkillProgramEffectOp.OfferRiceAfterDamagePoint => SelectAiRiceChoice(decision, frame),
                SkillProgramEffectOp.ProtectOtherSoleCardTarget => SelectAiSoleProtection(decision, frame),
                SkillProgramEffectOp.GrantOtherPlayUseRestriction or SkillProgramEffectOp.ChooseStartingEquipmentControl => SelectAiPhaseStartCardControl(decision, frame),
                SkillProgramEffectOp.AdjustTargetedOrdinaryTrick => SelectAiTargetedOrdinaryTrick(decision, frame),
                SkillProgramEffectOp.SelectOwnedHandRankSum => SelectAiOwnedHandRankSum(decision, frame),
                SkillProgramEffectOp.DiscardHandOrUseEquipment or SkillProgramEffectOp.MoveFieldEquipment =>
                    decision.Choices.First(),
                SkillProgramEffectOp.DonateAllEquipmentAndOfferRecipientBenefits => SelectAiEquipmentDonation(decision, frame),
                SkillProgramEffectOp.ChooseEquipmentOrDrawAfterOtherActualTurn => SelectAiActualEndedEquipment(decision, frame),
                SkillProgramEffectOp.DrawLostHpThenOfferOwnedCardsUpTo => SelectAiLostHpOwnedGift(decision, frame),
                SkillProgramEffectOp.ClaimGrantedPhaseSlash => SelectAiGrantedPhaseSlash(decision),
                SkillProgramEffectOp.ChoosePrivateColorsDiscardAndDuel => SelectAiDualColorChoice(decision, frame),
                SkillProgramEffectOp.DiscardSlashThenOtherCardAndUseDuel => SelectAiConditionalDuel(decision, frame),
                SkillProgramEffectOp.PayHpInspectHandThenDiscardOrSlash => SelectAiInspectedHand(decision, frame),
                SkillProgramEffectOp.UseSelectedForeignCardAsSlash => SelectAiSelectedForeignCardSlashChoice(decision, frame),
                SkillProgramEffectOp.DiscardEquipmentThenSlashAndOwnershipOutcome => SelectAiKuangfu(decision, frame),
                SkillProgramEffectOp.PlaceOwnedEquipmentThenResolveSlotBenefit => SelectAiPlacedEquipmentBenefit(decision, frame),
                SkillProgramEffectOp.PayOwnedCardOrMarker => SelectAiAlternativePhaseCost(decision, frame),
                SkillProgramEffectOp.ObtainDamageTargetCardAndResolveCategory => SelectAiDamageTargetObtain(decision, frame),
                SkillProgramEffectOp.OfferSameTypeDifferentNameOrExtraTarget => SelectAiSameTypeAid(decision, frame),
                SkillProgramEffectOp.DiscardDamageTargetAndClaimMount => SelectAiProgramOtherOwnedCardDiscard(decision, frame),
                SkillProgramEffectOp.ChooseOwnerHpLoss => SelectAiHpLossQuantity(decision),
                SkillProgramEffectOp.PayHpToGrantOneUseDamageShield => SelectAiHpDamageShield(decision),
                SkillProgramEffectOp.SuppressCurrentSlashTargetAndJudgeSuitDiscard => SelectAiSlashSuitDiscard(decision, frame),
                SkillProgramEffectOp.DiscardDistinctFactionParticipants => SelectAiDistinctFactionDiscard(decision,frame),
                SkillProgramEffectOp.ResolveDiscardBudgetParticipants or SkillProgramEffectOp.DiscardOutsideRangeAfterInsufficientUses or SkillProgramEffectOp.OfferCompletedFactionCostGift => decision.Choices[0],
                SkillProgramEffectOp.OfferRedDiscardRecoveryChoice => SelectAiRedDiscardRecovery(decision, frame),
                SkillProgramEffectOp.SelectRelativeZoneDemandTarget => decision.Choices[0],
                SkillProgramEffectOp.ExchangeOwnedCardThroughDeckEnd => decision.Choices[0],
                SkillProgramEffectOp.DrawPublicSuitThenEscalatingDiscard or SkillProgramEffectOp.DeclareNameForTargetDefense or SkillProgramEffectOp.DrawAndDraftLowHandPopulation => decision.Choices[0],
                SkillProgramEffectOp.ViewTopCardsAndObtainMatchingCards => decision.Choices[0],
                SkillProgramEffectOp.ChooseDifferentActionCategoryGift => decision.Choices[0],
                SkillProgramEffectOp.RequestFactionRecovery => SelectAiFactionRecovery(decision, frame),
                SkillProgramEffectOp.WeaponDiscardOrDamageBonus => SelectAiWeaponDamage(decision, frame),
                SkillProgramEffectOp.RevealSelectedHandAgainstTarget => decision.Choices[0],
                SkillProgramEffectOp.ChooseHandCountIntervention or SkillProgramEffectOp.RevealHandColorDiscardAndTake or
                    SkillProgramEffectOp.DrawThenPutOwnedCardOnTopParticipants or SkillProgramEffectOp.DrawTurnOwnerThenDiscardMaximumHandForDodge =>
                    SelectAiProgramHandControlChoice(decision, frame),
                SkillProgramEffectOp.SampleFactionSkills or SkillProgramEffectOp.ReplaceSkillsOnAwakening or
                    SkillProgramEffectOp.ObtainDeckRankSum or SkillProgramEffectOp.DamageAfterDeckShuffle or
                    SkillProgramEffectOp.EquipSampledGenerals or SkillProgramEffectOp.InheritWeapon or
                    SkillProgramEffectOp.BalanceHandAttackTricks or SkillProgramEffectOp.DamageFarthestCharacter =>
                    SelectAiAdvancedLifecycleChoice(decision, frame),
                SkillProgramEffectOp.ExchangePrivatePile or SkillProgramEffectOp.DiscardParticipantCards or
                    SkillProgramEffectOp.SpendMarkerOrLoseHp => decision.Choices[0],
                SkillProgramEffectOp.SelectDistinctSuitHandDiscards or SkillProgramEffectOp.SuppressGeneralSkill or SkillProgramEffectOp.SelectChainedByMarker or SkillProgramEffectOp.SelectOneSelectedTarget => decision.Choices[0],
                SkillProgramEffectOp.OfferOriginalTargetAddition => SelectAiOriginalTargetAddition(decision, frame),
                SkillProgramEffectOp.DiscardOwnedCardToAdjustCurrentDamage => SelectAiSignedDamagePayment(decision, frame),
                SkillProgramEffectOp.DiscardSuitPreventDamageAndBenefit => SelectAiSuitPreventionBenefit(decision, frame),
                SkillProgramEffectOp.RestoreActualDiscardBatch => SelectAiActualDiscardRecovery(decision, frame),
                SkillProgramEffectOp.GiveAfterBatchGain => SelectAiGainGift(decision, frame),
                SkillProgramEffectOp.GiveSameCategoryFromDeck => SelectAiActualHandGain(decision, frame),
                SkillProgramEffectOp.PlaceMatchedJudgmentCard => SelectAiMatchedJudgmentPlacement(decision, frame),
                SkillProgramEffectOp.PayCompletedUseDiscardOrLoseHp => SelectAiCompletedUsePayment(decision),
                SkillProgramEffectOp.OfferShortRangeSlashTarget => SelectAiShortRangeSlash(decision, frame),
                SkillProgramEffectOp.BeginPhaseNamePrediction or SkillProgramEffectOp.SettlePhaseNamePrediction => decision.Choices[0],
                SkillProgramEffectOp.BeginFriendPrediction or SkillProgramEffectOp.ObserveFriendPrediction or SkillProgramEffectOp.ReclaimFriendXuanjian or SkillProgramEffectOp.GainFriendCategoryMark => SelectAiFriendTrioChoice(decision, frame),
                SkillProgramEffectOp.ExchangeFriendGainForDiscard or SkillProgramEffectOp.UseFriendDeckSuitsAtPlayEnd => SelectAiFriendPangTongChoice(decision, frame),
                SkillProgramEffectOp.LastDamageSourceReciprocity => SelectAiLastDamageSourceReciprocity(decision, frame),
                SkillProgramEffectOp.RecastMatchingCardsThenPeerChoice => SelectAiMatchingRecast(decision, frame),
                SkillProgramEffectOp.PairedHandRecast => SelectAiPairedHandRecast(decision, frame),
                SkillProgramEffectOp.DrawAfterActualOutsideDraw or SkillProgramEffectOp.DiscardAfterActualOutsideDiscard => SelectAiOutsidePhaseDrawDiscard(decision, frame),
                SkillProgramEffectOp.OfferOriginalHandLossBenefit or SkillProgramEffectOp.InheritOriginalHandBonuses => SelectAiOriginalHandEntityChoice(decision, frame),
                SkillProgramEffectOp.OfferPairedColorCardDisposition => SelectAiPairedColorDisposition(decision, frame),
                SkillProgramEffectOp.OfferUniqueLargestHandTrickTargetAddition or
                    SkillProgramEffectOp.JoinUniqueLargestHpTrickTargetAndDrawAfterDamage => SelectAiUniqueLeaderTrickTargetChoice(decision, frame),
                SkillProgramEffectOp.AdjustOneRoundGainedOrdinaryTrickTarget => SelectAiRoundGainedTrickTargetChoice(decision, frame),
                SkillProgramEffectOp.OfferSameNameHandDiscardOrDamage => SelectAiSameNameHandDiscardOrDamage(decision, frame),
                SkillProgramEffectOp.AllocateCurrentTurnDefaultStats => decision.Choices[0],
                SkillProgramEffectOp.GiveHandAndGrantCategoryMark or SkillProgramEffectOp.SpendCategoryMarkForDyingRecovery or
                    SkillProgramEffectOp.SpendCategoryMarkForAreaDiscard or SkillProgramEffectOp.SpendCategoryMarkForSlashTargets => SelectAiRecipientCategoryMarkChoice(decision, frame),
                SkillProgramEffectOp.GiveOffTurnUsedCards => SelectAiOffTurnUsedCardGift(decision),
                SkillProgramEffectOp.RevealUndamagedUseTargetHandAndDiscardSameColor => SelectAiCompletedUndamagedTargetReveal(decision, frame),
                SkillProgramEffectOp.SettleFixedDistanceOneEndingDebt => SelectAiFixedDistanceDebt(decision),
                SkillProgramEffectOp.UseRoundPricedPileDyingAlcohol => decision.Choices.First(c => c.Parameters.GetValueOrDefault("branch") != "pass"),
                SkillProgramEffectOp.OfferCurrentSlashFireAndExtraTarget => decision.Choices[0],
                SkillProgramEffectOp.OfferCompletedCardGift or SkillProgramEffectOp.ApplyCurrentCardEnhancements or
                    SkillProgramEffectOp.PayEquipmentColorDiscard or SkillProgramEffectOp.AddCurrentCardUseTarget => decision.Choices[0],
                SkillProgramEffectOp.AlternatingSuitDrawDiscard or SkillProgramEffectOp.FirstCategoryCompletedTop => decision.Choices[0],
                SkillProgramEffectOp.DiscardNonFinalTargetCardThenDraw or SkillProgramEffectOp.DiscardHandToNamedTurnCount => decision.Choices[0],
                SkillProgramEffectOp.InitializePrivateGeneralLibrary or SkillProgramEffectOp.AcquirePrivateGeneralAvatar or SkillProgramEffectOp.ChoosePrivateGeneralAvatar => decision.Choices[0],
                SkillProgramEffectOp.ResolveFirstGameDomainCrossing or SkillProgramEffectOp.StoreArbitraryOwnedPublicPile or SkillProgramEffectOp.UsePublicPileEquipmentSequence => SelectAiDomainChoice(decision,frame),
                SkillProgramEffectOp.PublicPileColorDamage or SkillProgramEffectOp.RewardDiscardedActionColor => SelectAiPublicPileColorChoice(decision,frame),
                SkillProgramEffectOp.PeekTurnQuotaTop or SkillProgramEffectOp.UseDiamondDelayedOrDiscard => decision.Choices[0],
                SkillProgramEffectOp.CompareSelectedHandWithHpHand => decision.Choices[0],
                SkillProgramEffectOp.OfferFaceUpForOutsideClaims => decision.Choices[0],
                SkillProgramEffectOp.ChooseOption => SelectAiProgramOption(decision, frame),
                SkillProgramEffectOp.MouZhitianView or SkillProgramEffectOp.MouZhijueUse => decision.Choices[0],
                SkillProgramEffectOp.ReturnIssuedPhaseHandDebt => SelectAiPhaseHandDebt(decision, frame),
                SkillProgramEffectOp.OfferHalfHandRecipientSupport => SelectAiHalfHandSupport(decision, frame),
                SkillProgramEffectOp.ObtainOneFromEachSelectedTarget or SkillProgramEffectOp.GiveShownCardToLeastOriginalTarget => SelectAiPairBenefit(decision, frame),
                SkillProgramEffectOp.ChooseCategoryOrSequentialDiscard or SkillProgramEffectOp.EscalatingDiscardOrDamageFromSelected =>
                    SelectAiSequentialDiscard(decision, frame),
                SkillProgramEffectOp.ChooseCategoryAlternativeDiscard or SkillProgramEffectOp.EscalatingDiscardOrDamage =>
                    SelectAiProgramDiscardChallenge(decision, frame),
                SkillProgramEffectOp.PutDiscardedCardsOnDrawPileTop or SkillProgramEffectOp.PutOwnOrPreviousFirstDiscardOnTop => decision.Choices[0],
                SkillProgramEffectOp.CollectPublicPile => decision.Choices.OrderByDescending(choice => choice.Targets.Count).First(),
                SkillProgramEffectOp.ChooseDifferentCategoryDiscard =>
                    SelectAiProgramCategoryDiscard(decision, frame),
                SkillProgramEffectOp.ChooseOtherOwnedCardDiscard =>
                    SelectAiProgramOtherOwnedCardDiscard(decision, frame),
                SkillProgramEffectOp.RestorePhaseHandDiscards =>
                    SelectAiProgramPhaseHandDiscardRestore(decision, frame),
                SkillProgramEffectOp.ChooseOwnCardDiscard =>
                    SelectAiProgramOwnCardDiscard(decision, frame),
                SkillProgramEffectOp.DiscardDrawAndOfferUniqueHpPeer or SkillProgramEffectOp.GiveAllHandAndStartRecipientPindian => SelectAiRecipientContest(decision, frame),
                SkillProgramEffectOp.StoreNonBasicOwnedPublicPile or SkillProgramEffectOp.RemovePublicPileAfterAttackDamage or SkillProgramEffectOp.ResolvePreparationPublicPile => SelectAiPublicPilePreparation(decision, frame),
                SkillProgramEffectOp.GiveBlackHandAndResolveRecipientContest or SkillProgramEffectOp.RaiseMaximumRecoverAndQualifyPrintedLord => SelectAiRecipientConsequences(decision, frame),
                SkillProgramEffectOp.SelectEquipmentPairAndPayment => SelectAiEquipmentPairPayment(decision, frame),
                SkillProgramEffectOp.SelectDyingOwnedCard => SelectAiDyingOwnedCard(decision),
                SkillProgramEffectOp.SelectOwnedCards or SkillProgramEffectOp.ResolveDeferredHandAlignment or SkillProgramEffectOp.SelectTurnDamageUseDebtPayment or SkillProgramEffectOp.SelectFrozenHandExchangeDebtPayment => SelectAiProgramOwnedCards(decision, frame),
                SkillProgramEffectOp.DrawThenDiscardHandToMaximumHp => decision.Choices[0],
                SkillProgramEffectOp.HoldTargetCards => SelectAiProgramHoldCards(decision, frame),
                SkillProgramEffectOp.ResolvePrepDiscardOrEnding => SelectAiPrepDiscard(decision, frame),
                SkillProgramEffectOp.RequireTargetDiscardOrEquipmentRecast => SelectAiTargetPenalty(decision, frame),
                SkillProgramEffectOp.OfferSlashTargetBenefit or SkillProgramEffectOp.SettleDodgeCancelledSlashBenefit => SelectAiSlashTargetBenefit(decision, frame),
                SkillProgramEffectOp.ResolveDeferredPrivateCardOffer or SkillProgramEffectOp.ResolveGameTargetHandHpChoice => decision.Choices[0],
                SkillProgramEffectOp.DiscardTargetHpCardsAndDamage => decision.Choices[0],
                SkillProgramEffectOp.RequestSlashByTarget => SelectAiProgramRequestSlash(decision, frame),
                SkillProgramEffectOp.UseOwnerSlashAgainstTurnOwner or SkillProgramEffectOp.DeclareDeckCriterionAndGiveMatchingCard =>
                    SelectAiFixedSlashAndDeclaredDeck(decision, frame),
                SkillProgramEffectOp.RequestSlashByNearest => SelectAiProgramRequestSlashByNearest(decision),
                SkillProgramEffectOp.JudgeDamageTargetThenOfferSuitDiscard => SelectAiDamageJudgmentSuitPayment(decision),
                SkillProgramEffectOp.RequestLegalSlashByNearest => SelectAiNearestLegalSlash(decision),
                SkillProgramEffectOp.OfferUnlimitedVirtualSlash => SelectAiUnlimitedSlash(decision),
                SkillProgramEffectOp.DiscardSelectedParticipantCards or SkillProgramEffectOp.OfferBoundCardsForDamagePrevention => decision.Choices[0],
                SkillProgramEffectOp.OfferVirtualSlashOrDraw or SkillProgramEffectOp.OfferVirtualBasicCard => decision.Choices[0],
                SkillProgramEffectOp.GiveBoundCardThenOfferVirtualSlashOrSharedDraw => SelectAiSharedSlashOffer(decision, frame),
                SkillProgramEffectOp.RequestSlashAgainstChosenTarget or SkillProgramEffectOp.TakeSelectedTargetCards => decision.Choices[0],
                SkillProgramEffectOp.ViewAndTakeSelectedTargetHand or SkillProgramEffectOp.RequestHandBySuitsOrLoseHp => SelectAiParticipantHandChoice(decision, frame),
                SkillProgramEffectOp.RevealTargetHandCard => decision.Choices
                    .OrderBy(choice => choice.Id.Value, StringComparer.Ordinal).First(),
                SkillProgramEffectOp.DistributeOwnedCards =>
                    SelectAiProgramOwnedCardDistribution(decision, frame),
                SkillProgramEffectOp.GiveOwnedCardToOtherFinalTargetAndDraw or SkillProgramEffectOp.CollectFinalTargetCardInPublicPile or SkillProgramEffectOp.ObtainPublicPileCard or SkillProgramEffectOp.DiscardPublicZoneAfterHandPayment => decision.Choices[0],
                SkillProgramEffectOp.ExchangePublicPileHand or SkillProgramEffectOp.ExchangePublicPile or SkillProgramEffectOp.DistributePublicPileIfAllSuits =>
                    SelectAiPublicPileChoice(decision, frame),
                SkillProgramEffectOp.RequestAttackRangeAid =>
                    SelectAiProgramAttackRangeAid(decision, frame),
                SkillProgramEffectOp.SelectCardSubset
                    when paused.AiOrder == SkillProgramSubsetAiOrder.MostCardsThenRankSum =>
                    decision.Choices
                        .OrderByDescending(choice => choice.Cards.Count)
                        .ThenByDescending(choice => int.Parse(
                            choice.Parameters.GetValueOrDefault("rank-sum", "0"),
                            System.Globalization.CultureInfo.InvariantCulture))
                        .ThenBy(choice => choice.Id.Value, StringComparer.Ordinal)
                        .First(),
                SkillProgramEffectOp.MoveBoundCards
                    when paused.Destination == SkillProgramCardDestination.DrawPileBottom =>
                    decision.Choices.OrderBy(choice => choice.Id.Value, StringComparer.Ordinal).First(),
                SkillProgramEffectOp.SelectTargets when paused.TargetAiOrder is { } targetAiOrder =>
                    SelectAiProgramTargets(decision, targetAiOrder),
                SkillProgramEffectOp.SelectTarget =>
                    SelectAiCompositionTarget(decision, frame),
                SkillProgramEffectOp.SelectAndMoveOwnedCard when paused.CoverageResultBind is not null =>
                    decision.Choices.OrderByDescending(choice => choice.Cards.Count == 1 &&
                        WouldEquipmentRemovalReduceCoverage(
                            ResolveProgramParticipant(frame, paused.CardOwnerRef!), choice.Cards[0]))
                        .ThenBy(choice => choice.Id.Value, StringComparer.Ordinal).First(),
                SkillProgramEffectOp.SelectSourceCard or SkillProgramEffectOp.SelectAndMoveOwnedCard or
                    SkillProgramEffectOp.GiveBoundCard => decision.Choices[0],
                SkillProgramEffectOp.UseAllHandCardsAsOrdinaryTrick => decision.Choices
                    .OrderBy(choice => choice.Parameters.GetValueOrDefault("card-kind") == nameof(CardKind.DrawTwo) ? 0 : 1)
                    .ThenBy(choice => choice.Id.Value, StringComparer.Ordinal)
                    .First(),
                SkillProgramEffectOp.UseVirtualOrdinaryTrick => decision.Choices[0],
                SkillProgramEffectOp.ConfigureFriendDuelCategories or SkillProgramEffectOp.ConfigureFriendUseSuits => decision.Choices[0],
                SkillProgramEffectOp.DrawThenDiscardSuitsForDyingPeach => SelectAiDyingSuits(decision, frame),
                SkillProgramEffectOp.UseOwnPlayHistoryAtEnding => SelectAiHistoricalEndingUse(decision, frame),
                SkillProgramEffectOp.YanjiaoSplitRevealedCards => SelectAiYanjiaoSplit(decision, frame),
                SkillProgramEffectOp.TunanUseRevealedCard => SelectAiTunanChoice(decision),
                SkillProgramEffectOp.DaoshuGuessAndTake => SelectAiDaoshuChoice(decision),
                SkillProgramEffectOp.ZhirenResolveFieldTiers => SelectAiZhirenFieldChoice(decision),
                SkillProgramEffectOp.BijingPunishDiscardPhase => decision.Choices
                    .OrderBy(choice => choice.Id.Value, StringComparer.Ordinal).First(),
                SkillProgramEffectOp.YoudiBaitDiscard => SelectAiYoudiBaitChoice(decision),
                SkillProgramEffectOp.GuanchaoChoosePattern => SelectAiGuanchaoPatternChoice(decision),
                SkillProgramEffectOp.XunxianGiftUsedCard => SelectAiXunxianGiftChoice(decision),
                SkillProgramEffectOp.ZecaiRoundSettlement => SelectAiZecaiChoice(decision),
                SkillProgramEffectOp.JuanxiaDeclareTricks or SkillProgramEffectOp.JuanxiaRetaliation =>
                    SelectAiJuanxiaChoice(decision),
                SkillProgramEffectOp.ZhuLingZhanyiChooseCategory => SelectAiZhanyiCategoryChoice(decision),
                SkillProgramEffectOp.ZhuLingZhanyiEquipmentPunish => SelectAiZhanyiPunishChoice(decision),
                SkillProgramEffectOp.FengjiRoundChoice => SelectAiFengjiChoice(decision),
                SkillProgramEffectOp.ChangjiEndingDamageChoice => SelectAiChangjiEndingChoice(decision),
                SkillProgramEffectOp.ZengouNullifyDodge => SelectAiZengouCostChoice(decision),
                SkillProgramEffectOp.ZhuihuanArm => SelectAiZhuihuanArmChoice(decision),
                SkillProgramEffectOp.TongxieArm => SelectAiTongxieArmChoice(decision),
                SkillProgramEffectOp.TongxieFollowUp => SelectAiTongxieFollowUpChoice(decision),
                SkillProgramEffectOp.TongxieGuard => SelectAiTongxieGuardChoice(decision),
                SkillProgramEffectOp.KanggeChooseTarget => SelectAiKanggeChooseChoice(decision),
                SkillProgramEffectOp.KanggeHealVictim => SelectAiKanggeHealChoice(decision),
                SkillProgramEffectOp.JieliePreventAndGift => SelectAiJielieSuitChoice(decision, frame),
                SkillProgramEffectOp.QiaoliWeaponDamageDraw => SelectAiQiaoliDistributionChoice(decision),
                SkillProgramEffectOp.QingliangChooseOption => SelectAiQingliangChoice(decision),
                SkillProgramEffectOp.LuochongResolve => SelectAiLuochongResolveChoice(decision),
                SkillProgramEffectOp.AichenRemoveOption => SelectAiAichenRemoveChoice(decision),
                SkillProgramEffectOp.YujueResolve => SelectAiYujueChoice(decision),
                SkillProgramEffectOp.YuanziDamageDraw => SelectAiYuanziDamageDrawChoice(decision),
                SkillProgramEffectOp.LiejieSourceDiscard => SelectAiLiejieSourceDiscardChoice(decision),
                SkillProgramEffectOp.ZhuitaoMarkTarget => SelectAiZhuitaoMarkChoice(decision),
                _ => throw new InvalidOperationException(
                    $"The AI does not support suspended program instruction '{paused.Op}'.")
            };
        }
        else
        {
            selected = SelectAiProgramActivation(decision);
        }
        ResolveProgramTriggerChoice(selected);
        AdvanceRulesAndPublishState();
    }

    private PromptChoice SelectAiProgramActivation(PendingDecision decision)
    {
        var activateChoices = decision.Choices.Where(choice =>
            choice.Parameters.GetValueOrDefault("program-action") == "activate").ToArray();
        var skip = decision.Choices.SingleOrDefault(choice =>
            choice.Parameters.GetValueOrDefault("program-action") == "skip");
        if (activateChoices.Length > 1)
            return SelectAiProgramChoiceGroup(decision, activateChoices, skip);
        var pendingContext = GetPendingProgramTriggerCandidate().Context;
        if (GetProgramTrigger(GetPendingProgramTriggerCandidate().Candidate).Effects is [{ Op: SkillProgramEffectOp.OfferRiceAfterDamagePoint }])
            return activateChoices.Single();
        if (pendingContext.OptionalChooserSeat is not null)
        {
            var (choice, thought) = _aiBrains[decision.PlayerSeat].ChooseOptionalBeneficiaryDraw(CreateSnapshot(decision.PlayerSeat), decision.Choices, pendingContext.OwnerSeat, _thoughtSequence++);
            AddThought(thought);
            return decision.Choices.Single(c => c.Id == choice);
        }
        var activate = activateChoices.Single();
        if (skip is null) return activate;

        var skillId = activate.Parameters["skill-id"];
        var bindingId = activate.Parameters["binding-id"];
        var skillInstanceId = activate.Parameters["skill-instance-id"];
        var skill = _contentRegistry!.GetSkill(skillId);
        var trigger = ProgramInstructionResolver.Default.Resolve(skill.Program!,
            ProgramInstructionSourceKind.Trigger, bindingId).Trigger!;
        var owner = _players[decision.PlayerSeat];
        var publicContext = WithPhaseHandExtraTurnTargetPricing(
            WithProgramConditionFacts(CreateProgramAiPublicContext(trigger, owner, decision.PlayerSeat),
                owner, skillId, skillInstanceId), skill.Program!, trigger);
        var estimate = EstimateCompositionForAi(owner, trigger.Effects, publicContext,
            windowContext: pendingContext).Estimate;
        estimate = IncludePhaseHandExtraTurnDeclarationForAi(estimate, owner, skillId, skillInstanceId,
            skill.Program!, trigger, publicContext, pendingContext);
        var shouldActivate = !estimate.IsSelfLethal && estimate.Score > 0d;
        var activateAction = new LegalAction(
            LegalActionKind.UseProgramSkill, null, null, $"发动【{skill.Name}】");
        var skipAction = new LegalAction(
            LegalActionKind.UseProgramSkill, null, null, $"跳过【{skill.Name}】");
        var candidates = new[]
        {
            new AiCandidateScore(activateAction,
                shouldActivate ? estimate.Score : Math.Min(estimate.Score, -1000d),
                estimate.IsSelfLethal ? "公开效果将令自身失去全部体力。" : estimate.Approximation),
            new AiCandidateScore(skipAction, 0d, "保留当前状态。")
        };
        AddThought(new AiThoughtRecord(
            _thoughtSequence++, _turnNumber, decision.PlayerSeat,
            shouldActivate ? activateAction.Description : skipAction.Description,
            candidates.OrderByDescending(candidate => candidate.Score).ToArray(),
            $"组合估值 {estimate.Score:0.##}；{estimate.Approximation}"));
        return shouldActivate ? activate : skip;
    }

    private PromptChoice SelectAiProgramChoiceGroup(
        PendingDecision decision,
        IReadOnlyList<PromptChoice> activateChoices,
        PromptChoice? skip)
    {
        var parentOwnerSeat = _resolutionStack.LastOrDefault() switch
        {
            ProgramLifecycleTriggerWindowFrame lifecycle => lifecycle.Candidates[lifecycle.CandidateIndex].OwnerSeat,
            PlayPhaseStartingBoundaryFrame starting when starting.Items
                .Skip(starting.ItemIndex)
                .Any(item => item.Candidate?.OwnerSeat == decision.PlayerSeat) => decision.PlayerSeat,
            _ => -1
        };
        if (parentOwnerSeat != decision.PlayerSeat)
            throw new InvalidOperationException("A program choice group lost its lifecycle parent.");
        var owner = _players[decision.PlayerSeat];
        var estimated = activateChoices.Select(choice =>
        {
            var skill = _contentRegistry!.GetSkill(choice.Parameters["skill-id"]);
            var trigger = ProgramInstructionResolver.Default.Resolve(skill.Program!,
                ProgramInstructionSourceKind.Trigger, choice.Parameters["binding-id"]).Trigger!;
            var candidateContext = GetPendingProgramTriggerCandidate().Context;
            var publicContext = WithPhaseHandExtraTurnTargetPricing(
                WithProgramConditionFacts(CreateProgramAiPublicContext(trigger, owner, decision.PlayerSeat),
                    owner, choice.Parameters["skill-id"], choice.Parameters["skill-instance-id"]), skill.Program!, trigger);
            var estimate = EstimateCompositionForAi(owner, trigger.Effects, publicContext,
                windowContext: candidateContext).Estimate;
            estimate = IncludePhaseHandExtraTurnDeclarationForAi(estimate, owner, choice.Parameters["skill-id"],
                choice.Parameters["skill-instance-id"], skill.Program!, trigger, publicContext, candidateContext);
            var action = new LegalAction(LegalActionKind.UseProgramSkill, null, null,
                $"发动【{skill.Name}】");
            return (Choice: choice, Action: action, Estimate: estimate);
        }).OrderByDescending(item => item.Estimate.IsSelfLethal ? double.NegativeInfinity : item.Estimate.Score)
            .ThenBy(item => item.Choice.Id.Value, StringComparer.Ordinal).ToArray();
        var best = estimated[0];
        var activate = skip is null || !best.Estimate.IsSelfLethal && best.Estimate.Score > 0d;
        var skipAction = new LegalAction(LegalActionKind.UseProgramSkill, null, null, "跳过组合技能分支");
        var candidates = estimated.Select(item => new AiCandidateScore(
            item.Action, item.Estimate.IsSelfLethal ? -1000d : item.Estimate.Score,
            item.Estimate.IsSelfLethal ? "公开效果将令自身失去全部体力。" : item.Estimate.Approximation));
        if (skip is not null)
            candidates = candidates.Append(new AiCandidateScore(skipAction, 0d, "保留当前状态。"));
        AddThought(new AiThoughtRecord(
            _thoughtSequence++, _turnNumber, decision.PlayerSeat,
            activate ? best.Action.Description : skipAction.Description,
            candidates.OrderByDescending(candidate => candidate.Score).ToArray(),
            "互斥组使用同一操作目录与公开上下文估值。"));
        return activate ? best.Choice : skip!;
    }

    private ProgramAiPublicContext CreateProgramAiPublicContext(
        SkillProgramTrigger trigger,
        CharacterState owner,
        int ownerSeat)
    {
        if (trigger.Window == SkillProgramTriggerWindow.TurnEnding &&
            trigger.Effects.Any(e => e.Op == SkillProgramEffectOp.DrawEndingPairThenBlockRoundIfUnequal))
            return CreateAttributedPaymentAiContext(owner, trigger) with
            { Actor = CreateSkillContext(_players[_currentSeat]), SelectedTarget = CreateSkillContext(_players[_currentSeat]),
              CardActionActorIsOwner = _currentSeat == ownerSeat };
        if (trigger.Window == SkillProgramTriggerWindow.OtherActualUseTargeted &&
            _resolutionStack.OfType<ActualUseTargetWindowFrame>().LastOrDefault() is { } actualTargets &&
            actualTargets.Contexts[actualTargets.CandidateIndex].ActualUseTarget is { } actualUse)
            return CreateAttributedPaymentAiContext(owner, trigger) with { CardUseEffectiveKind = actualUse.EffectiveKind };
        if (ProgramInstructionResolver.Default.Features(trigger).HasOperation(SkillProgramEffectOp.PayHpToGrantOneUseDamageShield))
            return CreateAttributedPaymentAiContext(owner, trigger) with { HpDamageShieldTargetValue = GetHpDamageShieldAiTargetValue(owner) };
        if (trigger.Effects.Any(effect => effect.Op == SkillProgramEffectOp.PeekTurnQuotaTop))
            return CreateAttributedPaymentAiContext(owner,trigger) with { TurnCriterionQuota = ComputeTurnCriterionQuota(owner.Seat) };
        if (trigger.Window is SkillProgramTriggerWindow.CardUseCommitted or
            SkillProgramTriggerWindow.CardUseBeforeTargetEffects or
            SkillProgramTriggerWindow.CardUseTargetsFinalized or SkillProgramTriggerWindow.CardResponseAccepted or SkillProgramTriggerWindow.CardResponseCompleted or SkillProgramTriggerWindow.CardSupplyCompleted or
            SkillProgramTriggerWindow.CardUseCompleted or
            SkillProgramTriggerWindow.SlashTargetRedirecting or
            SkillProgramTriggerWindow.SlashBeforeResponse or
            SkillProgramTriggerWindow.SlashFullyDodged)
        {
            var parent = _resolutionStack.OfType<ProgramCardTriggerWindowFrame>().LastOrDefault() ??
                throw new InvalidOperationException("A card-action estimate lost its frozen parent action.");
            var suits = parent.Action.PhysicalCards.Select(cost =>
            {
                var location = _cardZones.GetLocation(cost.CardId);
                return _cardZones.CardsAt(location).Single(card => card.Id == cost.CardId).Suit;
            }).ToArray();
            return CreateAttributedPaymentAiContext(owner,trigger) with
            {
                CardUseIsRed = suits.Length == 0 ? null : suits.All(suit => suit is Suit.Heart or Suit.Diamond),
                Actor = CreateSkillContext(_players[parent.Action.ActorSeat]),
                CardActionActorIsOwner = parent.Action.ActorSeat == ownerSeat,
                CardUseEffectiveKind = parent.Action.EffectiveKind,
                CardEffectInterventionScore = parent.Action.Type == CardActionType.Use &&
                    (ProgramInstructionResolver.Default.Features(trigger).HasOperation(SkillProgramEffectOp.NullifySelectedCardEffects) ||
                     ProgramInstructionResolver.Default.Features(trigger).HasOperation(SkillProgramEffectOp.RemoveSelectedCurrentArrowBarrageTarget))
                    ? parent.Action.EffectiveDesignatedTargetSeats.Distinct()
                        .Where(seat => _players[seat].IsAlive &&
                            _resolutionStack.OfType<CardUseFrame>()
                                .Single(item => item.Id == parent.ParentFrameId)
                                .IneffectiveTargetSeats?.Contains(seat) != true)
                        .Select(seat => Math.Max(0d, _aiBrains[ownerSeat].ScoreCardEffectIntervention(
                            CreateSnapshot(ownerSeat), parent.Action.EffectiveKind, seat)))
                        .Aggregate(0d, (total, score) => ProgramInstructionResolver.Default.Features(trigger).HasOperation(SkillProgramEffectOp.RemoveSelectedCurrentArrowBarrageTarget) ? Math.Max(total, score) : total + score)
                    : 0d,
                PairedColorDispositionScore = GetPairedColorDispositionAiScore(trigger, ownerSeat, parent),
                CardUseDebitActive = IsCardUseDebitActive(parent.Action.ActionId)
            };
        }
        if (trigger.Window != SkillProgramTriggerWindow.DrawPhaseStarting)
            return CreateAttributedPaymentAiContext(owner,trigger);
        if (_resolutionStack.LastOrDefault() is not ProgramLifecycleTriggerWindowFrame drawPhase ||
            drawPhase.Window != SkillProgramTriggerWindow.DrawPhaseStarting ||
            drawPhase.OwnerSeat != ownerSeat && !ProgramInstructionResolver.Default.Features(trigger).HasOperation(SkillProgramEffectOp.AddMarkerSubjectNormalDraw))
            throw new InvalidOperationException("A draw-phase estimate lost its lifecycle parent.");
        return CreateAttributedPaymentAiContext(owner,trigger) with
        {
            NormalDrawCount = checked((drawPhase.FrozenBaseDrawCount ?? GetTurnDrawCount(_players[drawPhase.OwnerSeat])) +
                drawPhase.NormalDrawAdjustment),
            EligibleTargetCount = ProgramInstructionResolver.Default.Features(trigger)
                .First(SkillProgramEffectOp.SelectTargets)?.TargetKind is { } targetKind
                ? GetProgramTargetSeats(ownerSeat, targetKind).Count : 0,
            ReplacesNormalDraw = trigger.DrawPhaseMode == SkillProgramDrawPhaseMode.Replacement
        };
    }

    private ProgramAiPublicContext CreateProgramAiPublicContext(CharacterState owner) =>
        new(GetLivingFactionCount(), CanUseSlashOnOther:
            !HasTurnCardTargetRestriction(owner.Seat, SkillProgramCardTargetRestriction.SelfOnly) &&
            new[] { CardKind.Slash, CardKind.FireSlash, CardKind.ThunderSlash }
                .Any(kind => !IsCardUseForbidden(owner.Seat, kind, CardActionType.Use)),
            AttackRange: GetAttackRange(owner.Seat),
            AttackRangeCoverageDecreased: _ => _players.Where(player => player.IsAlive && player.Seat != owner.Seat)
                .Any(player => GetEquipment(player).Any(card =>
                    WouldEquipmentRemovalReduceCoverage(player.Seat, card.Id))),
            LivingPlayersMinHp: GetLivingPlayersMinHp(),
            TurnOwnerDiscardPhaseHandDiscardCount: TurnOwnerDiscardPhaseHandDiscardCount,
            CurrentTurnUsedCardCategoryCount: TracksCurrentTurnUseKinds ? CurrentTurnUseKinds(owner.Seat).Categories : null,
            PublicLivingFactionCount: TracksTurnDrawDebt ? GetPublicLivingFactionCount() : null,
            EquipmentCardCount: GetEquipment(owner).Count);

    private ProgramAiPublicContext WithProgramConditionFacts(ProgramAiPublicContext context,
        CharacterState owner, string skillId, string skillInstanceId)
    {
        var cardFrame = _resolutionStack.OfType<ProgramCardTriggerWindowFrame>().LastOrDefault();
        var cardFacts = cardFrame is not null && cardFrame.CandidateIndex < cardFrame.Candidates.Count
            ? cardFrame.Candidates[cardFrame.CandidateIndex].FrozenContext?.Facts
            : null;
        var ending = _resolutionStack.OfType<TurnEndingBoundaryFrame>().LastOrDefault();
        var endingFacts = ending is not null && ending.ItemIndex < ending.Items.Count
            ? ending.Items[ending.ItemIndex].Facts ?? ending.Facts : null;
        var movementFrame = _resolutionStack.OfType<CardsMovedTriggerWindowFrame>().LastOrDefault();
        var movementContext = movementFrame is not null && movementFrame.Contexts is {} contexts && movementFrame.CandidateIndex < contexts.Count
            ? contexts[movementFrame.CandidateIndex] : null;
        var movementFacts = movementContext?.OwnerSeat == owner.Seat && movementContext.Window == SkillProgramTriggerWindow.CardsMoved
            ? movementContext.Facts : null;
        var effectFrame = _resolutionStack.OfType<CardEffectBeforeApplyFrame>().LastOrDefault();
        var effectFacts = effectFrame is not null && effectFrame.CandidateIndex < effectFrame.Candidates.Count
            ? effectFrame.Candidates[effectFrame.CandidateIndex].FrozenContext?.Facts : null;
        var facts = _resolutionStack.OfType<ProgramLifecycleTriggerWindowFrame>().LastOrDefault()?.Facts ??
            endingFacts ?? movementFacts ?? effectFacts ?? cardFacts;
        return context with
        {
            EventMovedCardCount = movementFacts?.MovedCardCount,
            BooleanState = stateId => facts is null
                ? GetProgramBooleanState(owner.Seat, skillId, skillInstanceId, stateId)
                : facts.GetBooleanState(skillId, skillInstanceId, stateId)
        };
    }

    private (ProgramAiEstimate Estimate, int? TargetSeat) EstimateCompositionForAi(
        CharacterState owner, IEnumerable<SkillProgramEffect> sourceEffects,
        ProgramAiPublicContext publicContext, IReadOnlyList<int>? publishedTargets = null,
        ProgramSkillWindowContext? windowContext = null)
    {
        var effects = sourceEffects.ToArray();
        if (effects.Any(e => e.Op is SkillProgramEffectOp.ResolveUnequalHandHpEnding or SkillProgramEffectOp.AdjustTargetedOrdinaryTrick))
            publicContext = publicContext with { TargetedTrickHandHpScore = GetTargetedTrickHandHpPublicScore(owner.Seat, effects, windowContext) };
        if (effects.Any(e => e.Op == SkillProgramEffectOp.RefillAndScheduleNextTurnSelfOnly))
            publicContext = publicContext with { EndRefillNextTurnScore = EndRefillNextTurnPublicScore(owner.Seat) };
        if (effects.Any(e => e.Op == SkillProgramEffectOp.UsePhaseOwnerVirtualAlcohol) &&
            windowContext is { Window: SkillProgramTriggerWindow.PlayPhaseStarting, SourceSeat: { } wineActor })
            publishedTargets = [wineActor];
        if (effects.Any(e => e.NumberExpression == SkillProgramNumberExpression.ActualTurnDeathBenefits) &&
            windowContext is { Window: SkillProgramTriggerWindow.AfterTurnEnded,
                Facts: { ActualTurnDeathCount: { } deaths, OwnerActualTurnKillCount: { } kills } })
            publicContext = publicContext with { ActualTurnDeathBenefits = checked(deaths + 2 * kills) };
        publishedTargets ??= PublishedFixedRecipientForAi(owner, effects, windowContext);
        publishedTargets ??= PublishedEndingPairActorForAi(owner, effects, windowContext);
        if (publishedTargets is null && effects.Any(effect => effect.Op == SkillProgramEffectOp.YuanziResolve) &&
            windowContext is { Window: SkillProgramTriggerWindow.TurnStartBeforeNormalFlow,
                SourceSeat: { } yuanziTurnSeat } && yuanziTurnSeat != owner.Seat)
            publishedTargets = [yuanziTurnSeat];
        if (publishedTargets is null && effects.Any(effect => effect.Op == SkillProgramEffectOp.GrantTurnSkills &&
                effect.TargetReference is { Kind: ProgramParticipantRef.Actor }) &&
            windowContext?.CardUse is { } grantedUse)
            publishedTargets = [grantedUse.ActorSeat];
        if (effects.Any(effect => effect.Op is SkillProgramEffectOp.RecoverOtherDyingVictimTo or SkillProgramEffectOp.SelectDyingOwnedCard) &&
            windowContext is { Window: SkillProgramTriggerWindow.DyingEntering, TargetSeat: { } dyingVictim })
            publishedTargets = [dyingVictim];
        if (effects.Any(e => e.Op == SkillProgramEffectOp.ObtainDamageTargetCardAndResolveCategory) && windowContext?.TargetSeat is { } obtainTarget)
            publishedTargets = [obtainTarget];
        if (effects.Any(e => e.Op == SkillProgramEffectOp.DiscardDamageTargetAndClaimMount) && windowContext?.TargetSeat is { } mountTarget)
            publishedTargets = [mountTarget];
        if (HasFinalTargetSlashEffects(effects) && windowContext is { Window: SkillProgramTriggerWindow.CardUseTargetsFinalized, Facts: { } finalFacts, TargetSeat: { } finalSeat })
            {
                publicContext = publicContext with { FinalTargetFacts = finalFacts, SelectedTarget = CreateSkillContext(_players[finalSeat]) };
                publishedTargets = [finalSeat];
            }
        var selection = effects.FirstOrDefault(effect => effect.Op == SkillProgramEffectOp.SelectTarget);
        var targets = publishedTargets ?? (selection?.TargetKind is { } kind
            ? GetProgramTargetSeats(owner.Seat, kind, windowContext, selection.Marker) : Array.Empty<int>());
        var context = CreateSkillContext(owner);
        if (targets.Count == 0)
            return (ProgramCompositionAi.Estimate(effects, context, owner.IsFaceDown, publicContext), null);
        var snapshot = CreateSnapshot(owner.Seat);
        return targets.Select(targetSeat =>
            {
                var estimate = ProgramCompositionAi.Estimate(effects, context, owner.IsFaceDown,
                    publicContext with
                    {
                        SelectedTarget = CreateSkillContext(_players[targetSeat]),
                        HasOwnedCardCategory = (zones, categories, kinds) =>
                            zones.Contains(CardZoneKind.Equipment) &&
                            GetEquipment(_players[targetSeat]).Any(card =>
                                MatchesProgramCardFilter(card.Kind, categories, kinds)),
                        AttackRangeCoverageDecreased = _ => GetEquipment(_players[targetSeat])
                            .Any(card => WouldEquipmentRemovalReduceCoverage(targetSeat, card.Id))
                    });
                var targetValue = _aiBrains[owner.Seat].ScoreProgramTarget(snapshot, targetSeat, estimate.Hint);
                return (Estimate: estimate with { Score = estimate.Score + targetValue }, TargetSeat: (int?)targetSeat);
            })
            .OrderByDescending(candidate => candidate.Estimate.Score)
            .ThenBy(candidate => candidate.TargetSeat)
            .First();
    }

    private PromptChoice SelectAiCompositionTarget(PendingDecision decision, ProgramSkillFrame frame)
    {
        var owner = _players[decision.PlayerSeat];
        var program = _contentRegistry!.GetSkill(frame.SkillId).Program!;
        var effects = ProgramInstructionResolver.Default.Resolve(frame, program).Instructions;
        var targets = decision.Choices.SelectMany(choice => choice.Targets).Distinct().ToArray();
        var publicContext = CreateProgramAiPublicContext(owner) with
        {
            BooleanState = stateId => GetProgramBooleanState(frame.OwnerSeat, frame.SkillId,
                frame.SkillInstanceId, stateId),
            PindianWon = bind => frame.PindianResultBindings.SingleOrDefault(item => item.Name == bind)?.SourceWon ?? false,
            PindianOutcome = bind => frame.PindianResultBindings.SingleOrDefault(item => item.Name == bind)?.SourceWon,
            ChoiceResult = bind => frame.ChoiceBindings.SingleOrDefault(item => item.Name == bind)?.OptionId
        };
        if (frame.TriggerId is { } triggerId)
            publicContext = WithPhaseHandExtraTurnTargetPricing(publicContext, program,
                ProgramInstructionResolver.Default.Resolve(program, ProgramInstructionSourceKind.Trigger, triggerId).Trigger!);
        var selected = EstimateCompositionForAi(owner, effects,
            publicContext, targets);
        return decision.Choices.First(choice => choice.Targets.Contains(selected.TargetSeat ??
            throw new InvalidOperationException("A configured target selection has no published candidate.")));
    }

    private PromptChoice SelectAiProgramTargets(
        PendingDecision decision,
        SkillProgramTargetAiOrder aiOrder)
    {
        if (aiOrder == SkillProgramTargetAiOrder.Stable)
        {
            return decision.Choices
                .OrderByDescending(choice => choice.Targets.Count)
                .ThenBy(choice => choice.Id.Value, StringComparer.Ordinal)
                .First();
        }
        var (choiceId, thought) = aiOrder switch
        {
            SkillProgramTargetAiOrder.HostileThenHandCount =>
                _aiBrains[decision.PlayerSeat].ChooseHostileHandTargets(
                    CreateSnapshot(decision.PlayerSeat), decision.Choices, _thoughtSequence++),
            SkillProgramTargetAiOrder.SupportFirstThenOpposeSecond =>
                _aiBrains[decision.PlayerSeat].ChooseSupportFirstTransferTargets(
                    CreateSnapshot(decision.PlayerSeat), decision.Choices, _thoughtSequence++),
            SkillProgramTargetAiOrder.SupportDraw =>
                _aiBrains[decision.PlayerSeat].ChooseSupportDrawTargets(
                    CreateSnapshot(decision.PlayerSeat), decision.Choices, _thoughtSequence++),
            SkillProgramTargetAiOrder.SupportRecovery =>
                _aiBrains[decision.PlayerSeat].ChooseSupportRecoveryTargets(
                    CreateSnapshot(decision.PlayerSeat), decision.Choices, _thoughtSequence++),
            SkillProgramTargetAiOrder.CardEffectIntervention =>
                _aiBrains[decision.PlayerSeat].ChooseCardEffectInterventionTargets(
                    CreateSnapshot(decision.PlayerSeat),
                    _resolutionStack.OfType<ProgramCardTriggerWindowFrame>().Last().Action.EffectiveKind,
                    decision.Choices, _thoughtSequence++),
            _ => throw new InvalidOperationException("Unsupported configured target AI order.")
        };
        AddThought(thought);
        return decision.Choices.Single(choice => choice.Id == choiceId);
    }

    private PromptChoice SelectAiProgramOwnedCards(PendingDecision decision, ProgramSkillFrame frame)
    {
        var draft = frame.OwnedCardSelection ??
            throw new InvalidOperationException("The configured owned-card choice lost its draft.");
        if (draft.MinimumCount > 0 && draft.SelectedCardIds.Count >= draft.MinimumCount)
            return decision.Choices.Single(choice =>
                choice.Parameters.GetValueOrDefault("program-action") == "finish-owned-cards");
        return decision.Choices
            .Where(choice => choice.Parameters.GetValueOrDefault("program-action") == "select-owned-cards")
            .OrderBy(choice => _cardZones.CardsAt(_cardZones.GetLocation(choice.Cards.Single()))
                .Single(card => card.Id == choice.Cards[0]).Kind is CardKind.Peach ? 1 : 0)
            .ThenBy(choice => choice.Cards[0]).First();
    }

    private PromptChoice SelectAiProgramHoldCards(PendingDecision decision, ProgramSkillFrame frame)
    {
        var draft = frame.HoldCardSelection ??
            throw new InvalidOperationException("The card-hold choice lost its draft.");
        if (draft.SelectedCardIds.Count >= draft.RequiredCount)
            return decision.Choices.Single(choice =>
                choice.Parameters.GetValueOrDefault("program-action") == "finish-owned-cards");
        // Public equipment is held first; hidden hand slots follow in fixed order.
        return decision.Choices
            .Where(choice => choice.Parameters.GetValueOrDefault("program-action") == "select-owned-cards")
            .OrderByDescending(choice =>
                choice.Parameters.GetValueOrDefault("source-zone") == nameof(CardZoneKind.Equipment))
            .ThenBy(choice => choice.Id.Value, StringComparer.Ordinal)
            .First();
    }

    private void CompleteDetachedProgramBinding(ProgramSkillFrame frame, bool completed)
    {
        var context = frame.WindowContext ??
            throw new InvalidOperationException("A detached program frame lost its window context.");
        CleanupProgramBoundCards(frame, completed);
        AdvanceEventRulesAndQueueFact(new ProgramBindingResolvedEvent(
            frame.Id, frame.SkillId, frame.TriggerId!, frame.SkillInstanceId,
            frame.OwnerSeat, context.Window, Activated: true, Completed: completed));
    }

    private void CompleteDyingProgramBinding(ProgramSkillFrame frame, bool completed)
    {
        var dying = ActiveDying ??
            throw new InvalidOperationException("The dying program lost its dying resolution.");
        if (dying.FrameId != frame.WindowContext!.ParentFrameId ||
            dying.VictimSeat != frame.WindowContext.TargetSeat ||
            dying.ResponderSeat != frame.OwnerSeat)
            throw new InvalidOperationException("The dying program returned to the wrong responder or victim.");
        var victim = _players[dying.VictimSeat];
        if (frame.WindowContext.Window == SkillProgramTriggerWindow.SelfDyingResponse)
        {
            dying = UpdateDyingFrame(dying.Id, current => current with
            {
                AttemptedSelfDyingBindings = [.. current.AttemptedSelfDyingBindings,
                    SelfDyingBindingKey(frame.SkillId, frame.TriggerId!, frame.SkillInstanceId)]
            });
            if (victim.Hp > 0)
                CompleteDying(dying, survived: true);
            else if (!TryBeginMandatorySelfDyingProgram(dying) && !TryBeginDyingEntryProgramWindow(dying))
            {
                SetDyingFrameStep(dying.FrameId, ResolutionFrameStep.AwaitingResponse);
                _status = EngineStatus.Running;
                ExposeHumanDyingPrompt();
            }
            return;
        }
        if (victim.Hp > 0)
        {
            CompleteDying(dying, survived: true);
            return;
        }
        dying = UpdateDyingFrame(dying.Id, current => current with
        {
            ResponderIndex = current.ResponderIndex + 1
        });
        if (dying.ResponderIndex >= dying.ResponderSeats.Count)
            CompleteDying(dying, survived: false);
        else
        {
            SetDyingFrameStep(dying.FrameId, ResolutionFrameStep.AwaitingResponse);
            _status = EngineStatus.Running;
            ExposeHumanDyingPrompt();
        }
    }

    private ProgramSkillWindowContext CreateDyingProgramContext(
        DyingFrame dying,
        ProgramTriggerCandidate candidate) =>
        new(
            GetProgramTrigger(candidate).Window,
            dying.FrameId,
            candidate.OwnerSeat,
            SourceSeat: GetDyingAttack(dying) is { IsSourceLess: false } attack ? attack.SourceSeat : null,
            TargetSeat: dying.VictimSeat,
            DamageFrameId: dying.DamageFrameId,
            OccurrenceIndex: candidate.OccurrenceIndex);

    private IReadOnlyList<ProgramTriggerCandidate> GetDyingProgramCandidates(
        CharacterState responder,
        DyingFrame dying) =>
        new[] { SkillProgramTriggerWindow.SelfDyingResponse, SkillProgramTriggerWindow.DyingResponse }
            .Where(window => window != SkillProgramTriggerWindow.SelfDyingResponse ||
                responder.Seat == dying.VictimSeat)
            .SelectMany(window => CollectProgramTriggerCandidates(responder, window))
                .Where(candidate => GetProgramTrigger(candidate).Window !=
                    SkillProgramTriggerWindow.SelfDyingResponse ||
                    !dying.AttemptedSelfDyingBindings.Contains(SelfDyingBindingKey(
                        candidate.SkillId, candidate.BindingId, candidate.SkillInstanceId)))
                .Where(candidate => CanRunProgramTrigger(
                    candidate,
                    CreateDyingProgramContext(dying, candidate)))
                .ToArray();

    private static string SelfDyingBindingKey(string skillId, string bindingId, string skillInstanceId) =>
        $"{skillId}\u001f{bindingId}\u001f{skillInstanceId}";

    private bool TryBeginMandatorySelfDyingProgram(DyingFrame dying)
    {
        if (dying.ResponderIndex >= dying.ResponderSeats.Count ||
            dying.ResponderSeat != dying.VictimSeat) return false;
        var victim = _players[dying.VictimSeat];
        var candidate = GetDyingProgramCandidates(victim, dying).FirstOrDefault(item =>
            GetProgramTrigger(item) is
            {
                Window: SkillProgramTriggerWindow.SelfDyingResponse,
                Optional: false
            });
        if (candidate is null) return false;
        BeginDyingProgramBinding(candidate, dying);
        return true;
    }

    private void BeginDyingProgramBinding(ProgramTriggerCandidate candidate, DyingFrame dying) =>
        BeginProgramBinding(candidate, CreateDyingProgramContext(dying, candidate));

    private ProgramSkillWindowContext CreateAfterDamageProgramContext(
        DamageTriggerWindowFrame damage,
        ProgramTriggerCandidate candidate)
    {
        var attack = GetDamageTriggerAttack(damage);
        var owner = _players[candidate.OwnerSeat];
        var appearanceSourceLess = attack.IsDelayedJudgmentDamage &&
            ProgramInstructionResolver.Default.Features(GetProgramTrigger(candidate)).HasOperation(SkillProgramEffectOp.DrawByDamageCardColor);
        var facts = CaptureProgramTriggerFacts(owner) with
        {
            CardActionActorIsCurrentTurn = !attack.IsSourceLess && attack.SourceSeat == _currentSeat,
            CardActionPhaseIsPlay = _phase == TurnPhase.Play,
            OtherDamageParticipantAlive = !attack.IsSourceLess && IsValidPlayerSeat(attack.SourceSeat) &&
                IsValidPlayerSeat(attack.TargetSeat) &&
                attack.SourceSeat != attack.TargetSeat &&
                _players[attack.SourceSeat].IsAlive &&
                _players[attack.TargetSeat].IsAlive,
            DirectCardUseDamage = !attack.IsSourceLess && !attack.IsChainPropagation &&
                attack.Card is not null &&
                attack.CardUserSeat == attack.SourceSeat,
            DamageCardIsRed = !attack.IsSourceLess && attack.Card?.Suit is Suit.Heart or Suit.Diamond,
            DamageCardSuit = !attack.IsSourceLess ? attack.Card?.Suit : null,
            DamageCardIsSlash = !attack.IsSourceLess && attack.EffectiveCardKind is
                CardKind.Slash or CardKind.FireSlash or CardKind.ThunderSlash,
            SourceToTargetDistanceAtDamage = attack.IsSourceLess ? null : attack.SourceToTargetDistanceAtDamage,
            EventTargetHp = _players[attack.TargetSeat].Hp,
            EventTargetMaxHp = _players[attack.TargetSeat].MaxHp,
            EventTargetDamageInstancesTakenThisTurn = damage.EventTargetDamageInstancesTakenThisTurn,
            DamageTargetIsOther = candidate.OwnerSeat != attack.TargetSeat,
            DamageSourceIsOwner = !attack.IsSourceLess && candidate.OwnerSeat == attack.SourceSeat,
            EventSourceMarkerCounts = HasAttributedEventOperations() && !attack.IsSourceLess &&
                IsValidPlayerSeat(attack.SourceSeat)
                ? new Dictionary<PlayerMarkerKind, int>(_players[attack.SourceSeat].Markers) : null,
            DamageSourceFactionId = attack.IsSourceLess ? null : GetEffectiveFactionId(_players[attack.SourceSeat]),
            DamageInstancesTakenThisTurn =
                GetSkillBindingShard(owner).ProgramInstances.Any(instance =>
                    ProgramInstructionResolver.Default.ProgramUsesTriggerValue(instance.Program, SkillProgramTriggerValueKind.DamageInstancesTakenThisTurn))
                ? DamageInstancesTakenThisTurn(owner.Seat) : null
        };
        return new(
            damage.TriggerWindow,
            damage.Id,
            candidate.OwnerSeat,
            SourceSeat: attack.IsSourceLess || appearanceSourceLess ? null : attack.SourceSeat,
            TargetSeat: attack.TargetSeat,
            DamageFrameId: damage.ParentFrameId,
            Amount: attack.DamageAmount,
            OccurrenceIndex: candidate.OccurrenceIndex,
            Facts: facts)
        { OptionalChooserSeat = GetProgramTrigger(candidate).Effects is [{ Op: SkillProgramEffectOp.OfferRiceAfterDamagePoint }] ? attack.TargetSeat : null };
    }
}
