$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/17917/Desktop/Card'
$taskRoot=[IO.Path]::GetFullPath('C:/Users/17917/AppData/Local/Temp/Card-architecture-01a13336')
$taskDir=Join-Path $taskRoot 'iteration15'
$deliverable=[IO.Path]::GetFullPath('docs/benchmarks/2026-10-13-architecture-frozen-copy-reuse')
$routine=Get-Content -LiteralPath (Join-Path $taskDir 'routine-summary.json') -Raw | ConvertFrom-Json
if($routine.status -ne 'passed' -or $routine.mode -ne 'routine'){throw 'Unexpected verification state'}
$files=@(Get-ChildItem -LiteralPath $taskDir -File -Recurse -Force | Sort-Object FullName)
$manifest=@(foreach($file in $files){if($file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked evidence'};[ordered]@{path=[IO.Path]::GetRelativePath($taskDir,$file.FullName).Replace('\','/');length=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}})
$manifest | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $deliverable 'evidence-manifest.json') -Encoding utf8
$zipPath=Join-Path $deliverable 'evidence.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Preserve existing archive before update'}
[IO.Compression.ZipFile]::CreateFromDirectory($taskDir,$zipPath,[IO.Compression.CompressionLevel]::Optimal,$false)
$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{
    if($zip.Entries.Count -ne $manifest.Count){throw 'Archive count mismatch'}
    foreach($item in $manifest){
        $entry=$zip.GetEntry($item.path)
        if($null -eq $entry -or $entry.Length -ne $item.length){throw 'Archive entry mismatch'}
        $stream=$entry.Open()
        try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
        if($hash -ne $item.sha256){throw "Archive hash mismatch: $($item.path)"}
    }
}finally{$zip.Dispose()}
$summary=[ordered]@{
    generatedAt=[DateTimeOffset]::Now.ToString('O')
    structural=Get-Content -LiteralPath (Join-Path $taskDir 'structural-results.json') -Raw | ConvertFrom-Json
    productionLineDelta=1
    ownedInputs=Get-Content -LiteralPath (Join-Path $taskDir 'owned-verification-proof.json') -Raw | ConvertFrom-Json
    focused=[ordered]@{corePassed=38;coreFailed=0;wpfPassed=3;wpfFailed=0;run=Get-Content -LiteralPath (Join-Path $taskDir 'focused-summary.json') -Raw | ConvertFrom-Json}
    focusedWpfEvidence=[ordered]@{passed=3;failed=0;run=Get-Content -LiteralPath (Join-Path $taskDir 'initial-focused-summary.json') -Raw | ConvertFrom-Json;note='WPF passed despite unregistered initial Core selector; Core later passed independently'}
    repairRecheck=[ordered]@{corePassed=4;coreFailed=0;wpfPassed=1;wpfFailed=0;run=Get-Content -LiteralPath (Join-Path $taskDir 'recheck-summary.json') -Raw | ConvertFrom-Json}
    initialRoutine=Get-Content -LiteralPath (Join-Path $taskDir 'initial-routine-failures.json') -Raw | ConvertFrom-Json
    repairAttribution=Get-Content -LiteralPath (Join-Path $taskDir 'repair-attribution.json') -Raw | ConvertFrom-Json
    routine=[ordered]@{corePassed=570;coreFailed=0;wpfPassed=76;wpfFailed=0;run=$routine;parallelScopes=$true}
    drift=Get-Content -LiteralPath (Join-Path $taskDir 'routine-source-drift.json') -Raw | ConvertFrom-Json
    discovery=Get-Content -LiteralPath (Join-Path $taskDir 'final-input-discovery.json') -Raw | ConvertFrom-Json
    evidence=[ordered]@{path=$zipPath;files=$manifest.Count;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Get-FileHash -LiteralPath $zipPath).Hash;allEntryHashesVerified=$true}
    cleanup=[ordered]@{taskRoot=$taskRoot;taskTemporaryPath=$taskDir;newBuildOutputDirectories=0;blockedDeletionRetried=$false;verificationReasonsRestored=$true;disposableTaskEvidence='archive verified; cleanup pending'}
    limits=@('No manual Full','No foreground desktop acceptance','No isolated routine speedup claim','No direct registered Qiaoli runtime fixture; exact membership equivalence and catalogue metadata are the scoped evidence','Focused Core and WPF evidence came from separate invocations','Concurrent feature additions excluded from own diff attribution')
}
$summary | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $deliverable 'summary.json') -Encoding utf8
[ordered]@{archive=$summary.evidence;routine='570 Core and 76 WPF passed';milliseconds=$routine.durationMs;capturedInputs=$summary.drift.inputCount} | ConvertTo-Json -Depth 4
