$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:\Users\17917\Desktop\Card'
& ./tools/Test-Changed.ps1 -CoreFilter @('content registry compiles whole catalog dependencies') -ArtifactsPath 'C:\Users\17917\AppData\Local\Temp\Card-architecture-01a13336\verification' -Verbose
